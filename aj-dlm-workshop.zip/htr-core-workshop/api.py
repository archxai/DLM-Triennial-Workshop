# api.py
"""
ArchXAI HTR API Server
======================
"""

import asyncio
import logging
import os
import sys
import time
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Literal, Union

from fastapi import Depends, FastAPI, File, HTTPException, Query, UploadFile
from fastapi.responses import Response
from pydantic import BaseModel, ConfigDict

sys.path.insert(0, str(Path(__file__).parent))

from htr_core.config import LANGUAGE_MAP, _load_languages
from htr_core.service import HTRService

# =============================================================================
# LOAD LANGUAGES AT IMPORT TIME (before FastAPI starts)
# =============================================================================
_load_languages()

# Build Literal type from loaded languages for Swagger dropdown
AVAILABLE_LANGUAGES = sorted(LANGUAGE_MAP.keys())
if AVAILABLE_LANGUAGES:
    _LangLiteralType = Literal[tuple(AVAILABLE_LANGUAGES)]
else:
    _LangLiteralType = str
    AVAILABLE_LANGUAGES = ["finnish", "swedish", "estonian", "latvian"]

# Logging setup
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()
logging.basicConfig(
    level=getattr(logging, LOG_LEVEL, logging.INFO),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("api")

# Maximum file size: 50 MB
MAX_FILE_SIZE_BYTES = 50 * 1024 * 1024

# Ngrok configuration
PUBLIC_URL = os.getenv("PUBLIC_URL", "false").lower() in ("true", "1", "yes")
NGROK_AUTHTOKEN = os.getenv("NGROK_AUTHTOKEN")

# Try to import pyngrok - it's optional
try:
    import pyngrok.ngrok as pyngrok_ngrok
    TUNNEL_AVAILABLE = True
except ImportError:
    TUNNEL_AVAILABLE = False
    logger.warning("pyngrok not installed. Ngrok tunnel will not be available. Install with: pip install pyngrok")


class LineResultSummary(BaseModel):
    """Summary of a recognized text line for API responses."""
    model_config = ConfigDict(frozen=True)
    line_number: int
    text: str
    confidence: float
    orientation: Optional[str] = "upright"
    bbox: Optional[Tuple[int, int, int, int]] = None
    segment_id: Optional[str] = None


class HTRProcessResponse(BaseModel):
    """Full response model for /process endpoint."""
    model_config = ConfigDict(frozen=True)
    status: str
    text: str = ""
    confidence: Optional[float] = None
    hash: str = ""
    storage_key: Optional[str] = None
    preprocessed_storage_key: Optional[str] = None
    boxed_image_key: Optional[str] = None
    doc_id: Optional[int] = None
    text_id: Optional[int] = None
    regions_detected: int = 0
    lines: List[LineResultSummary] = []
    model_version: Optional[str] = None
    language: Optional[str] = None
    inference_mode: Optional[str] = None
    preprocessing_enabled: bool = False
    preprocessing_method: Optional[str] = None
    detected_languages: Optional[Dict[str, float]] = None
    detected_language_code: Optional[str] = None
    processing_time_ms: Optional[float] = None
    image_metadata: Optional[Dict[str, Any]] = None
    cached: Optional[bool] = None


class HealthResponse(BaseModel):
    model_config = ConfigDict(frozen=True)
    status: str
    service: str = "htr-api"
    version: str = "1.0.0"
    languages: List[str]
    db_available: bool
    storage_available: bool
    public_url: Optional[str] = None


class LanguageInfo(BaseModel):
    model_config = ConfigDict(frozen=True)
    code: str
    name: str
    repo_id: Optional[str] = None
    description: Optional[str] = None


# Global service management
_services: Dict[str, HTRService] = {}
_services_started: Dict[str, bool] = {}
_public_url: Optional[str] = None


def get_htr_service(
    lang: _LangLiteralType = Query(..., description="Language of the text"),
    mode: Literal["Fast", "Balanced", "Accurate"] = Query("Balanced", description="Inference confidence mode"),
) -> HTRService:
    """Get or create an HTR service instance."""
    lang_code = lang.lower()
    service_key = f"{lang_code}:{mode}"
    
    if service_key not in _services:
        logger.info(f"Creating new HTR service for language '{lang_code}' with mode '{mode}'")
        _services[service_key] = HTRService(language=lang_code, mode=mode)
        _services_started[service_key] = False
    
    return _services[service_key]


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Manage application lifecycle."""
    global _public_url
    
    logger.info("Starting HTR API server...")
    logger.info(f"Loaded {len(AVAILABLE_LANGUAGES)} languages: {', '.join(AVAILABLE_LANGUAGES)}")
    
    # ── STARTUP: Create public tunnel if enabled ──────────────────────────────
    if PUBLIC_URL and TUNNEL_AVAILABLE:
        try:
            if NGROK_AUTHTOKEN:
                pyngrok_ngrok.set_auth_token(NGROK_AUTHTOKEN)
            
            port = int(os.getenv("PORT", 8081))
            tunnel = pyngrok_ngrok.connect(port)
            _public_url = tunnel.public_url
            
            logger.info(f"🌍 Ngrok tunnel created: {_public_url}")
            print(f"\n{'='*60}")
            print(f"🚀 API running at: http://localhost:{port}")
            print(f"🌍 Public URL:     {_public_url}")
            print(f"{'='*60}\n")
        except Exception as e:
            logger.warning(f"Failed to create ngrok tunnel: {e}. Starting without public URL.")
            _public_url = None
    elif PUBLIC_URL and not TUNNEL_AVAILABLE:
        logger.warning("PUBLIC_URL=true but pyngrok is not installed. Install with: pip install pyngrok")
    
    logger.info("HTR API server started successfully")
    
    yield
    
    # ── SHUTDOWN ──────────────────────────────────────────────────────────────
    if PUBLIC_URL and TUNNEL_AVAILABLE and _public_url:
        try:
            pyngrok_ngrok.kill()
            logger.info("Ngrok tunnel closed")
        except Exception:
            pass
    
    logger.info("Shutting down HTR API server...")
    for service_key, service in _services.items():
        try:
            if _services_started.get(service_key, False):
                await service.stop()
        except Exception as e:
            logger.error(f"Error stopping service {service_key}: {e}")
    
    _services.clear()
    _services_started.clear()
    _public_url = None
    logger.info("HTR API server shutdown complete")


app = FastAPI(
    title="ArchXAI HTR API",
    description="Handwritten Text Recognition API for historical documents",
    version="1.0.0",
    lifespan=lifespan,
)


@app.get("/", tags=["Root"])
async def root():
    return {
        "service": "ArchXAI HTR API",
        "version": "1.0.0",
        "docs": "/docs",
        "health": "/health",
        "languages": "/languages",
        "public_url": _public_url
    }


@app.get("/health", response_model=HealthResponse, tags=["Health"])
async def health_check():
    db_available = False
    storage_available = False
    
    try:
        if _services:
            service = list(_services.values())[0]
            db_available = service.db.is_available
            storage_available = True
    except Exception as e:
        logger.warning(f"Health check error: {e}")
    
    return HealthResponse(
        status="healthy",
        service="htr-api",
        version="1.0.0",
        languages=AVAILABLE_LANGUAGES,
        db_available=db_available,
        storage_available=storage_available,
        public_url=_public_url,
    )


@app.get("/languages", response_model=List[LanguageInfo], tags=["Languages"])
async def list_languages():
    """List all available languages with their configurations."""
    languages = []
    for lang_code, config in LANGUAGE_MAP.items():
        if isinstance(config, dict):
            repo_id = config.get("repo")
            description = config.get("description")
        else:
            repo_id = config
            description = None
        
        languages.append(LanguageInfo(
            code=lang_code,
            name=lang_code.capitalize(),
            repo_id=repo_id,
            description=description
        ))
    
    return languages


@app.post("/process", response_model=HTRProcessResponse, tags=["Processing"])
async def process_image(
    file: UploadFile = File(..., description="Image file to process"),
    lang: _LangLiteralType = Query(..., description="Language of the text"),
    mode: Literal["Fast", "Balanced", "Accurate"] = Query("Balanced", description="Inference confidence mode"),
    doc_type: str = Query("Historical_Manuscript", description="Document category for database"),
    rerun: bool = Query(False, description="Force re-process"),
    alternative: bool = Query(False, description="Allow storing new results"),
    merge_lines: bool = Query(True, description="Merge overlapping line detections"),
):
    start_time = time.time()
    
    try:
        # Validate language
        lang_code = lang.lower()
        if lang_code not in LANGUAGE_MAP:
            raise HTTPException(status_code=400, detail=f"Invalid language: {lang}. Available: {list(LANGUAGE_MAP.keys())}")
        
        # Get or create service
        service_key = f"{lang_code}:{mode}"

        if service_key not in _services:
            logger.info(f"Creating new HTR service for language '{lang_code}' with mode '{mode}'")
            _services[service_key] = HTRService(language=lang_code, mode=mode)
            _services_started[service_key] = False

        service = _services[service_key]

        # Validate file type
        if not file.content_type or not file.content_type.startswith('image/'):
            raise HTTPException(status_code=400, detail=f"Invalid file type: {file.content_type}")
        
        # Read with size check
        image_bytes = await file.read()
        
        if len(image_bytes) == 0:
            raise HTTPException(status_code=400, detail="Empty file received")
        
        # Add file size bound check
        if len(image_bytes) > MAX_FILE_SIZE_BYTES:
            raise HTTPException(
                status_code=413,
                detail=f"File too large: {len(image_bytes):,} bytes. Maximum allowed: {MAX_FILE_SIZE_BYTES:,} bytes (50 MB)"
            )
        
        logger.info(f"Processing: file={file.filename}, size={len(image_bytes):,} bytes, lang={lang}, mode={mode}")
        
        # Ensure service is started before processing
        if not _services_started.get(service_key, False):
            logger.info(f"Starting service {service_key}")
            await service.start()
            _services_started[service_key] = True
        
        # Process image
        result = await service.process_image(
            image_input=image_bytes,
            doc_type=doc_type,
            alternative=alternative,
            merge_lines=merge_lines,
            rerun=rerun,
            original_filename=file.filename,
        )
        
        # Build line summaries
        lines = []
        if "lines" in result:
            for line_data in result.get("lines", []):
                lines.append(LineResultSummary(
                    line_number=len(lines) + 1,
                    text=line_data.get("text", ""),
                    confidence=line_data.get("confidence", 0.0),
                    orientation=line_data.get("orientation", "upright"),
                    bbox=line_data.get("bbox"),
                    segment_id=line_data.get("segment_id"),
                ))
        
        elapsed_ms = (time.time() - start_time) * 1000
        
        return HTRProcessResponse(
            status=result.get("status", "success"),
            text=result.get("text", ""),
            confidence=result.get("confidence"),
            hash=result.get("hash", ""),
            storage_key=result.get("storage_key"),
            preprocessed_storage_key=result.get("preprocessed_storage_key"),
            boxed_image_key=result.get("boxed_image_key"),
            doc_id=result.get("doc_id"),
            text_id=result.get("text_id"),
            regions_detected=result.get("regions_detected", 0),
            lines=lines,
            model_version=result.get("model_version"),
            language=result.get("language"),
            inference_mode=result.get("inference_mode"),
            preprocessing_enabled=result.get("preprocessing_enabled", False),
            preprocessing_method=result.get("preprocessing_method"),
            detected_languages=result.get("detected_languages"),
            detected_language_code=result.get("detected_language_code"),
            processing_time_ms=result.get("processing_time_ms", elapsed_ms),
            image_metadata=result.get("image_metadata"),
            cached=result.get("cached", False),
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Internal Server Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8081))
    host = os.getenv("HOST", "0.0.0.0")
    uvicorn.run("api:app", host=host, port=port, log_level=LOG_LEVEL.lower())