# htr_core/service.py
"""
HTR Service - Pipeline Orchestrator
====================================
"""

import asyncio
import base64
import hashlib
import io
import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import httpx
from PIL import Image

from .core import HTRStandaloneProcessor
from .database import AsyncArchXAIDatabaseHandler
from .exceptions import HTRCoreError
from .storage import MinIOStorageHandler

logger = logging.getLogger(__name__)

# MIME type mapping
MIME_TYPES = {
    'JPEG': 'image/jpeg', 'JPG': 'image/jpeg', 'PNG': 'image/png',
    'GIF': 'image/gif', 'TIFF': 'image/tiff', 'BMP': 'image/bmp',
    'WEBP': 'image/webp',
}

# Bit depth mapping
MODE_BIT_DEPTH = {
    '1': 1, 'L': 8, 'LA': 16, 'P': 8, 'PA': 16,
    'RGB': 24, 'RGBX': 32, 'RGBA': 32, 'CMYK': 32,
    'YCbCr': 24, 'LAB': 24, 'HSV': 24,
}

# EXIF resolution unit mapping (standard EXIF tag 296)
EXIF_RESOLUTION_UNIT_MAP = {
    1: 'none',
    2: 'inch',
    3: 'cm',
    4: 'mm',
    5: 'um',
}


def _parse_exif_datetime(exif_string: Optional[str]) -> Optional[datetime]:
    """Parse EXIF datetime string to datetime object."""
    if not exif_string:
        return None
    try:
        parsed = datetime.strptime(exif_string, "%Y:%m:%d %H:%M:%S")
        return parsed.replace(tzinfo=timezone.utc)
    except ValueError:
        logger.debug(f"Failed to parse EXIF datetime: {exif_string}")
        return None


def _parse_exif_resolution_unit(value: Optional[int]) -> Optional[str]:
    """Parse EXIF resolution unit to human-readable string."""
    if value is None:
        return None
    return EXIF_RESOLUTION_UNIT_MAP.get(value)


def extract_metadata_from_image(
    img: Image.Image,
    image_bytes: bytes,
    original_filename: Optional[str] = None
) -> Dict[str, Any]:
    """Extract comprehensive metadata from a PIL Image."""
    width, height = img.size
    format_str = img.format or "UNKNOWN"
    mime_type = MIME_TYPES.get(format_str.upper(), "application/octet-stream")
    
    extension = None
    if original_filename:
        ext = Path(original_filename).suffix.lower()
        extension = ext.lstrip(".") if ext else None
    
    color_mode = img.mode
    bit_depth = MODE_BIT_DEPTH.get(img.mode)
    has_alpha = color_mode in ("RGBA", "LA", "PA") and color_mode.endswith("A")
    
    compression_type = format_str
    compression_quality = None
    
    # EXIF extraction
    raw_exif_data = None
    exif_make = exif_model = exif_datetime_str = exif_software = None
    exif_datetime: Optional[datetime] = None
    exif_orientation = exif_x_resolution = exif_y_resolution = None
    exif_resolution_unit: Optional[str] = None
    
    try:
        exif = img.getexif()
        if exif:
            raw_exif_data = {str(k): str(v) for k, v in exif.items()}
            exif_make = str(exif.get(271)) if 271 in exif else None
            exif_model = str(exif.get(272)) if 272 in exif else None
            exif_datetime_str = str(exif.get(306)) if 306 in exif else None
            exif_datetime = _parse_exif_datetime(exif_datetime_str)
            exif_software = str(exif.get(305)) if 305 in exif else None
            exif_orientation = exif.get(274)
            exif_x_resolution = float(exif.get(282)) if 282 in exif and exif.get(282) else None
            exif_y_resolution = float(exif.get(283)) if 283 in exif and exif.get(283) else None
            exif_resolution_unit_raw = exif.get(296)
            exif_resolution_unit = _parse_exif_resolution_unit(exif_resolution_unit_raw)
    except Exception as e:
        logger.debug(f"EXIF extraction failed: {e}")
    
    return {
        "file_size_bytes": len(image_bytes),
        "image_width": width,
        "image_height": height,
        "mime_type": mime_type,
        "original_filename": original_filename,
        "original_extension": extension,
        "exif_make": exif_make,
        "exif_model": exif_model,
        "exif_datetime": exif_datetime,
        "exif_software": exif_software,
        "exif_orientation": exif_orientation,
        "exif_x_resolution": exif_x_resolution,
        "exif_y_resolution": exif_y_resolution,
        "exif_resolution_unit": exif_resolution_unit,
        "color_mode": color_mode,
        "bit_depth": bit_depth,
        "has_alpha": has_alpha,
        "compression_type": compression_type,
        "compression_quality": compression_quality,
        "raw_exif_data": json.dumps(raw_exif_data) if raw_exif_data else None,
    }


class HTRService:
    """High-level HTR service orchestrator."""
    
    def __init__(self, language: str, device: Optional[str] = None, mode: str = "Balanced"):
        self.language = language.lower()
        self.mode = mode
        self.processor = HTRStandaloneProcessor(language, device, mode)
        self.db = AsyncArchXAIDatabaseHandler()
        self.storage = MinIOStorageHandler()
        self.lock = asyncio.Lock()
        self.http: Optional[httpx.AsyncClient] = None
        
        self.langdetect_url = os.getenv('LANGDETECT_ENDPOINT', 'http://langdetect-archxai/detectlanguage')
        self.preprocess_url = os.getenv('PREPROCESS_URL', 'http://image-enhance-archxai/preprocess')
        self.preprocessing_method = os.getenv('PREPROCESSING_METHOD', 'auto')
        
        logger.info(f"HTRService initialized for language '{language}', mode '{mode}'")

    async def start(self) -> None:
        """Initialize connections and resources."""
        await self.db.connect()
        self.storage.ensure_bucket()
        self.http = httpx.AsyncClient(timeout=60.0)
        logger.info("HTR service started")

    async def stop(self) -> None:
        """Cleanup resources."""
        if self.http:
            await self.http.aclose()
            self.http = None
        await self.db.disconnect()
        await self.processor.close()
        logger.info("HTR service stopped")

    @staticmethod
    def calculate_sha256(data: bytes) -> str:
        return hashlib.sha256(data).hexdigest()

    async def _preprocess(self, img: Image.Image) -> Tuple[Image.Image, str]:
        """Preprocess image using external image-enhance service."""
        if not self.http:
            return img, "none"
            
        try:
            buffer = io.BytesIO()
            img.save(buffer, format='JPEG', quality=95)
            image_bytes = buffer.getvalue()
            image_b64 = base64.b64encode(image_bytes).decode()
            
            response = await self.http.post(
                self.preprocess_url,
                json={"image_base64": image_b64, "method": self.preprocessing_method},
                timeout=30.0
            )
            response.raise_for_status()
            
            result = response.json()
            method_used = result.get("method_used", "auto")
            preprocessed_b64 = result.get("preprocessed_base64", image_b64)
            preprocessed_bytes = base64.b64decode(preprocessed_b64)
            preprocessed_img = Image.open(io.BytesIO(preprocessed_bytes))
            
            logger.info(f"Preprocessed image using method: {method_used}")
            return preprocessed_img, method_used
            
        except Exception as e:
            logger.warning(f"Preprocessing failed: {e}, using original image")
            return img, "none"

    async def _detect(self, text: str) -> Dict[str, float]:
        """
        Detect language of transcribed text via langdetect service.
        
        Returns:
            Dict of {lang_code: confidence} sorted by confidence descending.
            Example: {"fi": 0.88, "en": 0.08, "sv": 0.03}
        """
        if not self.http or not text or not text.strip():
            logger.debug("Skipping language detection: empty text or no HTTP client")
            return {}
        
        try:
            logger.info(f"Calling langdetect service at {self.langdetect_url}")
            
            response = await self.http.post(
                self.langdetect_url,
                json={"text": text[:10000]},  # Limit text length
                timeout=30.0
            )
            response.raise_for_status()
            result = response.json()
            
            # Validate response format
            if not isinstance(result, dict):
                logger.warning(f"Language detection returned non-dict: {type(result)}")
                return {}
            
            # Filter to only valid language codes with numeric confidence
            detections = {}
            for lang_code, confidence in result.items():
                if not isinstance(lang_code, str) or not lang_code.isalpha() or len(lang_code) > 10:
                    continue
                if not isinstance(confidence, (int, float)):
                    continue
                conf = float(confidence)
                if 0 <= conf <= 1:
                    detections[lang_code] = conf
            
            # Sort by confidence (descending) - highest confidence first
            detections = dict(sorted(detections.items(), key=lambda x: x[1], reverse=True))
            
            if not detections:
                logger.warning("No valid language detections found in response")
                return {}
            
            logger.info(f"Detected languages: {detections}")
            return detections
            
        except httpx.TimeoutException:
            logger.warning(f"Language detection timed out after 30s")
            return {}
        except httpx.HTTPStatusError as e:
            logger.warning(f"Language detection HTTP error: {e.response.status_code}")
            return {}
        except Exception as e:
            logger.warning(f"Language detection failed: {e}")
            return {}

    async def process_image(
        self,
        image_input: Union[str, Path, bytes, Image.Image],
        doc_type: str = "Historical_Manuscript",
        alternative: bool = False,
        merge_lines: bool = True,
        rerun: bool = False,
        original_filename: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Process a single image through the HTR pipeline."""
        import time
        start_time = time.time()
        
        try:
            # Load image
            if isinstance(image_input, (str, Path)):
                path = Path(image_input)
                if original_filename is None:
                    original_filename = path.name
                img = Image.open(path).convert("RGB")
            elif isinstance(image_input, bytes):
                img = Image.open(io.BytesIO(image_input)).convert("RGB")
            elif isinstance(image_input, Image.Image):
                img = image_input.convert("RGB")
            else:
                raise ValueError(f"Unsupported image input type: {type(image_input)}")
            
            # Calculate hash
            buffer = io.BytesIO()
            img.save(buffer, format='JPEG', quality=95)
            image_bytes = buffer.getvalue()
            file_hash = self.calculate_sha256(image_bytes)
            
            # Check cache
            if not rerun and not alternative:
                existing_text = await self.db.get_transcription(file_hash)
                if existing_text:
                    logger.info(f"Cache hit for {file_hash}")
                    return {
                        "status": "cached",
                        "text": existing_text,
                        "hash": file_hash,
                        "confidence": None,
                        "cached": True
                    }
            
            # Clear existing data if rerun
            if rerun:
                await self.db.clear_image_data(file_hash)
            
            # Extract FULL metadata BEFORE preprocessing
            metadata = extract_metadata_from_image(img, image_bytes, original_filename)
            
            # Preprocess image
            preprocessed_img, preprocess_method = await self._preprocess(img)
            
            # Add preprocessing info to metadata
            metadata["preprocessing_method"] = preprocess_method
            preprocessed_storage_key = None
            
            if preprocess_method != "none":
                metadata["preprocessed_at"] = datetime.now(timezone.utc)
                metadata["preprocessing_version"] = "1.0"
                preprocessed_buffer = io.BytesIO()
                preprocessed_img.save(preprocessed_buffer, format='JPEG', quality=95)
                preprocessed_bytes = preprocessed_buffer.getvalue()
                preprocessed_storage_key = self.storage.upload_image(preprocessed_bytes, f"{file_hash}_preprocessed")
                metadata["preprocessed_image_path"] = preprocessed_storage_key
            else:
                metadata["preprocessed_image_path"] = None
            
            # Upload original to MinIO (AFTER metadata extraction, BEFORE DB)
            storage_key = self.storage.upload_image(image_bytes, file_hash)
            
            # Initialize document with FULL metadata
            doc_id, pic_id = await self.db.initialize_document(
                doc_type=doc_type,
                storage_key=storage_key,
                file_hash=file_hash,
                archive_origin='htr-core',
                collection_type=doc_type,
                metadata=metadata,
                force_new_picture=alternative
            )
            
            # Run HTR inference
            async with self.lock:
                lines, confidence, metrics = await self.processor.process_async(
                    preprocessed_img if preprocess_method != "none" else img,
                    merge_lines=merge_lines
                )
            
            # Get model metadata
            model_metadata = self.processor.get_model_metadata()
            logger.info(f"Model metadata keys: {model_metadata.keys() if model_metadata else 'None'}")
            
            # Get model version - try multiple keys
            model_version = model_metadata.get("model_id") or model_metadata.get("repo_id") or "unknown"
            logger.info(f"Model version extracted: {model_version}")
            
            # Build full text from recognized lines
            full_text = "\n".join(line.text for line in lines if hasattr(line, 'text'))
            
            # Detect language via external service
            lang_detections = await self._detect(full_text)
            
            # Extract primary detected language (highest confidence)
            detected_lang = None
            if lang_detections:
                detected_lang = max(lang_detections.items(), key=lambda x: x[1])[0]
            logger.info(
                f"Language detection complete: detected={detected_lang}, "
                f"confidences={lang_detections}"
            )
            # Save HTR results
            text_id = await self.db.save_htr_results(
                doc_id=doc_id,
                pic_id=pic_id,
                lines=lines,
                user_chosen_language=self.language,
                detected_language_code=detected_lang,
                model_ver=model_version,
                confidence_score=confidence,
                model_details=model_metadata,
                text_origin="HTR",
                inference_mode=self.mode
            )
            
            # Save detected languages to Text_Language_Detections table
            if lang_detections:
                await self.db.save_detected_languages(text_id, lang_detections)
                logger.info(f"Saved {len(lang_detections)} language detections for text_id={text_id}")
            
            # Generate and upload visualization
            segments = metrics.get('segments', [])
            boxed_img = self.processor.generate_visualization(
                preprocessed_img if preprocess_method != "none" else img,
                lines,
                segments
            )
            boxed_key = self.storage.upload_boxed_image(boxed_img, file_hash)
            await self.db.update_boxed_image_path(pic_id, boxed_key)
            await self.db.update_status(doc_id, "Completed", "Finished", text_id=text_id)
            
            elapsed = (time.time() - start_time) * 1000
            
            result = {
                "status": "success",
                "text": full_text,
                "confidence": confidence,
                "hash": file_hash,
                "storage_key": storage_key,
                "preprocessed_storage_key": preprocessed_storage_key,
                "boxed_image_key": boxed_key,
                "doc_id": doc_id,
                "text_id": text_id,
                "regions_detected": len(set(
                    l.segment_id for l in lines
                    if hasattr(l, 'segment_id') and l.segment_id
                )),
                "lines": [
                    {
                        "text": l.text if hasattr(l, 'text') else "",
                        # FIX: Use recognition_confidence instead of non-existent 'confidence'
                        "confidence": l.recognition_confidence if hasattr(l, 'recognition_confidence') else 0.0,
                        "bbox": l.bbox if hasattr(l, 'bbox') else None,
                        "orientation": l.orientation if hasattr(l, 'orientation') else "upright",
                        "segment_id": l.segment_id if hasattr(l, 'segment_id') else None,
                    }
                    for l in lines
                ],
                "model_version": model_version,
                "language": self.language,
                "inference_mode": self.mode,
                "preprocessing_enabled": preprocess_method != "none",
                "preprocessing_method": preprocess_method,
                "detected_languages": lang_detections,
                "detected_language_code": detected_lang,
                "processing_time_ms": elapsed,
                "image_metadata": metadata
            }
            
            logger.info(
                f"Processed {file_hash}: {len(lines)} lines, "
                f"confidence={confidence:.3f}, time={elapsed:.0f}ms, "
                f"detected_lang={detected_lang}"
            )
            return result
            
        except Exception as e:
            logger.exception(f"HTR processing failed: {e}")
            raise HTRCoreError(f"HTR processing failed: {e}") from e