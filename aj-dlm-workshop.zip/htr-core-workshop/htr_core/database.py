# htr_core/database.py
"""
Async PostgreSQL handler for ArchXAI HTR data persistence.
"""

import json
import logging
import os
from typing import Any, Dict, List, Optional, Tuple

import asyncpg

from .exceptions import HTRDatabaseError

logger = logging.getLogger(__name__)


class AsyncArchXAIDatabaseHandler:
    def __init__(self):
        self.host = os.getenv("DB_HOST", "localhost")
        self.port = int(os.getenv("DB_PORT", 5432))
        self.dbname = os.getenv("DB_NAME", "archxai_db")
        self.user = os.getenv("DB_USER", "archxai_user")
        self.password = os.getenv("DB_PASS", "")
        self.pool: Optional[asyncpg.Pool] = None
        self.is_available = False

    async def connect(self) -> None:
        if self.pool:
            return
        try:
            self.pool = await asyncpg.create_pool(
                user=self.user,
                password=self.password,
                database=self.dbname,
                host=self.host,
                port=self.port,
                min_size=1,
                max_size=20,
                command_timeout=60
            )
            self.is_available = True
            logger.info(f"Connected to database {self.dbname}")
            await self.purge_orphaned_documents()
        except Exception as e:
            self.is_available = False
            logger.error(f"Database connection failed: {e}")
            raise HTRDatabaseError(f"Database connection failed: {e}") from e

    async def disconnect(self) -> None:
        if self.pool:
            await self.pool.close()
            self.pool = None
            self.is_available = False
            logger.info("Database connection pool closed")

    async def get_transcription(
        self,
        file_hash: str,
        model_version: Optional[str] = None,
        text_origin: str = "HTR",
        inference_mode: Optional[str] = None
    ) -> Optional[str]:
        if not self.pool:
            return None
        try:
            query = '''
                SELECT COALESCE(t."corrected_text", t."original_raw_text")
                FROM "Texts" t
                JOIN "Pictures" p ON t."picture_id" = p."picture_id"
                JOIN "Documents" d ON t."document_id" = d."document_id"
                WHERE p."sha256_hash" = $1
                  AND t."text_origin" = $2::text_origin
                  AND d."deleted_at" IS NULL
            '''
            params: List[Any] = [file_hash, text_origin]
            
            if model_version:
                query += f' AND t."model_version" = ${len(params) + 1}'
                params.append(model_version)
            if inference_mode:
                query += f' AND t."inference_mode" = ${len(params) + 1}::inference_mode'
                params.append(inference_mode)
            query += ' ORDER BY t."created_at" DESC LIMIT 1'
            
            async with self.pool.acquire() as conn:
                return await conn.fetchval(query, *params)
        except Exception as e:
            logger.error(f"Failed to get transcription: {e}")
            return None

    async def initialize_document(
        self,
        doc_type: str,
        storage_key: str,
        file_hash: str,
        archive_origin: Optional[str] = None,
        collection_type: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        force_new_picture: bool = False,
    ) -> Tuple[Optional[int], Optional[int]]:
        """
        Initialize document and picture records.
        
        force_new_picture (alternative):
          - True + picture exists: REUSE existing (add alternative transcription)
          - False + picture exists: reuse same document
          - No picture: create new records
        """
        if not self.pool:
            logger.warning("Database pool not available, skipping document initialization")
            return None, None
        
        if metadata is None:
            metadata = {}
            
        try:
            async with self.pool.acquire() as conn:
                async with conn.transaction():
                    # Check if picture already exists
                    existing = await conn.fetchrow(
                        'SELECT "picture_id", "document_id", "metadata_id" FROM "Pictures" WHERE "sha256_hash" = $1',
                        file_hash
                    )
                    
                    if existing:
                        # Picture exists - reuse existing records
                        existing_doc_id = existing["document_id"]
                        existing_pic_id = existing["picture_id"]
                        
                        # Update file_path if needed
                        await conn.execute(
                            'UPDATE "Pictures" SET "file_path" = $1, "updated_at" = CURRENT_TIMESTAMP WHERE "picture_id" = $2',
                            storage_key, existing_pic_id
                        )
                        
                        # UPDATE existing processing status
                        await conn.execute(
                            '''UPDATE "Processing_Status" 
                               SET "status" = 'Processing', 
                                   "current_stage" = 'HTR_Inference',
                                   "updated_at" = CURRENT_TIMESTAMP,
                                   "error_log" = NULL
                               WHERE "document_id" = $1''',
                            existing_doc_id
                        )
                        
                        logger.info(f"Reusing existing picture {existing_pic_id}, document {existing_doc_id} (alternative={force_new_picture})")
                        return existing_doc_id, existing_pic_id
                    
                    # No existing picture - create new records
                    doc_id = await conn.fetchval(
                        'INSERT INTO "Documents" ("document_type") VALUES ($1) RETURNING "document_id"',
                        doc_type
                    )
                    
                    # Create metadata record
                    metadata_id = await conn.fetchval(
                        '''
                        INSERT INTO "Pictures_Metadata" (
                            "file_size_bytes", "image_width", "image_height", "mime_type",
                            "original_filename", "original_extension", "exif_make", "exif_model",
                            "exif_datetime", "exif_software", "exif_orientation",
                            "exif_x_resolution", "exif_y_resolution", "exif_resolution_unit",
                            "color_mode", "bit_depth", "has_alpha", "compression_type",
                            "compression_quality", "preprocessing_method", "preprocessed_at",
                            "preprocessing_version", "preprocessed_image_path", "raw_exif_data"
                        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24)
                        RETURNING "metadata_id"
                        ''',
                        metadata.get("file_size_bytes"),
                        metadata.get("image_width"),
                        metadata.get("image_height"),
                        metadata.get("mime_type"),
                        metadata.get("original_filename"),
                        metadata.get("original_extension"),
                        metadata.get("exif_make"),
                        metadata.get("exif_model"),
                        metadata.get("exif_datetime"),
                        metadata.get("exif_software"),
                        metadata.get("exif_orientation"),
                        metadata.get("exif_x_resolution"),
                        metadata.get("exif_y_resolution"),
                        metadata.get("exif_resolution_unit"),
                        metadata.get("color_mode"),
                        metadata.get("bit_depth"),
                        metadata.get("has_alpha"),
                        metadata.get("compression_type"),
                        metadata.get("compression_quality"),
                        metadata.get("preprocessing_method"),
                        metadata.get("preprocessed_at"),
                        metadata.get("preprocessing_version"),
                        metadata.get("preprocessed_image_path"),
                        metadata.get("raw_exif_data"),
                    )
                    
                    # Insert picture
                    pic_id = await conn.fetchval(
                        '''
                        INSERT INTO "Pictures" 
                        ("document_id", "metadata_id", "sha256_hash", "file_path", "archive_origin", "collection_type")
                        VALUES ($1, $2, $3, $4, $5, $6)
                        RETURNING "picture_id"
                        ''',
                        doc_id, metadata_id, file_hash, storage_key, archive_origin, collection_type
                    )
                    
                    # Initialize processing status
                    await conn.execute(
                        'INSERT INTO "Processing_Status" ("document_id", "status", "current_stage") VALUES ($1, $2, $3)',
                        doc_id, 'Processing', 'HTR_Inference'
                    )
                    
                    logger.info(f"Created new document {doc_id}, picture {pic_id}, metadata {metadata_id}")
                    return doc_id, pic_id
                    
        except Exception as e:
            logger.error(f"Failed to initialize document: {e}")
            raise HTRDatabaseError(f"Failed to initialize document: {e}") from e

    async def update_boxed_image_path(self, pic_id: int, key: str) -> None:
        if not self.pool:
            return
        try:
            async with self.pool.acquire() as conn:
                await conn.execute(
                    'UPDATE "Pictures" SET "boxed_image_path" = $1, "updated_at" = CURRENT_TIMESTAMP WHERE "picture_id" = $2',
                    key, pic_id
                )
        except Exception as e:
            logger.error(f"Failed to update boxed image path: {e}")

    async def delete_transcription(
        self,
        pic_id: int,
        model_version: Optional[str] = None,
        inference_mode: Optional[str] = None,
        text_origin: str = "HTR"
    ) -> None:
        """Delete transcription records and their child records for a picture."""
        if not self.pool:
            return
        try:
            async with self.pool.acquire() as conn:
                async with conn.transaction():
                    # Get all text_ids matching the criteria
                    query = 'SELECT "text_id" FROM "Texts" WHERE "picture_id" = $1 AND "text_origin" = $2::text_origin'
                    params: List[Any] = [pic_id, text_origin]
                    
                    if model_version:
                        query += f' AND "model_version" = ${len(params) + 1}'
                        params.append(model_version)
                    if inference_mode:
                        query += f' AND "inference_mode" = ${len(params) + 1}::inference_mode'
                        params.append(inference_mode)
                    
                    text_ids = await conn.fetchvals(query, *params)
                    
                    if text_ids:
                        # Delete Text_Lines and Text_Segments for each text
                        for text_id in text_ids:
                            await conn.execute('DELETE FROM "Text_Lines" WHERE "text_id" = $1', text_id)
                            await conn.execute('DELETE FROM "Text_Segments" WHERE "text_id" = $1', text_id)
                            await conn.execute('DELETE FROM "Text_Language_Detections" WHERE "text_id" = $1', text_id)
                        
                        # Delete Texts records
                        delete_texts_query = 'DELETE FROM "Texts" WHERE "picture_id" = $1 AND "text_origin" = $2::text_origin'
                        delete_params: List[Any] = [pic_id, text_origin]
                        if model_version:
                            delete_texts_query += f' AND "model_version" = ${len(delete_params) + 1}'
                            delete_params.append(model_version)
                        if inference_mode:
                            delete_texts_query += f' AND "inference_mode" = ${len(delete_params) + 1}::inference_mode'
                            delete_params.append(inference_mode)
                        await conn.execute(delete_texts_query, *delete_params)
                        
                        logger.info(f"Deleted transcriptions {text_ids} and child records for picture {pic_id}")
                    else:
                        logger.info(f"No transcriptions found for picture {pic_id}")
                        
        except Exception as e:
            logger.error(f"Failed to delete transcription: {e}")

    async def clear_image_data(self, file_hash: str) -> Optional[str]:
        if not self.pool:
            return None
        try:
            async with self.pool.acquire() as conn:
                row = await conn.fetchrow(
                    'SELECT "file_path" FROM "Pictures" WHERE "sha256_hash" = $1',
                    file_hash
                )
                storage_key = row["file_path"] if row else None
                
                async with conn.transaction():
                    pic_row = await conn.fetchrow(
                        'SELECT "picture_id", "document_id", "metadata_id" FROM "Pictures" WHERE "sha256_hash" = $1',
                        file_hash
                    )
                    
                    if pic_row:
                        pic_id = pic_row["picture_id"]
                        doc_id = pic_row["document_id"]
                        metadata_id = pic_row["metadata_id"]
                        
                        # Get text_ids to delete child records
                        text_ids = await conn.fetchvals(
                            'SELECT "text_id" FROM "Texts" WHERE "picture_id" = $1',
                            pic_id
                        )
                        for text_id in text_ids:
                            await conn.execute('DELETE FROM "Text_Lines" WHERE "text_id" = $1', text_id)
                            await conn.execute('DELETE FROM "Text_Segments" WHERE "text_id" = $1', text_id)
                            await conn.execute('DELETE FROM "Text_Language_Detections" WHERE "text_id" = $1', text_id)
                        
                        await conn.execute('DELETE FROM "Texts" WHERE "picture_id" = $1', pic_id)
                        await conn.execute('DELETE FROM "Processing_Status" WHERE "document_id" = $1', doc_id)
                        if metadata_id:
                            await conn.execute('DELETE FROM "Pictures_Metadata" WHERE "metadata_id" = $1', metadata_id)
                        await conn.execute('DELETE FROM "Pictures" WHERE "picture_id" = $1', pic_id)
                        await conn.execute('DELETE FROM "Documents" WHERE "document_id" = $1', doc_id)
                        logger.info(f"Cleared all data for hash {file_hash}")
                        
                return storage_key
                
        except Exception as e:
            logger.error(f"Failed to clear image data: {e}")
            return None

    async def save_htr_results(
        self,
        doc_id: int,
        pic_id: int,
        lines: List[Any],
        user_chosen_language: str,
        detected_language_code: Optional[str],
        model_ver: str,
        confidence_score: float,
        model_details: Optional[Dict[str, Any]] = None,
        text_origin: str = "HTR",
        inference_mode: str = "Balanced",
    ) -> int:
        """
        Save HTR results including transcription and line data.
        
        FIX: segment_id is now a coordinate-based hash string (e.g. "0_0", "100_200"),
        NOT a sequential integer index. We build a proper mapping from segment_id 
        to segment_database_id when creating Text_Segments records.
        """
        if not self.pool:
            raise HTRDatabaseError("Database pool not available")

        try:
            async with self.pool.acquire() as conn:
                async with conn.transaction():
                    full_text = "\n".join(line.text for line in lines if hasattr(line, 'text'))
                    
                    # Insert Texts record
                    text_id = await conn.fetchval(
                        '''
                        INSERT INTO "Texts" 
                        ("document_id", "picture_id", "original_raw_text", 
                        "confidence_score", "user_chosen_language", "detected_language_code",
                        "model_version", "model_details", "inference_mode", "text_origin")
                        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10::text_origin)
                        RETURNING "text_id"
                        ''',
                        doc_id, pic_id, full_text, confidence_score,
                        user_chosen_language, detected_language_code,
                        model_ver,
                        json.dumps(model_details) if model_details else None,
                        inference_mode, text_origin
                    )
                    
                    logger.debug(f"Created Texts record: text_id={text_id}")
                    
                    # Build mapping: segment_id (string hash) -> segment_db_id (int)
                    # Group lines by their segment_id
                    segments_map: Dict[str, List[Any]] = {}
                    for line in lines:
                        seg_id = getattr(line, 'segment_id', None)
                        # Handle None, empty string, or invalid segment_id
                        if seg_id is None or seg_id == '' or str(seg_id) == 'None':
                            seg_id = 'default'
                        else:
                            seg_id = str(seg_id)
                        
                        if seg_id not in segments_map:
                            segments_map[seg_id] = []
                        segments_map[seg_id].append(line)
                    
                    logger.debug(f"Unique segment_ids found: {list(segments_map.keys())}")
                    logger.debug(f"Lines per segment_id: {{k: len(v) for k, v in segments_map.items()}}")
                    
                    # Insert Text_Segments records and build seg_id -> DB_id mapping
                    segment_id_map: Dict[str, int] = {}  # string segment_id -> database segment_id
                    
                    for seg_idx, (seg_id, seg_lines) in enumerate(sorted(segments_map.items())):
                        first_line = seg_lines[0]
                        bbox_xmin = bbox_ymin = bbox_xmax = bbox_ymax = None
                        polygon_coords = getattr(first_line, 'region_polygon', None)
                        if polygon_coords and len(polygon_coords) >= 4:
                            xs = [c[0] for c in polygon_coords]
                            ys = [c[1] for c in polygon_coords]
                            bbox_xmin, bbox_ymin = min(xs), min(ys)
                            bbox_xmax, bbox_ymax = max(xs), max(ys)
                        
                        seg_confidence = sum(
                            getattr(l, 'recognition_confidence', confidence_score) for l in seg_lines
                        ) / len(seg_lines) if seg_lines else 0
                        
                        segment_db_id = await conn.fetchval(
                            '''
                            INSERT INTO "Text_Segments"
                            ("text_id", "segment_number", "category", "confidence_score",
                            "bbox_xmin", "bbox_ymin", "bbox_xmax", "bbox_ymax",
                            "polygon_coords", "line_count")
                            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
                            RETURNING "segment_id"
                            ''',
                            text_id, seg_idx + 1, 'text_region', seg_confidence,
                            bbox_xmin, bbox_ymin, bbox_xmax, bbox_ymax,
                            json.dumps(polygon_coords) if polygon_coords else None,
                            len(seg_lines)
                        )
                        # Store the mapping: original segment_id string -> database segment_id int
                        segment_id_map[seg_id] = segment_db_id
                    
                    logger.debug(f"Created {len(segment_id_map)} segments: {segment_id_map}")
                    
                    # Insert Text_Lines
                    for line_num, line in enumerate(lines, start=1):
                        polygon = getattr(line, 'polygon', None)
                        polygon_json = json.dumps(polygon) if polygon else None
                        orientation = getattr(line, 'orientation', 'upright') or 'upright'
                        line_confidence = getattr(line, 'recognition_confidence', confidence_score)
                        line_text = getattr(line, 'text', '') or ''
                        
                        bbox = getattr(line, 'bbox', None)
                        bbox_xmin = bbox_ymin = bbox_xmax = bbox_ymax = None
                        if bbox and len(bbox) >= 4:
                            bbox_xmin, bbox_ymin, bbox_xmax, bbox_ymax = bbox
                        
                        # Get segment FK from segment_id mapping
                        # FIX: Use the string segment_id to look up the database segment_id
                        line_segment_id = None
                        seg_id = getattr(line, 'segment_id', None)
                        if seg_id is not None and str(seg_id) != 'None' and str(seg_id) != '':
                            seg_id_str = str(seg_id)
                            line_segment_id = segment_id_map.get(seg_id_str)
                        
                        await conn.execute(
                            '''
                            INSERT INTO "Text_Lines"
                            ("text_id", "line_number", "line_text", "confidence_score",
                            "bbox_xmin", "bbox_ymin", "bbox_xmax", "bbox_ymax",
                            "polygon_coords", "orientation", "line_segment_id")
                            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10::text_line_orientation, $11)
                            ''',
                            text_id, line_num, line_text, line_confidence,
                            bbox_xmin, bbox_ymin, bbox_xmax, bbox_ymax,
                            polygon_json, orientation, line_segment_id
                        )
                    
                    logger.info(f"Saved HTR results: text_id={text_id}, {len(lines)} lines, {len(segment_id_map)} segments")
                    return text_id
                    
        except Exception as e:
            logger.error(f"Failed to save HTR results: {e}")
            raise HTRDatabaseError(f"Failed to save HTR results: {e}") from e

    async def save_detected_languages(self, text_id: int, detections: Dict[str, float]) -> None:
        if not self.pool or not detections:
            return
        try:
            async with self.pool.acquire() as conn:
                async with conn.transaction():
                    # Upsert language codes
                    for lang_code in detections.keys():
                        await conn.execute(
                            'INSERT INTO "Languages" ("lang_code") VALUES ($1) ON CONFLICT ("lang_code") DO NOTHING',
                            lang_code
                        )
                    
                    # Sort by confidence descending, assign ranks
                    sorted_detections = sorted(detections.items(), key=lambda x: x[1], reverse=True)
                    
                    for rank, (lang_code, confidence) in enumerate(sorted_detections):
                        await conn.execute(
                            'INSERT INTO "Text_Language_Detections" ("text_id", "lang_code", "confidence", "rank") VALUES ($1, $2, $3, $4)',
                            text_id, lang_code, max(0.0, min(1.0, float(confidence))), rank
                        )
                    logger.debug(f"Saved {len(detections)} language detections for text {text_id}")
        except Exception as e:
            logger.error(f"Failed to save detected languages: {e}")

    async def update_status(
        self,
        doc_id: int,
        status: str,
        stage: Optional[str] = None,
        error: Optional[str] = None,
        retry_count: Optional[int] = None,
        text_id: Optional[int] = None,
    ) -> None:
        if not self.pool:
            return
        try:
            async with self.pool.acquire() as conn:
                updates = ['"status" = $2', '"updated_at" = CURRENT_TIMESTAMP']
                params: List[Any] = [doc_id, status]
                param_idx = 3
                
                if stage is not None:
                    updates.append(f'"current_stage" = ${param_idx}')
                    params.append(stage)
                    param_idx += 1
                if error is not None:
                    updates.append(f'"error_log" = ${param_idx}')
                    params.append(error)
                    param_idx += 1
                if retry_count is not None:
                    updates.append(f'"retry_count" = ${param_idx}')
                    params.append(retry_count)
                    param_idx += 1
                if text_id is not None:
                    updates.append(f'"text_id" = ${param_idx}')
                    params.append(text_id)
                    
                query = f'UPDATE "Processing_Status" SET {", ".join(updates)} WHERE "document_id" = $1'
                await conn.execute(query, *params)
        except Exception as e:
            logger.error(f"Failed to update status: {e}")

    async def purge_orphaned_documents(self) -> int:
        if not self.pool:
            return 0
        try:
            async with self.pool.acquire() as conn:
                count = await conn.fetchval(
                    '''
                    SELECT COUNT(*) FROM (
                        SELECT d."document_id"
                        FROM "Documents" d
                        LEFT JOIN "Pictures" p ON d."document_id" = p."document_id"
                        WHERE p."picture_id" IS NULL AND d."deleted_at" IS NULL
                    ) AS orphaned
                    '''
                )
                if count > 0:
                    await conn.execute(
                        'DELETE FROM "Documents" WHERE "document_id" IN (SELECT d."document_id" FROM "Documents" d LEFT JOIN "Pictures" p ON d."document_id" = p."document_id" WHERE p."picture_id" IS NULL AND d."deleted_at" IS NULL)'
                    )
                    logger.info(f"Purged {count} orphaned documents")
                return count
        except Exception as e:
            logger.warning(f"Orphan cleanup failed: {e}")
            return 0