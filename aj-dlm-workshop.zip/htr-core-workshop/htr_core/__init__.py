"""
HTR Core Package
================
High-performance Core engine for Handwritten Text Recognition using RF-DETR and TrOCR.
"""
from .core import HTRStandaloneProcessor
from .models import LineResult, RegionResult, TextRegionCategory
from .config import LANGUAGE_MAP

__all__ = [
    "HTRStandaloneProcessor",
    "LineResult",
    "RegionResult",
    "TextRegionCategory",
    "LANGUAGE_MAP",
]