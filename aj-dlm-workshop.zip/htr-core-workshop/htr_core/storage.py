"""
MinIO Storage Handler for ArchXAI HTR.
"""
import os
import logging
from pathlib import Path
from typing import Union
from dotenv import load_dotenv
from minio import Minio
from io import BytesIO
from PIL import Image

# Load environment variables FIRST, before any defaults are read
load_dotenv()

logger = logging.getLogger("htr_core.storage")


class MinIOStorageHandler:
    def __init__(self):
        # Credentials are now properly loaded from .env via load_dotenv() above
        self.access_key = os.getenv("MINIO_ROOT_USER", "archxai_admin")
        self.secret_key = os.getenv("MINIO_ROOT_PASSWORD", "archxai_secure_password_123")
        self.endpoint = os.getenv("MINIO_ENDPOINT", "localhost:9000")
        self.bucket_name = os.getenv("MINIO_BUCKET", "archxai-images")
        
        try:
            self.client = Minio(
                self.endpoint,
                access_key=self.access_key,
                secret_key=self.secret_key,
                secure=False
            )
            logger.info(f"MinIO client initialized. Endpoint: {self.endpoint}")
        except Exception as e:
            logger.error(f"Failed to initialize MinIO client: {e}")
            raise

    def ensure_bucket(self):
        """Ensures the bucket exists. THIS METHOD IS MANDATORY."""
        try:
            if not self.client.bucket_exists(self.bucket_name):
                self.client.make_bucket(self.bucket_name)
                logger.info(f"Created bucket: {self.bucket_name}")
            else:
                logger.debug(f"Bucket {self.bucket_name} already exists.")
        except Exception as e:
            logger.error(f"Error ensuring MinIO bucket: {e}")
            raise

    def upload_image(self, image_input: Union[str, Path, bytes, Image.Image], file_hash: str) -> str:
        object_name = f"{file_hash}.jpg"
        
        # Skip if already exists in MinIO
        try:
            if self.client.stat_object(self.bucket_name, object_name):
                logger.info(f"Image {file_hash[:10]} already in MinIO. Skipping upload.")
                return object_name
        except Exception:
            # Object doesn't exist — proceed with upload
            pass

        try:
            if isinstance(image_input, (str, Path)):
                self.client.fput_object(self.bucket_name, object_name, str(image_input))
            elif isinstance(image_input, bytes):
                self.client.put_object(
                    self.bucket_name, object_name, 
                    BytesIO(image_input), len(image_input), "image/jpeg"
                )
            elif isinstance(image_input, Image.Image):
                buf = BytesIO()
                image_input.convert("RGB").save(buf, format="JPEG")
                buf.seek(0)
                self.client.put_object(
                    self.bucket_name, object_name, 
                    buf, buf.getbuffer().nbytes, "image/jpeg"
                )
            return object_name
        except Exception as e:
            logger.error(f"MinIO upload failed for {object_name}: {e}")
            raise

    def delete_image(self, object_name: str) -> bool:
        """
        Deletes an image from MinIO.
        
        Returns:
            True if deletion succeeded or object didn't exist.
            False if deletion failed.
        """
        try:
            self.client.remove_object(self.bucket_name, object_name)
            logger.info(f"Deleted object {object_name} from MinIO")
            return True
        except Exception as e:
            logger.error(f"Failed to delete object {object_name} from MinIO: {e}")
            return False

    def get_public_url(self, object_name: str) -> str:
        """Returns the public URL for an image."""
        return f"http://{self.endpoint}/{self.bucket_name}/{object_name}"
    
    def upload_boxed_image(self, boxed_image: Image.Image, file_hash: str) -> str:
        """
        Uploads the visualized boxed image to MinIO.
        Naming convention: {file_hash}_segments.jpg
        """
        object_name = f"{file_hash}_segments.jpg"
        try:
            buf = BytesIO()
            boxed_image.convert("RGB").save(buf, format="JPEG")
            buf.seek(0)
            
            self.client.put_object(
                self.bucket_name, 
                object_name, 
                buf, 
                buf.getbuffer().nbytes, 
                "image/jpeg"
            )
            return object_name
        except Exception as e:
            logger.error(f"MinIO boxed image upload failed for {object_name}: {e}")
            raise