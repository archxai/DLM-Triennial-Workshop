# htr_core/core.py
from __future__ import annotations

import os
import time
from threading import Lock
from typing import Any, Dict, List, Optional, Tuple

import cv2
import numpy as np
import torch
from huggingface_hub import hf_hub_download
from PIL import Image

from .config import DEFAULT_DETECTION_FILENAME, DEFAULT_DETECTION_REPO_ID, get_language_config
from .models import LineResult
from .processing import crop_line_with_polygon
from .recognition_backends import RecognitionResult, create_backend
from .segmentation import SegmentImage
import logging

logger = logging.getLogger(__name__)

_DET: Dict[str, Any] = {}
_LOCK = Lock()


class HTRStandaloneProcessor:
    def __init__(
        self,
        language: str,
        device: Optional[str] = None,
        mode='Balanced',
    ):
        self.language = language.lower()

        self.spec = get_language_config(
            language
        )

        # Force CPU if CUDA is not available
        # or explicitly requested
        if device is None:
            self.device = 'cpu'
        else:
            self.device = device

        self.mode = mode

        self.threshold = {
            'Fast': .18,
            'Balanced': .15,
            'Accurate': .12,
        }.get(
            mode,
            .15,
        )

        # Optimize CPU threads
        if self.device == 'cpu':
            cpu_count = (
                os.cpu_count()
                or 4
            )

            torch.set_num_threads(
                min(
                    32,
                    cpu_count,
                )
            )

        # Create recognition backend from languages.json.
        #
        # local-pytorch -> PyTorch backend
        # local-onnx    -> local ONNX backend
        # remote-onnx   -> remote recognition service
        self.recognizer = create_backend(
            self.spec,
            self.device,
        )

        logger.info(
            "Recognition backend initialized "
            "for language=%s backend=%s repo=%s",
            self.language,
            self.spec.get("backend"),
            self.spec.get("repo"),
        )
    
    def _segmenter(self):
        key = f'{self.device}:{self.threshold}'
        with _LOCK:
            if key not in _DET:
                weights = hf_hub_download(
                    repo_id=DEFAULT_DETECTION_REPO_ID,
                    filename=DEFAULT_DETECTION_FILENAME
                )
                _DET[key] = SegmentImage(
                    str(weights),
                    max_size=768,
                    confidence_threshold=self.threshold,
                    device=self.device
                )
            return _DET[key]
    
    async def process_async(self, image: Image.Image, merge_lines=True) -> Tuple[List[LineResult], float, Dict[str, Any]]:
        """Process image through HTR pipeline."""
        start = time.perf_counter()
        arr = np.asarray(image.convert('RGB'))
        
        # Time detection
        d0 = time.perf_counter()
        seg_result = self._segmenter().get_segmentation(arr)
        d1 = time.perf_counter()
        
        if seg_result is None:
            return [], 0.0, {
                'total_time': 0, 'det_time': 0, 'rec_time': 0,
                'detections': 0, 'final_lines': 0,
                'segments': [], 'img_shape': None,
            }
        
        lines_data = seg_result.get('lines', [])
        segments_data = seg_result.get('regions', [])
        img_shape = seg_result.get('img_shape', (arr.shape[0], arr.shape[1]))
        
        logger.info(f"Segmentation found {len(lines_data)} lines, image shape: {img_shape}")
        
        # Crop line regions from image
        crops = []
        valid_lines = []
        crop_failures = 0
        
        for idx, row in enumerate(lines_data):
            coords = row.get('coords')
            
            # Validate coordinates
            if coords is None:
                logger.debug(f"Line {idx}: coords is None")
                crop_failures += 1
                continue
            
            if not isinstance(coords, (list, np.ndarray)):
                logger.debug(f"Line {idx}: coords is not a list/array, got {type(coords)}")
                crop_failures += 1
                continue
            
            if len(coords) < 3:
                logger.debug(f"Line {idx}: coords has < 3 points: {len(coords)}")
                crop_failures += 1
                continue
            
            # Try to crop
            crop = crop_line_with_polygon(arr, coords)
            if crop is not None and crop.size > 0:
                crops.append(Image.fromarray(crop))
                valid_lines.append(row)
            else:
                # Debug: log why cropping failed
                try:
                    polygon_array = np.array([[int(pt[0]), int(pt[1])] for pt in coords], dtype=np.int32)
                    x, y, w, h = cv2.boundingRect(polygon_array)
                    logger.debug(
                        f"Line {idx}: crop failed - bbox=({x},{y},{w},{h}), "
                        f"img_shape={arr.shape}, coords_sample={coords[:2]}"
                    )
                except Exception as e:
                    logger.debug(f"Line {idx}: crop failed - coords error: {e}")
                crop_failures += 1
        
        logger.info(
            f"Cropping results: {len(crops)} successful, {crop_failures} failed, "
            f"out of {len(lines_data)} detected lines"
        )
        
        if not crops:
            logger.warning("No valid crops generated from detected lines")
            return [], 0.0, {
                'total_time': time.perf_counter() - start,
                'det_time': d1 - d0,
                'rec_time': 0,
                'detections': len(lines_data),
                'final_lines': 0,
                'crops_processed': 0,
                'avg_confidence': 0.0,
                'segments': segments_data,
                'img_shape': img_shape,
            }
        
        # Time recognition
        r0 = time.perf_counter()
        recognized = await self.recognizer.recognize_batch(crops)
        r1 = time.perf_counter()
        
        logger.info(f"Recognition results: {len(recognized)} items for {len(crops)} crops")
        
        # Build line results - properly handle RecognitionResult
        lines = []
        for idx, (row, result) in enumerate(zip(valid_lines, recognized)):
            # Handle both RecognitionResult and tuple formats
            if isinstance(result, RecognitionResult):
                text = result.text or ""
                confidence = result.confidence or 0.0
            elif isinstance(result, tuple):
                text = result[0] or ""
                confidence = float(result[1]) if len(result) > 1 else 0.0
            else:
                text = str(result) if result else ""
                confidence = 0.0
            
            logger.info(f"Line {idx}: text='{text[:30]}...', confidence={confidence}")

            # Only add if there's actual text
            if text and text.strip():
                # Safe extraction of bbox - ensure it's a proper 4-tuple of ints
                raw_bbox = row.get('bbox')
                if raw_bbox and len(raw_bbox) == 4:
                    bbox = tuple(int(x) for x in raw_bbox)
                else:
                    bbox = (0, 0, 0, 0)

                # Safe extraction of region_bbox
                raw_region_bbox = row.get('region_bbox')
                if raw_region_bbox and len(raw_region_bbox) == 4:
                    region_bbox = tuple(int(x) for x in raw_region_bbox)
                else:
                    region_bbox = None

                lines.append(LineResult(
                    line_number=len(lines) + 1,
                    text=text.strip(),
                    bbox=bbox,
                    detection_confidence=float(row.get('confidence', 1.0)),
                    recognition_confidence=confidence,
                    segment_id=str(row.get('segment_id', '0')),
                    polygon=row.get('coords'),
                    orientation=row.get('orientation', 'upright'),
                    region_bbox=region_bbox,
                    region_polygon=row.get('segment_coords'),
                ))
        
        logger.info(f"Built {len(lines)} LineResult objects with non-empty text")
        
        avg = float(np.mean([x.recognition_confidence for x in lines])) if lines else 0.0
        
        metrics = {
            'total_time': time.perf_counter() - start,
            'det_time': d1 - d0,
            'rec_time': r1 - r0,
            'detections': len(lines_data),
            'final_lines': len(lines),
            'crops_processed': len(crops),
            'avg_confidence': avg,
            'segments': segments_data,
            'img_shape': img_shape,
        }
        
        return lines, avg, metrics
    
    def generate_visualization(self, image, lines, segments=None):
        """Generate visualization with detected regions and lines."""
        canvas = cv2.cvtColor(np.array(image.convert('RGB')), cv2.COLOR_RGB2BGR)
        
        # Draw regions first
        if segments:
            overlay = canvas.copy()
            region_color = (144, 238, 144)  # Light green
            region_outline = (0, 128, 0)    # Dark green
            
            for seg in segments:
                coords = seg.get('region_coords', seg.get('coords', []))
                if coords and len(coords) >= 3:
                    pts = np.asarray(coords, dtype=np.int32)
                    cv2.fillPoly(overlay, [pts], region_color)
            
            cv2.addWeighted(overlay, 0.3, canvas, 0.7, 0, canvas)
            
            for seg in segments:
                coords = seg.get('region_coords', seg.get('coords', []))
                if coords and len(coords) >= 3:
                    pts = np.asarray(coords, dtype=np.int32)
                    cv2.polylines(canvas, [pts], True, region_outline, 2, cv2.LINE_AA)
                    x, y = pts[0]
                    cv2.putText(canvas, f"R{seg.get('region_number', '?')}", 
                               (x + 5, y + 20), cv2.FONT_HERSHEY_SIMPLEX, 
                               0.7, region_outline, 2)
        
        # Draw lines
        line_color = (0, 165, 255)  # Orange
        for line in lines:
            pts = np.asarray(line.polygon or [], dtype=np.int32)
            if len(pts) >= 3:
                cv2.polylines(canvas, [pts], True, line_color, 2, cv2.LINE_AA)
            else:
                x1, y1, x2, y2 = line.bbox
                cv2.rectangle(canvas, (x1, y1), (x2, y2), line_color, 2)
        
        return Image.fromarray(cv2.cvtColor(canvas, cv2.COLOR_BGR2RGB))
    
    def get_model_metadata(self):
        return self.recognizer.get_model_metadata()
    
    async def close(self):
        await self.recognizer.close()