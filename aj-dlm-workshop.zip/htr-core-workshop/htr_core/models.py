# htr_core/models.py
from __future__ import annotations

from enum import Enum
from typing import List, Optional, Tuple
from pydantic import BaseModel, ConfigDict


class TextRegionCategory(str, Enum):
    """RF-DETR detection categories for text regions and lines."""
    TEXT_REGION = "text_region"
    TEXT_LINE_UPRIGHT = "text_line_upright"
    TEXT_LINE_UPSIDE_DOWN = "text_line_upside_down"
    TEXT_LINE_ROTATED_CW = "text_line_rotated_cw"
    TEXT_LINE_ROTATED_CCW = "text_line_rotated_ccw"


class RegionResult(BaseModel):
    """Result model for a detected text region (container/column)."""
    model_config = ConfigDict(arbitrary_types_allowed=True)

    region_number: int
    category: TextRegionCategory
    coords: List[List[float]]  # Polygon coordinates [[x1,y1], [x2,y2], ...]
    bbox: Tuple[int, int, int, int]  # (xmin, ymin, xmax, ymax)
    confidence: float
    line_count: int = 0


class LineResult(BaseModel):
    """
    Result model for a detected and recognized text line.
    
    Attributes:
        line_number: Sequential line number in reading order (1-based)
        text: Recognized text content
        bbox: Bounding box (xmin, ymin, xmax, ymax) in image coordinates
        detection_confidence: RF-DETR detection model confidence score [0, 1]
        recognition_confidence: TrOCR recognition confidence score [0, 1]
        segment_id: ID of the parent text region (from RF-DETR, coordinate-based hash)
        polygon: Line polygon coordinates [[x1,y1], [x2,y2], ...]
        orientation: Text line orientation (upright, upside_down, rotated_cw, rotated_ccw)
        region_bbox: Bounding box of the parent text region (xmin, ymin, xmax, ymax)
        region_polygon: Polygon coordinates of the parent text region
    """
    model_config = ConfigDict(arbitrary_types_allowed=True)

    line_number: int
    text: str
    bbox: Tuple[int, int, int, int]  # (xmin, ymin, xmax, ymax)
    detection_confidence: float
    recognition_confidence: float
    segment_id: Optional[str] = None  # Parent region ID (coordinate-based hash)
    polygon: Optional[List[List[float]]] = None  # Line polygon coordinates
    orientation: str = "upright"
    region_bbox: Optional[Tuple[int, int, int, int]] = None  # Parent region bbox
    region_polygon: Optional[List[List[float]]] = None  # Parent region polygon

    @property
    def confidence(self) -> float:
        """Alias for recognition_confidence for backward compatibility."""
        return self.recognition_confidence