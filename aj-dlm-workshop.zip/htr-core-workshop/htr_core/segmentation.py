# htr_core/segmentation.py
"""
Document image segmentation for detecting text regions and lines.
Based on: https://huggingface.co/spaces/Kansallisarkisto/Multicentury-HTR-Demo
"""
import logging
import os
from collections import defaultdict
from typing import Dict, List, Optional, Tuple, Any

import cv2
import numpy as np
from shapely.geometry import Polygon, Point
from shapely.validation import make_valid

from rfdetr import RFDETRSeg2XLarge

from .models import TextRegionCategory, RegionResult, LineResult
from .processing import preprocess_resize_torch_transform
from .reading_order import GraphBasedOrdering

logger = logging.getLogger(__name__)

# RF-DETR class IDs
CLASS_ID_REGION = 1
CLASS_ID_LINE_UPRIGHT = 2
CLASS_ID_LINE_UPSIDE_DOWN = 3
CLASS_ID_LINE_ROTATED_CW = 4
CLASS_ID_LINE_ROTATED_CCW = 5

CLASS_ID_TO_ORIENTATION: Dict[int, str] = {
    CLASS_ID_LINE_UPRIGHT: "upright",
    CLASS_ID_LINE_UPSIDE_DOWN: "upside_down",
    CLASS_ID_LINE_ROTATED_CW: "rotated_cw",
    CLASS_ID_LINE_ROTATED_CCW: "rotated_ccw",
}

_ordering = GraphBasedOrdering(text_direction="lr")


class SegmentImage:
    def __init__(
        self,
        model_path: str,
        max_size: int = 768,
        confidence_threshold: float = 0.15,
        line_percentage_threshold: float = 7e-05,
        region_percentage_threshold: float = 7e-05,
        line_iou: float = 0.3,
        region_iou: float = 0.3,
        line_overlap_threshold: float = 0.5,
        region_overlap_threshold: float = 0.5,
        class_id_region: int = CLASS_ID_REGION,
        class_id_line: int = CLASS_ID_LINE_UPRIGHT,
        min_polygon_points: int = 3,
        device: str = "cpu",  # Changed from "cuda:0" to "cpu"
    ):
        self.model_path = model_path
        self.max_size = max_size
        self.confidence_threshold = confidence_threshold
        self.line_percentage_threshold = line_percentage_threshold
        self.region_percentage_threshold = region_percentage_threshold
        self.line_iou = line_iou
        self.region_iou = region_iou
        self.line_overlap_threshold = line_overlap_threshold
        self.region_overlap_threshold = region_overlap_threshold
        self.class_id_region = class_id_region
        self.class_id_line = class_id_line
        self.min_polygon_points = min_polygon_points
        self.device = device

        if not os.path.exists(model_path):
            raise FileNotFoundError(f"Model path does not exist: {model_path}")

        self.init_model()

    def init_model(self) -> None:
        """Load and optimise RFDETR segmentation model."""
        try:
            self.model = RFDETRSeg2XLarge(
                pretrain_weights=self.model_path, device=self.device
            )
            if self.device != "cpu":
                self.model.optimize_for_inference()
            logger.info("✓ Segmentation model initialised successfully")
        except Exception as e:
            raise RuntimeError(f"Failed to initialise segmentation model: {e}")

    def validate_polygon(self, polygon: np.ndarray) -> Optional[Polygon]:
        """Test and correct polygon validity using Shapely."""
        if len(polygon) > 2:
            try:
                shapely_polygon = Polygon(polygon)
                if not shapely_polygon.is_valid:
                    shapely_polygon = make_valid(shapely_polygon)
                return shapely_polygon
            except Exception:
                return None
        return None

    def get_iou(self, poly1_coords: List, poly2_coords: List) -> float:
        """Calculate Intersection over Union between two polygons."""
        poly1 = self.validate_polygon(np.array(poly1_coords))
        poly2 = self.validate_polygon(np.array(poly2_coords))
        
        if not poly1 or not poly2:
            return 0.0
        
        if not poly1.intersects(poly2):
            return 0.0
        
        intersection = poly1.intersection(poly2).area
        union = poly1.union(poly2).area
        
        return intersection / union if union > 0 else 0.0

    def merge_polygons(
        self,
        polygons: List[np.ndarray],
        polygon_iou: float,
        overlap_threshold: float,
    ) -> Tuple[List[np.ndarray], List[int]]:
        """Merge overlapping polygons using union-find algorithm."""
        n = len(polygons)
        if n == 0:
            return [], []

        validated = [self.validate_polygon(p) for p in polygons]
        parent = list(range(n))

        def find(x: int) -> int:
            if parent[x] != x:
                parent[x] = find(parent[x])
            return parent[x]

        def union(x: int, y: int) -> None:
            px, py = find(x), find(y)
            if px != py:
                parent[px] = py

        for i in range(n):
            poly1 = validated[i]
            if not poly1:
                continue
            for j in range(i + 1, n):
                poly2 = validated[j]
                if not poly2 or not poly1.intersects(poly2):
                    continue
                intersection = poly1.intersection(poly2)
                union_geom = poly1.union(poly2)
                iou = intersection.area / union_geom.area if union_geom.area > 0 else 0
                should_merge = iou > polygon_iou
                if not should_merge and overlap_threshold > 0:
                    smaller_area = min(poly1.area, poly2.area)
                    overlap_ratio = intersection.area / smaller_area if smaller_area > 0 else 0
                    should_merge = overlap_ratio > overlap_threshold
                if should_merge:
                    union(i, j)

        components = defaultdict(list)
        for i in range(n):
            if validated[i]:
                components[find(i)].append(i)

        merged_polygons = []
        for root, indices in components.items():
            if len(indices) == 1:
                merged_polygons.append(polygons[indices[0]])
            else:
                merged = validated[indices[0]]
                for idx in indices[1:]:
                    merged = merged.union(validated[idx])
                if merged.geom_type == "Polygon":
                    coords = np.array(merged.exterior.coords)
                    if len(coords) > 3 and np.array_equal(coords[0], coords[-1]):
                        coords = coords[:-1]
                    merged_polygons.append(coords.astype(np.int32))
                elif merged.geom_type in ["MultiPolygon", "GeometryCollection"]:
                    for geom in merged.geoms:
                        if geom.geom_type == "Polygon":
                            coords = np.array(geom.exterior.coords)
                            if len(coords) > 3 and np.array_equal(coords[0], coords[-1]):
                                coords = coords[:-1]
                            merged_polygons.append(coords.astype(np.int32))

        return merged_polygons, []

    def calculate_polygon_area(self, vertices: np.ndarray) -> float:
        """Calculate polygon area using the Shoelace formula."""
        if len(vertices) < 3:
            return 0.0
        x, y = vertices[:, 0], vertices[:, 1]
        return 0.5 * np.abs(
            np.sum(x[:-1] * y[1:]) - np.sum(y[:-1] * x[1:]) + x[-1] * y[0] - y[-1] * x[0]
        )

    def mask_to_polygon_cv2(
        self, mask: np.ndarray, original_shape: Tuple[int, int]
    ) -> Tuple[List[np.ndarray], np.ndarray]:
        """Convert a binary segmentation mask to polygon coordinates."""
        mask_uint8 = mask.astype(np.uint8) * 255 if mask.dtype == bool else mask.astype(np.uint8)
        
        contours, _ = cv2.findContours(mask_uint8, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        polygons = []
        for contour in contours:
            pts = contour.squeeze()
            if pts.ndim == 1:
                continue
            if len(pts) >= self.min_polygon_points:
                polygons.append(pts)

        orig_h, orig_w = original_shape[:2]
        mask_h, mask_w = mask.shape[:2]
        
        scale_x = orig_w / mask_w if mask_w > 0 else 1.0
        scale_y = orig_h / mask_h if mask_h > 0 else 1.0

        scaled_polygons = []
        area_percentages = []
        mask_area = mask_h * mask_w

        for poly in polygons:
            if poly.ndim == 1:
                poly = poly.reshape(1, -1)
            
            area = self.calculate_polygon_area(poly)
            area_percentages.append(area / mask_area if mask_area > 0 else 0)
            
            scaled = np.round(poly * np.array([scale_x, scale_y])).astype(int)
            scaled_polygons.append(scaled)

        return scaled_polygons, np.array(area_percentages) if area_percentages else np.array([])

    def process_polygons(
        self,
        poly_masks: np.ndarray,
        image_shape: Tuple[int, int],
        percentage_threshold: float,
        overlap_threshold: float,
        iou_threshold: float,
        debug_name: str = "polygons"
    ) -> Tuple[List[np.ndarray], List[Tuple[int, int, int, int]]]:
        """Extract polygons from masks, filter by area, and merge."""
        all_polygons, all_area_percentages = [], []

        for mask in poly_masks:
            polygons, area_percentages = self.mask_to_polygon_cv2(
                mask=mask, original_shape=image_shape
            )
            all_polygons.extend(polygons)
            all_area_percentages.extend(area_percentages)

        if not all_area_percentages:
            return [], []

        all_area_percentages = np.array(all_area_percentages)
        if len(all_area_percentages) == 0:
            return [], []

        valid_indices = np.where(all_area_percentages > percentage_threshold)[0]
        filtered_polygons = [all_polygons[idx] for idx in valid_indices]

        if not filtered_polygons:
            return [], []

        merged_polygons, _ = self.merge_polygons(
            filtered_polygons, iou_threshold, overlap_threshold
        )

        merged_max_mins = []
        for poly in merged_polygons:
            if len(poly) > 0:
                xmax, ymax = np.max(poly, axis=0)
                xmin, ymin = np.min(poly, axis=0)
                merged_max_mins.append((int(xmin), int(ymin), int(xmax), int(ymax)))

        return merged_polygons, merged_max_mins

    def get_segmentation(self, image: np.ndarray) -> Optional[Dict[str, Any]]:
        """
        Detect and extract ordered text regions and lines.
        
        Returns:
            Dict with:
              - 'regions': list of region dicts
              - 'lines': list of line dicts with coords, bbox, segment_id
              - 'img_shape': image dimensions
        """
        image_shape = (image.shape[0], image.shape[1])
        preprocessed_image = preprocess_resize_torch_transform(image, max_size=self.max_size)

        try:
            detections = self.model.predict(preprocessed_image, threshold=self.confidence_threshold)
        except Exception as e:
            logger.error(f"Error during segmentation prediction: {e}")
            return None

        # Separate masks by class ID
        all_class_ids = detections.class_id
        all_masks = detections.mask

        region_mask = all_masks[all_class_ids == self.class_id_region]
        line_mask_indices = np.where(all_class_ids != self.class_id_region)[0]
        line_masks = all_masks[line_mask_indices]

        logger.info(f"RF-DETR: {len(region_mask)} region masks, {len(line_masks)} line masks")

        # Process both regions and lines with merging
        merged_region_polygons, merged_region_max_mins = self.process_polygons(
            region_mask,
            image_shape,
            self.region_percentage_threshold,
            self.region_overlap_threshold,
            self.region_iou,
            "regions"
        )

        merged_line_polygons, merged_line_max_mins = self.process_polygons(
            line_masks,
            image_shape,
            self.line_percentage_threshold,
            self.line_overlap_threshold,
            self.line_iou,
            "lines"
        )

        if not merged_line_polygons:
            logger.warning("No text lines detected from image.")
            return None

        # Build region list with COORDINATE-BASED IDs (not index-based)
        # Use a hash of coordinates as stable ID
        regions = []
        for i, (poly, bbox) in enumerate(zip(merged_region_polygons, merged_region_max_mins)):
            coords = poly.tolist() if hasattr(poly, "tolist") else poly
            # Create a stable ID based on first coordinate
            coord_hash = f"{coords[0][0]:.0f}_{coords[0][1]:.0f}" if coords else str(i)
            regions.append({
                "id": coord_hash,  # Stable ID based on coordinates
                "coords": coords,
                "bbox": bbox,
                "img_shape": image_shape,
            })

        # Connect each line to a region using IoU
        lines_raw = []
        for i, (poly, bbox) in enumerate(zip(merged_line_polygons, merged_line_max_mins)):
            coords = poly.tolist() if hasattr(poly, "tolist") else poly
            
            best_iou = 0
            best_region_id = regions[0]["id"] if regions else "default"
            
            for region in regions:
                iou = self.get_iou(coords, region["coords"])
                if iou > best_iou:
                    best_iou = iou
                    best_region_id = region["id"]
            
            # If no intersection, find closest region
            if best_iou == 0 and regions:
                line_poly = self.validate_polygon(np.array(coords))
                if line_poly:
                    best_dist = float('inf')
                    for region in regions:
                        reg_poly = self.validate_polygon(np.array(region["coords"]))
                        if reg_poly:
                            dist = line_poly.distance(reg_poly)
                            if dist < best_dist:
                                best_dist = dist
                                best_region_id = region["id"]

            lines_raw.append({
                "polygon": coords,
                "reg_id": best_region_id,  # Now uses coordinate-based stable ID
                "bbox": bbox,
                "orientation": "upright",
            })

        # Filter to only regions that contain at least one line
        regions_with_lines = []
        for region in regions:
            has_lines = any(ln["reg_id"] == region["id"] for ln in lines_raw)
            if has_lines:
                regions_with_lines.append(region)
        
        # If no regions with lines, create default full-page region
        if not regions_with_lines:
            w, h = image_shape[1], image_shape[0]
            default_region = {
                "id": "default",
                "coords": [[0, 0], [w, 0], [w, h], [0, h]],
                "bbox": (0, 0, w, h),
                "img_shape": image_shape,
            }
            regions_with_lines.append(default_region)
            for ln in lines_raw:
                ln["reg_id"] = "default"
        
        logger.info(f"Regions with lines: {len(regions_with_lines)}, Total lines: {len(lines_raw)}")

        # Order lines within each region and order regions
        region_max_mins = []
        for region in regions_with_lines:
            line_max_mins = [ln["bbox"] for ln in lines_raw if ln["reg_id"] == region["id"]]
            if line_max_mins:
                region_max_mins.append(region["bbox"])
            else:
                region_max_mins.append(None)
        
        # Order regions
        valid_region_indices = [i for i, m in enumerate(region_max_mins) if m is not None]
        if valid_region_indices:
            ordered_indices = _ordering.order([regions_with_lines[i]["bbox"] for i in valid_region_indices])
            regions_with_lines = [regions_with_lines[valid_region_indices[i]] for i in ordered_indices]
        
        # Build output - use coordinate-based IDs that won't change
        all_lines = []
        line_number = 1
        
        for reg in regions_with_lines:
            # Get all lines for this region using stable ID
            lines_in_region = [ln for ln in lines_raw if ln["reg_id"] == reg["id"]]
            
            # Order lines within region by y-coordinate (top to bottom)
            if lines_in_region:
                lines_in_region = sorted(lines_in_region, key=lambda x: x["bbox"][1])
            
            for ln in lines_in_region:
                polygon = ln.get("polygon", [])
                if not polygon:
                    polygon = [[0, 0], [1, 0], [1, 1], [0, 1]]
                
                all_lines.append({
                    "line_number": line_number,
                    "coords": polygon,
                    "bbox": ln["bbox"],
                    "segment_id": reg["id"],  # Use stable coordinate-based ID
                    "segment_coords": reg["coords"],
                    "orientation": ln.get("orientation", "upright"),
                })
                line_number += 1

        # Build regions output for visualization
        regions_out = []
        for reg in regions_with_lines:
            lines_in_region = [ln for ln in lines_raw if ln["reg_id"] == reg["id"]]
            if lines_in_region:
                lines_in_region = sorted(lines_in_region, key=lambda x: x["bbox"][1])
            
            regions_out.append({
                "region_number": len(regions_out) + 1,
                "region_coords": reg["coords"],
                "bbox": reg["bbox"],
                "img_shape": reg["img_shape"],
                "line_coords": [ln["polygon"] for ln in lines_in_region],
                "lines": lines_in_region,
            })

        logger.info(f"Final output: {len(all_lines)} lines in {len(regions_out)} regions")

        return {
            "regions": regions_out,
            "lines": all_lines,
            "img_shape": image_shape,
        }