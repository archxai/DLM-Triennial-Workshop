"""Graph-Based Reading Order Algorithm.

Mirrors the logic from Kansallisarkisto/Multicentury-HTR-Demo reading_order.py.
Uses Kahn's topological sort to determine the correct reading order of polygons
(Lines or Regions) by analysing vertical overlap and horizontal position.
"""
from collections import defaultdict, deque
from typing import List


class GraphBasedOrdering:
    """
    Graph-Based Reading Order Algorithm using Kahn's topological sort.

    Determines the reading order of polygons by:
    1. Comparing each pair of polygons to decide precedence.
    2. Building a directed graph of those relationships.
    3. Finding a topological ordering of the graph.

    The key rule (matches the reference):
    - If two elements have vertical overlap > 50% of their average height,
      they are on the same reading row → order by x position (left-to-right).
    - Otherwise they are on different rows → order by y position (top-to-bottom).

    This works correctly for multi-column layouts because column regions
    that share the same vertical band get ordered by x, not grouped by region.
    """

    def __init__(self, text_direction: str = "lr") -> None:
        self.text_direction = text_direction

    def _get_features(self, bbox: List[float]) -> dict:
        """
        Extract spatial features from a bounding box.

        Args:
            bbox: [xmin, ymin, xmax, ymax]

        Returns:
            dict with center, x_min, x_max, y_min, y_max, width, height
        """
        x_min, y_min, x_max, y_max = bbox
        return {
            "center": ((x_min + x_max) / 2, (y_min + y_max) / 2),
            "x_min": x_min,
            "x_max": x_max,
            "y_min": y_min,
            "y_max": y_max,
            "width": x_max - x_min,
            "height": y_max - y_min,
        }

    def _should_precede(self, a_feat: dict, b_feat: dict) -> bool:
        """
        Decide whether element A should come before element B in reading order.

        Matching the Multicentury-HTR-Demo reference exactly:
        - Same row (vertical overlap > 50% of avg height) → x-order
        - Different rows → y-order
        """
        a_center = a_feat["center"]
        b_center = b_feat["center"]

        v_overlap = min(a_feat["y_max"], b_feat["y_max"]) - max(a_feat["y_min"], b_feat["y_min"])
        avg_height = (a_feat["height"] + b_feat["height"]) / 2

        # If significant vertical overlap → same reading row → horizontal order
        if v_overlap > 0.5 * avg_height:
            if self.text_direction == "lr":
                return a_center[0] < b_center[0]
            else:
                return a_center[0] > b_center[0]

        # Otherwise → top-to-bottom row order
        return a_center[1] < b_center[1]

    def order(self, bboxes: List[List[float]]) -> List[int]:
        """
        Compute the reading-order index list for a list of bboxes.

        Args:
            bboxes: List of [xmin, ymin, xmax, ymax] bounding boxes

        Returns:
            List of original indices in reading order.
            If input is empty returns [].

        Algorithm (Kahn's topological sort):
        1. Build directed graph where edge i→j means "i precedes j".
        2. In-degree = number of predecessors for each node.
        3. Repeatedly remove nodes with in-degree 0 (no predecessors).
        4. If any nodes remain (cycle), fall back to position sort.
        """
        if not bboxes:
            return []

        n = len(bboxes)
        features = [self._get_features(bbox) for bbox in bboxes]

        # Build adjacency list and in-degree array
        graph: dict = defaultdict(list)
        in_degree = [0] * n

        for i in range(n):
            for j in range(i + 1, n):
                if self._should_precede(features[i], features[j]):
                    graph[i].append(j)
                    in_degree[j] += 1
                else:
                    graph[j].append(i)
                    in_degree[i] += 1

        # Kahn's topological sort
        queue = deque([i for i in range(n) if in_degree[i] == 0])
        result: List[int] = []

        while queue:
            node = queue.popleft()
            result.append(node)
            for neighbor in graph[node]:
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    queue.append(neighbor)

        # Fallback for cycles or disconnected components
        if len(result) < n:
            missing = set(range(n)) - set(result)
            missing_sorted = sorted(
                missing,
                key=lambda i: (features[i]["center"][1], features[i]["center"][0]),
            )
            result.extend(missing_sorted)

        return result