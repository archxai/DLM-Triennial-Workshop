class HTRCoreError(Exception): pass
class HTRInferenceError(HTRCoreError): pass
class HTRDatabaseError(HTRCoreError): pass
