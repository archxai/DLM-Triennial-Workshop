from __future__ import annotations
import asyncio, io
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, Sequence
import httpx
from PIL import Image
from .recognition import TextRecognition
@dataclass(frozen=True)
class RecognitionResult:
 text:str
 confidence:float
 error:str|None=None
class RecognitionBackend(ABC):
 @abstractmethod
 async def recognize_batch(self,images:Sequence[Image.Image])->list[RecognitionResult]:...
 @abstractmethod
 def get_model_metadata(self)->Dict[str,Any]:...
 async def close(self):pass
class LocalRecognitionBackend(RecognitionBackend):
 def __init__(self,repo,device,backend):self.recognizer=TextRecognition(repo,device=device,force_backend=backend)
 async def recognize_batch(self,images):
  raw=await asyncio.to_thread(self.recognizer.recognize_batch,list(images))
  return [RecognitionResult(t,float(c)) for t,c in raw]
 def get_model_metadata(self):return self.recognizer.get_model_metadata()
class RemoteRecognitionBackend(RecognitionBackend):
 def __init__(self,endpoint,repo,timeout=180):
  self.endpoint=endpoint.rstrip('/');self.repo=repo
  self.client=httpx.AsyncClient(timeout=httpx.Timeout(float(timeout),connect=15))
  self.meta={"model_id":repo,"backend":"remote-onnx","format":"ONNX"}
 async def recognize_batch(self,images):
  if not images:return []
  files=[]
  for i,img in enumerate(images):
   b=io.BytesIO();img.convert('RGB').save(b,'PNG');files.append(('files',(f'line_{i:05d}.png',b.getvalue(),'image/png')))
  try:r=await self.client.post(self.endpoint+'/recognize-lines',files=files);r.raise_for_status()
  except httpx.HTTPError as e:raise RuntimeError(f"Remote recognition unavailable: {e}") from e
  data=r.json();rows=data.get('results',[])
  if len(rows)!=len(images):raise RuntimeError(f"Remote service returned {len(rows)} results for {len(images)} inputs")
  indexed={int(x['index']):x for x in rows}
  if set(indexed)!=set(range(len(images))):raise RuntimeError('Remote service returned invalid line indices')
  self.meta=data.get('model',self.meta)
  return [RecognitionResult(str(indexed[i].get('text','')),float(indexed[i].get('confidence',0)),indexed[i].get('error')) for i in range(len(images))]
 def get_model_metadata(self):return dict(self.meta)
 async def close(self):await self.client.aclose()
def create_backend(spec,device):
 if spec['backend']=='remote-onnx':return RemoteRecognitionBackend(spec['endpoint'],spec['repo'],spec.get('timeout',180))
 return LocalRecognitionBackend(spec['repo'],device,'onnx' if spec['backend']=='local-onnx' else 'pytorch')
