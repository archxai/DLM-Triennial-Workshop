# htr_core/config.py
from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any, Dict


logger = logging.getLogger("htr_core.config")


# =============================================================================
# Segmentation configuration
# =============================================================================

SEGMENTATION_MAX_SIZE = 768
SEGMENTATION_CONFIDENCE_THRESHOLD = 0.15

SEGMENTATION_LINE_PERCENTAGE_THRESHOLD = 7e-05
SEGMENTATION_REGION_PERCENTAGE_THRESHOLD = 7e-05

SEGMENTATION_LINE_IOU = 0.3
SEGMENTATION_REGION_IOU = 0.3

SEGMENTATION_LINE_OVERLAP_THRESHOLD = 0.5
SEGMENTATION_REGION_OVERLAP_THRESHOLD = 0.5

SEGMENTATION_CLASS_ID_REGION = 1
SEGMENTATION_CLASS_ID_LINE = 2


# =============================================================================
# Recognition configuration
# =============================================================================

RECOGNITION_BATCH_SIZE = int(
    os.getenv(
        "RECOGNITION_BATCH_SIZE",
        os.getenv("HTR_BATCH_SIZE", "10"),
    )
)

RECOGNITION_IMG_HEIGHT = int(
    os.getenv("RECOGNITION_IMG_HEIGHT", "192")
)

RECOGNITION_IMG_WIDTH = int(
    os.getenv("RECOGNITION_IMG_WIDTH", "1024")
)

RECOGNITION_MAX_LENGTH = int(
    os.getenv("RECOGNITION_MAX_LENGTH", "128")
)

CONFIDENCE_RETRY_THRESHOLD = float(
    os.getenv("CONFIDENCE_RETRY_THRESHOLD", "0.15")
)


# =============================================================================
# Backward-compatible recognition settings
#
# recognition.py imports these names directly:
#
#     from .config import ONNX_THREADS, HTR_BATCH_SIZE
#
# Keep these aliases until recognition.py is refactored to use the newer names.
# =============================================================================

HTR_BATCH_SIZE = RECOGNITION_BATCH_SIZE

ONNX_THREADS = int(
    os.getenv(
        "ONNX_THREADS",
        str(
            min(
                8,
                max(
                    1,
                    os.cpu_count() or 1,
                ),
            )
        ),
    )
)

if HTR_BATCH_SIZE < 1:
    raise ValueError(
        "HTR_BATCH_SIZE / RECOGNITION_BATCH_SIZE "
        "must be at least 1"
    )

if ONNX_THREADS < 1:
    raise ValueError(
        "ONNX_THREADS must be at least 1"
    )


# =============================================================================
# Image enhancement service
# =============================================================================

IMAGE_ENHANCE_URL = os.getenv(
    "IMAGE_ENHANCE_URL",
    "http://image-enhance-archxai/enhance",
)

IMAGE_ENHANCE_TIMEOUT = float(
    os.getenv("IMAGE_ENHANCE_TIMEOUT", "10")
)


# =============================================================================
# Detection model
# =============================================================================

DEFAULT_DETECTION_REPO_ID = (
    "Kansallisarkisto/"
    "rfdetr-textline-textregion-detection-2xl"
)

DEFAULT_DETECTION_FILENAME = (
    "checkpoint_best_total.pth"
)


# =============================================================================
# Preprocessing service
# =============================================================================

PREPROCESSING_ENABLED = (
    os.getenv(
        "PREPROCESSING_ENABLED",
        "true",
    ).lower()
    == "true"
)

PREPROCESS_URL = os.getenv(
    "PREPROCESS_URL",
    "http://image-enhance-archxai/preprocess",
)

PREPROCESS_TIMEOUT = float(
    os.getenv("PREPROCESS_TIMEOUT", "30")
)

PREPROCESSING_METHOD = os.getenv(
    "PREPROCESSING_METHOD",
    "denoise",
)


# =============================================================================
# Language configuration
# =============================================================================

LANGUAGES_FILE = os.getenv(
    "HTR_LANGUAGES_FILE",
    str(Path(__file__).parent.parent / "languages.json"),
)

LANGUAGE_MAP: Dict[str, Dict[str, Any]] = {}

# --- Reverse lookup map: repo_id -> language key ---
_REPO_TO_LANG: Dict[str, str] = {}


def _load_languages() -> Dict[str, Dict[str, Any]]:
    """
    Load language configurations from languages.json file.
    
    Supports two formats:
    - Simple: {"estonian": "username/model-repo"}
    - Extended: {"estonian": {"repo": "username/model-repo", "backend": "local-onnx"}}
    
    Returns:
        Normalized dictionary with consistent structure for all entries.
    """
    global _REPO_TO_LANG

    try:
        with open(LANGUAGES_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        
        # Normalize format: support both simple string and extended dict
        normalized: Dict[str, Dict[str, Any]] = {}
        for lang, config in data.items():
            if isinstance(config, str):
                normalized[lang.lower()] = {
                    "repo": config,
                    "backend": "local-pytorch",
                    "description": None,
                }
            else:
                normalized[lang.lower()] = {
                    "repo": config.get("repo", ""),
                    "backend": config.get("backend", "local-pytorch"),
                    "description": config.get("description"),
                    "endpoint": config.get("endpoint"),
                    "timeout": config.get("timeout", 180),
                    "onnx": config.get("onnx", False),
                }
                # Build reverse lookup: repo_id -> lang_key
                repo = config.get("repo", "")
                if repo:
                    _REPO_TO_LANG[repo] = lang.lower()

        logger.info(f"Loaded {len(normalized)} language configurations from {LANGUAGES_FILE}")
        return normalized
        
    except FileNotFoundError:
        logger.warning(f"Languages file not found: {LANGUAGES_FILE}, using defaults")
        return {}
    except json.JSONDecodeError as e:
        logger.error(f"Invalid JSON in languages file: {e}")
        return {}


def get_language_config(language: str) -> Dict[str, Any]:
    """
    Get configuration for a specific language.
    
    Args:
        language: Language code (case-insensitive)
        
    Returns:
        Dictionary with keys:
        - repo: HuggingFace repository ID
        - backend: 'local-pytorch', 'local-onnx', or 'remote-onnx'
        - endpoint: Optional remote endpoint URL
        - timeout: Optional timeout for remote calls
        - onnx: Whether this is an ONNX model
        
    Raises:
        ValueError: If language is not found in configuration
    """
    global LANGUAGE_MAP
    
    if not LANGUAGE_MAP:
        LANGUAGE_MAP = _load_languages()
    
    lang_lower = language.lower()
    
    if lang_lower not in LANGUAGE_MAP:
        available = ", ".join(sorted(LANGUAGE_MAP.keys())) or "none"
        raise ValueError(
            f"Language '{language}' not found. "
            f"Available languages: {available}"
        )
    
    return LANGUAGE_MAP[lang_lower]


def get_repo_for_language(language: str) -> str:
    """Get the repo ID for a given language key."""
    config = get_language_config(language)
    return config.get("repo", "")


def is_onnx_model(language: str) -> bool:
    """Check if a language uses an ONNX backend."""
    config = get_language_config(language)
    backend = config.get("backend", "")
    return backend == "local-onnx" or backend == "remote-onnx"


# =============================================================================
# General configuration
# =============================================================================

DEBUG_MODE = (
    os.getenv(
        "DEBUG_LOGS",
        "false",
    ).lower()
    == "true"
)


# Initialize language map on module load
LANGUAGE_MAP = _load_languages()