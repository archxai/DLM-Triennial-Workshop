"""
Image Processing Utilities
==========================
Provides geometric image utilities for HTR.
Note: Image enhancement/preprocessing is handled by the external
image-enhance microservice (Single Source of Truth).
"""
import logging
from typing import Optional

import cv2
import numpy as np
import torch
from torchvision.io import read_image, ImageReadMode

# FIX: Import from torchvision.transforms.v2 explicitly
from torchvision.transforms import v2 as transforms_v2

logger = logging.getLogger("htr_core.processing")


# =============================================================================
# IMAGE LOADING
# =============================================================================

def load_with_torchvision(img_path: str) -> np.ndarray:
    """
    Load image using torchvision and convert to numpy array.
    
    Args:
        img_path: Path to the image file
        
    Returns:
        Numpy array (H, W, C) in RGB format
    """
    img_tensor = read_image(str(img_path), mode=ImageReadMode.RGB)
    return img_tensor.permute(1, 2, 0).numpy()


def preprocess_resize_torch_transform(image, max_size: int = 1024, normalize: bool = True):
    """
    Resize image using torchvision.transforms.v2 with antialiasing.
    
    Args:
        image: PIL Image or numpy array
        max_size: Maximum dimension for resize
        normalize: Whether to normalize to float32 [0, 1]
        
    Returns:
        Preprocessed tensor or image
    """
    if isinstance(image, np.ndarray):
        image = torch.from_numpy(image.copy())  # Make writable copy to avoid warning
    
    # Convert HWC to CHW format if needed
    if image.ndim == 3 and image.shape[2] in [1, 3]:
        image = image.permute(2, 0, 1)
    
    _, h, w = image.shape if isinstance(image, torch.Tensor) else (None, *image.size[::-1])
    
    transform_list = []
    
    # Only resize if image exceeds max_size
    if h > max_size or w > max_size:
        # Calculate target size maintaining aspect ratio
        if h > w:
            new_h = max_size
            new_w = int(w * max_size / h)
        else:
            new_w = max_size
            new_h = int(h * max_size / w)
        transform_list.append(transforms_v2.Resize(size=(new_h, new_w), antialias=True))
    
    if normalize:
        # Use ToDtype from torchvision.transforms.v2
        transform_list.append(transforms_v2.ToDtype(torch.float32, scale=True))
    
    if transform_list:
        return transforms_v2.Compose(transform_list)(image)
    
    return image


# =============================================================================
# POLYGON-BASED CROPPING (Geometric Operation)
# =============================================================================

def crop_line_with_polygon(image: np.ndarray, polygon: list) -> Optional[np.ndarray]:
    """
    Crop text line region using polygon mask.
    
    This is a geometric operation required to feed the recognition model
    with precise line regions. Unlike image enhancement, this is not
    preprocessing but rather extracting the detected region.
    
    Args:
        image: Full image as numpy array (H, W, C) or (H, W)
        polygon: List of [x, y] coordinate pairs defining the polygon
        
    Returns:
        Cropped image with polygon region, white background outside,
        or None if polygon is invalid
    """
    # Validate polygon has enough points
    if polygon is None:
        logger.debug("Polygon is None")
        return None
    
    if len(polygon) < 3:
        logger.debug(f"Polygon has < 3 points: {len(polygon)}")
        return None
    
    # Get image dimensions
    img_h, img_w = image.shape[:2]
    
    # Convert polygon to numpy array with bounds checking
    try:
        polygon_array = np.array([[float(pt[0]), float(pt[1])] for pt in polygon], dtype=np.float64)
    except (ValueError, TypeError, IndexError) as e:
        logger.warning(f"Failed to convert polygon coords: {e}, polygon={polygon[:3] if polygon else 'empty'}...")
        return None
    
    # Validate we have enough points after conversion
    if len(polygon_array) < 3:
        logger.warning(f"Polygon array has < 3 points after conversion: {len(polygon_array)}")
        return None
    
    # Calculate bounding rectangle
    x, y, w, h = cv2.boundingRect(polygon_array.astype(np.int32))
    
    # Clamp to image boundaries (prevent out-of-bounds access)
    x = max(0, min(x, img_w - 1))
    y = max(0, min(y, img_h - 1))
    w = max(1, min(w, img_w - x))
    h = max(1, min(h, img_h - y))
    
    # Validate dimensions after clamping
    if w <= 0 or h <= 0:
        logger.debug(f"Invalid bbox after clamping: ({x},{y},{w},{h}), img=({img_w},{img_h})")
        return None
    
    # Calculate actual end coordinates (clamped)
    x2 = min(x + w, img_w)
    y2 = min(y + h, img_h)
    
    # Final validation
    if x2 <= x or y2 <= y:
        logger.debug(f"Invalid crop region: ({x},{y})-({x2},{y2})")
        return None
    
    # Crop to bounding rectangle
    cropped = image[y:y2, x:x2]
    if cropped.size == 0:
        logger.warning("Cropped region is empty")
        return None
    
    # Create mask from polygon (offset to cropped coordinates)
    mask_h, mask_w = y2 - y, x2 - x
    mask = np.zeros([mask_h, mask_w], dtype=np.uint8)
    offset = polygon_array - np.array([[x, y]], dtype=np.float64)
    offset_int = offset.astype(np.int32)
    
    # Filter out points that would be outside the mask
    valid_mask = (offset_int[:, 0] >= 0) & (offset_int[:, 0] < mask_w) & \
                 (offset_int[:, 1] >= 0) & (offset_int[:, 1] < mask_h)
    if not np.all(valid_mask):
        # Some points are outside - clip them
        offset_int[:, 0] = np.clip(offset_int[:, 0], 0, mask_w - 1)
        offset_int[:, 1] = np.clip(offset_int[:, 1], 0, mask_h - 1)
    
    # Ensure we have at least 3 valid points for a polygon
    if len(offset_int) < 3:
        logger.warning(f"Not enough valid polygon points after clipping: {len(offset_int)}")
        return None
    
    # Draw filled polygon on mask
    try:
        cv2.drawContours(mask, [offset_int], -1, 255, -1, cv2.LINE_AA)
    except cv2.error as e:
        logger.warning(f"cv2.drawContours failed: {e}")
        return None
    
    # Apply mask while preserving white background outside polygon
    if len(cropped.shape) == 3:
        # Color image: create white background and blend
        masked = cv2.bitwise_and(cropped, cropped, mask=mask)
        white_bg = np.ones_like(cropped, np.uint8) * 255
        inv_mask = cv2.bitwise_not(mask)
        white_bg = cv2.bitwise_and(white_bg, white_bg, mask=inv_mask)
        result = cv2.add(masked, white_bg)
    else:
        # Grayscale: directly apply mask
        masked = cv2.bitwise_and(cropped, cropped, mask=mask)
        white_bg = np.ones_like(cropped, np.uint8) * 255
        inv_mask = cv2.bitwise_not(mask)
        white_bg = cv2.bitwise_and(white_bg, white_bg, mask=inv_mask)
        result = cv2.add(masked, white_bg)
    
    return result


# =============================================================================
# BACKWARD COMPATIBILITY (Deprecated)
# =============================================================================

def denoise_image(image: np.ndarray, strength: float = 2.0) -> np.ndarray:
    """
    DEPRECATED: Use external image-enhance microservice instead.
    
    This function is kept for backward compatibility only.
    Image preprocessing should be handled by the image-enhance API.
    
    Args:
        image: Input image
        strength: Denoising strength (ignored - uses API)
        
    Returns:
        Original image (no local processing)
    """
    logger.warning("denoise_image() is deprecated. Use external image-enhance API.")
    return image