# htr_core/recognition.py
"""
Text recognition module for HTR using TrOCR.
Supports both PyTorch and ONNX models with automatic detection.
"""
import hashlib
import logging
import os
import shutil
import tempfile

from pathlib import Path
from threading import Lock
from typing import Dict, Any, Tuple, Optional, List

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from huggingface_hub import snapshot_download
from transformers import (
    TrOCRProcessor,
    VisionEncoderDecoderConfig,
    VisionEncoderDecoderModel,
)
from transformers.models.vit.modeling_vit import (
    ViTEmbeddings,
    ViTPatchEmbeddings,
)

from .config import ONNX_THREADS, HTR_BATCH_SIZE


logger = logging.getLogger("htr_core.recognition")

IMG_HEIGHT, IMG_WIDTH = 192, 1024

_PATCH_APPLIED = False
_PATCH_LOCK = Lock()
_ONNX_MATERIALIZE_LOCK = Lock()


def _same_file_size(source: Path, target: Path) -> bool:
    """Return True when source and target exist and have the same size."""
    try:
        return (
            source.exists()
            and target.exists()
            and source.stat().st_size == target.stat().st_size
        )
    except OSError:
        return False


def _copy_real_file(source: Path, target: Path) -> None:
    """
    Copy the contents behind a regular file or symbolic link atomically.

    shutil.copy2 follows symbolic links by default, so the target becomes a
    real file instead of another Hugging Face cache symlink.
    """
    if not source.exists():
        raise FileNotFoundError(f"Source file does not exist: {source}")

    target.parent.mkdir(parents=True, exist_ok=True)

    if _same_file_size(source, target) and not target.is_symlink():
        return

    temporary_target = target.with_name(f"{target.name}.tmp")

    if temporary_target.exists() or temporary_target.is_symlink():
        temporary_target.unlink()

    try:
        shutil.copy2(source, temporary_target, follow_symlinks=True)

        if temporary_target.is_symlink():
            raise RuntimeError(
                f"Materialized file is unexpectedly still a symlink: "
                f"{temporary_target}"
            )

        if temporary_target.stat().st_size != source.stat().st_size:
            raise RuntimeError(
                f"Copied file size does not match source: "
                f"{source} -> {temporary_target}"
            )

        os.replace(temporary_target, target)
    except Exception:
        if temporary_target.exists() or temporary_target.is_symlink():
            temporary_target.unlink(missing_ok=True)
        raise


def _materialize_onnx_model(model_path: str) -> str:
    """
    Materialize an ONNX model and its external data as regular files.

    Hugging Face snapshots may represent the ONNX model and its .data file as
    symbolic links that resolve into different cache blob directories. ONNX
    Runtime can reject this because the external data appears to escape the
    resolved model directory. Copying both into one directory as regular files
    avoids that conflict.
    """
    source_model = Path(model_path)

    if not source_model.exists():
        raise FileNotFoundError(f"ONNX model does not exist: {source_model}")

    source_data = Path(f"{model_path}.data")
    has_external_data = source_data.exists()

    key_parts = [
        str(source_model.resolve()),
        str(source_model.stat().st_size),
    ]

    if has_external_data:
        key_parts.extend(
            [
                str(source_data.resolve()),
                str(source_data.stat().st_size),
            ]
        )

    cache_key = hashlib.sha256(
        "|".join(key_parts).encode("utf-8")
    ).hexdigest()[:20]

    materialized_root = Path(
        os.environ.get(
            "ARCHXAI_ONNX_MATERIALIZED_DIR",
            os.path.join(tempfile.gettempdir(), "archxai_onnx_models"),
        )
    )

    target_dir = materialized_root / cache_key
    target_model = target_dir / source_model.name
    target_data = target_dir / source_data.name

    with _ONNX_MATERIALIZE_LOCK:
        target_dir.mkdir(parents=True, exist_ok=True)
        _copy_real_file(source_model, target_model)

        if has_external_data:
            _copy_real_file(source_data, target_data)

    if not target_model.exists():
        raise RuntimeError(
            f"Materialized ONNX model was not created: {target_model}"
        )

    if target_model.is_symlink():
        raise RuntimeError(
            f"Materialized ONNX model is still a symlink: {target_model}"
        )

    if has_external_data:
        if not target_data.exists():
            raise RuntimeError(
                f"Materialized external data was not created: {target_data}"
            )

        if target_data.is_symlink():
            raise RuntimeError(
                f"Materialized external data is still a symlink: {target_data}"
            )

    logger.info("Using materialized ONNX model: %s", target_model)

    if has_external_data:
        logger.info(
            "Using materialized ONNX external data: %s",
            target_data,
        )

    return str(target_model)

# Enable ONNX external data loading before any ONNX operations
os.environ['ONNXRUNTIME_ALLOW_EXTERNAL_DATA'] = '1'


def _patch_vit_embeddings() -> None:
    """
    Apply ViT embedding patches for custom image size support.
    Required for Estonian/Latvian models with non-standard sizes.
    """
    global _PATCH_APPLIED

    with _PATCH_LOCK:
        if _PATCH_APPLIED:
            return

        try:
            original_embeddings_forward = ViTEmbeddings.forward

            def universal_patch_forward(self, pixel_values, **kwargs):
                return self.projection(pixel_values).flatten(2).transpose(1, 2)

            def universal_embeddings_forward(self, *args, **kwargs):
                kwargs["interpolate_pos_encoding"] = True
                return original_embeddings_forward(self, *args, **kwargs)

            ViTPatchEmbeddings.forward = universal_patch_forward
            ViTEmbeddings.forward = universal_embeddings_forward
            _PATCH_APPLIED = True
            logger.info("ViT embedding patches applied")
        except Exception as exc:
            logger.warning("Could not apply ViT patches: %s", exc)


# =============================================================================
# ONNX Recognition
# =============================================================================

def _onnx_generate_with_confidence(
    decoder,
    encoder_outputs: np.ndarray,
    batch_size: int,
    config: VisionEncoderDecoderConfig,
    max_length: int = 128,
) -> Tuple[np.ndarray, float]:
    """
    Autoregressive decoding with per-sequence early stopping.
    Returns generated token IDs and a confidence score.
    """
    decoder_input_ids = np.full(
        (batch_size, 1),
        config.decoder_start_token_id,
        dtype=np.int64,
    )
    finished = np.zeros(batch_size, dtype=bool)
    token_probs = []

    for _ in range(max_length):
        decoder_outputs = decoder.run(
            None,
            {
                "input_ids": decoder_input_ids,
                "encoder_hidden_states": encoder_outputs,
            },
        )[0]

        next_token_logits = decoder_outputs[:, -1, :]
        exp_logits = np.exp(
            next_token_logits
            - np.max(next_token_logits, axis=-1, keepdims=True)
        )
        probs = exp_logits / np.sum(exp_logits, axis=-1, keepdims=True)

        next_tokens = np.argmax(next_token_logits, axis=-1)
        token_prob = float(probs[0, next_tokens[0]])

        was_finished = finished.copy()
        just_finished = next_tokens == config.eos_token_id

        if not was_finished[0] and not just_finished[0]:
            token_probs.append(token_prob)

        finished = finished | just_finished
        next_tokens[finished] = config.pad_token_id

        decoder_input_ids = np.concatenate(
            [decoder_input_ids, next_tokens.reshape(-1, 1)],
            axis=1,
        )

        if np.all(finished):
            break

    confidence = float(np.mean(token_probs)) if token_probs else 0.0
    return decoder_input_ids, confidence


def _onnx_predict_text(
    image: Image.Image,
    processor: TrOCRProcessor,
    encoder,
    decoder,
    config: VisionEncoderDecoderConfig,
) -> Tuple[str, float]:
    """Predict text from a line image using ONNX models."""
    pixel_values = processor(
        [image],
        return_tensors="pt",
    ).pixel_values.numpy()

    batch_size = pixel_values.shape[0]
    encoder_outputs = encoder.run(
        None,
        {"pixel_values": pixel_values},
    )[0]

    generated_ids, confidence = _onnx_generate_with_confidence(
        decoder,
        encoder_outputs,
        batch_size,
        config,
    )

    texts = processor.batch_decode(
        generated_ids,
        skip_special_tokens=True,
        clean_up_tokenization_spaces=False,
    )

    text = texts[0] if texts else ""
    stripped_text = text.strip() if text else ""

    if not stripped_text:
        return "", 0.0

    return stripped_text, confidence


def _create_onnx_session_options(
    enable_optimizations: bool = True,
) -> "onnxruntime.SessionOptions":
    """Create ONNX Runtime session options."""
    import onnxruntime

    sess_options = onnxruntime.SessionOptions()

    if enable_optimizations:
        sess_options.graph_optimization_level = (
            onnxruntime.GraphOptimizationLevel.ORT_ENABLE_ALL
        )
    else:
        sess_options.graph_optimization_level = (
            onnxruntime.GraphOptimizationLevel.ORT_DISABLE_ALL
        )

    configured_threads = max(1, int(ONNX_THREADS))
    sess_options.intra_op_num_threads = configured_threads
    sess_options.inter_op_num_threads = min(
        4,
        max(1, configured_threads // 2),
    )
    sess_options.execution_mode = onnxruntime.ExecutionMode.ORT_PARALLEL

    return sess_options


def _load_onnx_model(
    model_path: str,
    providers: List[str],
) -> "onnxruntime.InferenceSession":
    """
    Load an ONNX model safely after materializing Hugging Face symlinks.
    """
    import onnxruntime

    safe_model_path = _materialize_onnx_model(model_path)
    available_providers = onnxruntime.get_available_providers()

    requested_providers = [
        provider
        for provider in providers
        if provider in available_providers
    ]

    if (
        "CPUExecutionProvider" in available_providers
        and "CPUExecutionProvider" not in requested_providers
    ):
        requested_providers.append("CPUExecutionProvider")

    if not requested_providers:
        raise RuntimeError(
            "None of the requested ONNX Runtime providers are available. "
            f"Requested: {providers}. Available: {available_providers}."
        )

    logger.info(
        "Loading ONNX model %s with providers %s",
        safe_model_path,
        requested_providers,
    )

    first_error = None

    try:
        session_options = _create_onnx_session_options(
            enable_optimizations=True
        )
        return onnxruntime.InferenceSession(
            safe_model_path,
            sess_options=session_options,
            providers=requested_providers,
        )
    except Exception as exc:
        first_error = exc
        logger.warning(
            "ONNX load with graph optimizations failed for %s: %s",
            safe_model_path,
            exc,
        )

    try:
        fallback_options = _create_onnx_session_options(
            enable_optimizations=False
        )
        return onnxruntime.InferenceSession(
            safe_model_path,
            sess_options=fallback_options,
            providers=requested_providers,
        )
    except Exception as final_error:
        logger.exception(
            "All ONNX loading attempts failed for %s",
            safe_model_path,
        )
        raise RuntimeError(
            "Failed to load ONNX model. "
            f"Original path: {model_path}. "
            f"Materialized path: {safe_model_path}. "
            f"First error: {first_error}. "
            f"Final error: {final_error}."
        ) from final_error


class TextRecognitionONNX:
    """ONNX-based text recognition for CUDA/CPU acceleration."""

    def __init__(
        self,
        model_path: str,
        device: str = "cpu",
        batch_size: int = 10,
    ):
        self.model_path = model_path
        self.device = device
        self.batch_size = batch_size
        self.processor = None
        self.encoder = None
        self.decoder = None
        self.config = None
        self.providers = None

        self._load_model()

    def _load_model(self) -> None:
        """Load ONNX encoder, decoder, processor, and configuration."""
        logger.info(
            "Loading ONNX recognition model from %s...",
            self.model_path,
        )

        try:
            local_path = snapshot_download(repo_id=self.model_path)
        except Exception as download_error:
            if os.path.isdir(self.model_path):
                local_path = self.model_path
                logger.info(
                    "Using local ONNX model directory: %s",
                    local_path,
                )
            else:
                raise RuntimeError(
                    f"Could not download ONNX model {self.model_path}"
                ) from download_error

        logger.info("Model downloaded or resolved to: %s", local_path)

        try:
            import onnxruntime

            available_providers = onnxruntime.get_available_providers()
        except ImportError as exc:
            raise RuntimeError(
                "ONNX Runtime is not installed in the HTR API container."
            ) from exc

        providers = ["CPUExecutionProvider"]

        if (
            self.device == "cuda"
            and torch.cuda.is_available()
            and "CUDAExecutionProvider" in available_providers
        ):
            providers = [
                "CUDAExecutionProvider",
                "CPUExecutionProvider",
            ]

        self.providers = providers

        logger.info(
            "Available ONNX Runtime providers: %s",
            available_providers,
        )
        logger.info("Selected ONNX Runtime providers: %s", providers)

        self.processor = TrOCRProcessor.from_pretrained(
            local_path,
            use_fast=True,
            do_resize=True,
            size={"height": IMG_HEIGHT, "width": IMG_WIDTH},
        )
        logger.info(
            "ONNX processor loaded with image size %sx%s",
            IMG_HEIGHT,
            IMG_WIDTH,
        )

        self.config = VisionEncoderDecoderConfig.from_pretrained(local_path)

        encoder_path = os.path.join(local_path, "encoder_model.onnx")
        decoder_path = os.path.join(local_path, "decoder_model.onnx")
        encoder_data_path = f"{encoder_path}.data"
        decoder_data_path = f"{decoder_path}.data"

        if not os.path.isfile(encoder_path):
            raise FileNotFoundError(
                f"Encoder model not found: {encoder_path}"
            )

        if not os.path.isfile(decoder_path):
            raise FileNotFoundError(
                f"Decoder model not found: {decoder_path}"
            )

        logger.info(
            "Encoder path: %s | symlink=%s | resolved=%s",
            encoder_path,
            os.path.islink(encoder_path),
            os.path.realpath(encoder_path),
        )
        logger.info(
            "Decoder path: %s | symlink=%s | resolved=%s",
            decoder_path,
            os.path.islink(decoder_path),
            os.path.realpath(decoder_path),
        )

        if os.path.exists(encoder_data_path):
            logger.info(
                "Encoder external data: %s | symlink=%s | resolved=%s",
                encoder_data_path,
                os.path.islink(encoder_data_path),
                os.path.realpath(encoder_data_path),
            )
        else:
            logger.info(
                "Encoder does not have a separate external data file."
            )

        if os.path.exists(decoder_data_path):
            logger.info(
                "Decoder external data: %s | symlink=%s | resolved=%s",
                decoder_data_path,
                os.path.islink(decoder_data_path),
                os.path.realpath(decoder_data_path),
            )
        else:
            logger.info(
                "Decoder does not have a separate external data file."
            )

        logger.info("Loading ONNX encoder...")
        self.encoder = _load_onnx_model(encoder_path, providers)
        logger.info("ONNX encoder loaded successfully")

        logger.info("Loading ONNX decoder...")
        self.decoder = _load_onnx_model(decoder_path, providers)
        logger.info("ONNX decoder loaded successfully")

        logger.info(
            "ONNX recognition model loaded successfully | "
            "model=%s | providers=%s | threads=%s",
            self.model_path,
            providers,
            ONNX_THREADS,
        )

    def recognize_single_line(
        self,
        image: Image.Image,
    ) -> Tuple[str, float]:
        """Recognize text from a single line image using ONNX."""
        try:
            return _onnx_predict_text(
                image,
                self.processor,
                self.encoder,
                self.decoder,
                self.config,
            )
        except Exception as exc:
            logger.error("ONNX recognition failed: %s", exc)
            return "", 0.0

    def recognize_batch(
        self,
        images: List[Image.Image],
    ) -> List[Tuple[str, float]]:
        """Recognize multiple line images sequentially with ONNX."""
        if not images:
            return []

        return [self.recognize_single_line(image) for image in images]

    def get_model_metadata(self) -> Dict[str, Any]:
        """Get model metadata."""
        configured_threads = max(1, int(ONNX_THREADS))
        return {
            "model_id": self.model_path,
            "architecture": "VisionEncoderDecoder (ONNX)",
            "format": "ONNX",
            "version_string": f"{self.model_path}@onnx",
            "providers": self.providers,
            "thread_config": {
                "intra_op": configured_threads,
                "inter_op": min(4, max(1, configured_threads // 2)),
            },
        }


# =============================================================================
# PyTorch Recognition
# =============================================================================

class TextRecognitionPyTorch:
    """PyTorch-based text recognition using TrOCR."""

    def __init__(
        self,
        model_path: str,
        device: str = "cpu",
        batch_size: int = 1,
    ):
        self.model_path = model_path
        self.device = device
        self.batch_size = batch_size
        self.processor = None
        self.model = None

        _patch_vit_embeddings()
        self._load_model()

    def _load_model(self) -> None:
        """Load TrOCR processor and model."""
        logger.info(
            "Loading PyTorch recognition model from %s...",
            self.model_path,
        )

        try:
            local_path = snapshot_download(repo_id=self.model_path)
        except Exception as download_error:
            if os.path.isdir(self.model_path):
                local_path = self.model_path
            else:
                raise RuntimeError(
                    f"Could not download PyTorch model {self.model_path}"
                ) from download_error

        self.processor = TrOCRProcessor.from_pretrained(
            local_path,
            do_resize=True,
            size={"height": IMG_HEIGHT, "width": IMG_WIDTH},
        )

        logger.info(
            "PyTorch processor loaded with image size %sx%s",
            IMG_HEIGHT,
            IMG_WIDTH,
        )

        self.model = VisionEncoderDecoderModel.from_pretrained(
            local_path
        ).to(self.device)
        self.model.eval()

        logger.info(
            "PyTorch recognition model loaded: %s",
            self.model_path,
        )

    def recognize_single_line(
        self,
        image: Image.Image,
    ) -> Tuple[str, float]:
        """Recognize text from a single line image with confidence."""
        inputs = self.processor(
            [image],
            return_tensors="pt",
        ).pixel_values.to(self.device)

        outputs = self.model.generate(
            inputs,
            max_new_tokens=128,
            use_cache=True,
            return_dict_in_generate=True,
            output_scores=True,
        )

        generated_ids = outputs.sequences[0]
        scores_tuple = outputs.scores

        text = self.processor.batch_decode(
            [generated_ids],
            skip_special_tokens=True,
        )[0]
        stripped_text = text.strip()

        if not stripped_text:
            return "", 0.0

        eos_token_id = self.model.config.eos_token_id
        token_probs = []

        for index in range(
            min(len(scores_tuple), len(generated_ids) - 1)
        ):
            token_id = generated_ids[index + 1]
            if token_id == eos_token_id:
                break

            logits = scores_tuple[index][0]
            probability = F.softmax(logits, dim=-1)[token_id].item()
            token_probs.append(probability)

        confidence = float(np.mean(token_probs)) if token_probs else 0.0
        return stripped_text, confidence

    def recognize_batch(
        self,
        images: List[Image.Image],
    ) -> List[Tuple[str, float]]:
        """Recognize multiple line images in batches."""
        if not images:
            return []

        results = []
        batch_size = min(HTR_BATCH_SIZE, len(images))

        for start in range(0, len(images), batch_size):
            batch = images[start:start + batch_size]
            pixel_values = self.processor(
                batch,
                return_tensors="pt",
            ).pixel_values.to(self.device)

            outputs = self.model.generate(
                pixel_values,
                max_new_tokens=128,
                use_cache=True,
                return_dict_in_generate=True,
                output_scores=True,
            )

            texts = self.processor.batch_decode(
                outputs.sequences,
                skip_special_tokens=True,
            )

            for batch_index, (generated_ids, text) in enumerate(
                zip(outputs.sequences, texts)
            ):
                stripped_text = text.strip()

                if not stripped_text:
                    results.append(("", 0.0))
                    continue

                eos_token_id = self.model.config.eos_token_id
                token_probs = []

                for score_index in range(
                    min(len(outputs.scores), len(generated_ids) - 1)
                ):
                    token_id = generated_ids[score_index + 1]
                    if token_id == eos_token_id:
                        break

                    logits = outputs.scores[score_index][batch_index]
                    probability = F.softmax(
                        logits,
                        dim=-1,
                    )[token_id].item()
                    token_probs.append(probability)

                confidence = (
                    float(np.mean(token_probs))
                    if token_probs
                    else 0.0
                )
                results.append((stripped_text, confidence))

        return results

    def get_model_metadata(self) -> Dict[str, Any]:
        """Get model metadata for versioning."""
        config = self.model.config
        architectures = getattr(config, "architectures", None) or [
            "unknown"
        ]

        return {
            "model_id": getattr(config, "_name_or_path", "unknown"),
            "architecture": architectures[0],
            "transformers_version": getattr(
                config,
                "transformers_version",
                "unknown",
            ),
            "format": "PyTorch",
            "version_string": (
                f"{getattr(config, '_name_or_path', 'unknown')}@"
                f"{getattr(config, 'transformers_version', 'unknown')}"
            ),
            "batch_support": True,
        }


# =============================================================================
# Unified TextRecognition
# =============================================================================

class TextRecognition:
    """Unified text recognition with PyTorch/ONNX backend selection."""

    def __init__(
        self,
        model_path: str,
        device: str = "cpu",
        batch_size: int = 1,
        force_backend: Optional[str] = None,
    ):
        self.model_path = model_path
        self.device = device
        self.batch_size = batch_size
        self.backend = None
        self._recognizer = None

        self._select_backend(force_backend)
        self._load_model()

    def _select_backend(
        self,
        force_backend: Optional[str] = None,
    ) -> None:
        """Select PyTorch or ONNX backend based on model/config."""
        if force_backend:
            selected_backend = force_backend.lower()
            if selected_backend not in {"pytorch", "onnx"}:
                raise ValueError(
                    "force_backend must be either 'pytorch' or 'onnx', "
                    f"got: {force_backend}"
                )

            self.backend = selected_backend
            logger.info("Forcing backend: %s", self.backend)
            return

        try:
            from .config import is_onnx_model, get_repo_for_language

            if "onnx" in self.model_path.lower():
                self.backend = "onnx"
                logger.info(
                    "Auto-detected ONNX model from path: %s",
                    self.model_path,
                )
                return

            for lang_key in [
                "finnish",
                "swedish",
                "estonian",
                "latvian",
            ]:
                if get_repo_for_language(lang_key) == self.model_path:
                    if is_onnx_model(lang_key):
                        self.backend = "onnx"
                        logger.info(
                            "Auto-detected ONNX model for %s",
                            lang_key,
                        )
                    else:
                        self.backend = "pytorch"
                        logger.info(
                            "Auto-detected PyTorch model for %s",
                            lang_key,
                        )
                    return
        except (ImportError, KeyError, ValueError, TypeError) as exc:
            logger.debug(
                "Could not determine backend from configuration: %s",
                exc,
            )

        self.backend = "pytorch"
        logger.info("Using default PyTorch backend")

    def _load_model(self) -> None:
        """Load the selected recognition model."""
        if self.backend == "onnx":
            self._recognizer = TextRecognitionONNX(
                model_path=self.model_path,
                device=self.device,
                batch_size=self.batch_size,
            )
        else:
            self._recognizer = TextRecognitionPyTorch(
                model_path=self.model_path,
                device=self.device,
                batch_size=self.batch_size,
            )

        logger.info(
            "TextRecognition initialized | Backend: %s | Device: %s",
            self.backend,
            self.device,
        )

    def recognize_single_line(
        self,
        image: Image.Image,
    ) -> Tuple[str, float]:
        """Recognize text from a single line image."""
        return self._recognizer.recognize_single_line(image)

    def recognize_batch(
        self,
        images: List[Image.Image],
    ) -> List[Tuple[str, float]]:
        """Recognize text from a batch of line images."""
        return self._recognizer.recognize_batch(images)

    def get_model_metadata(self) -> Dict[str, Any]:
        """Get model metadata for versioning."""
        base_meta = self._recognizer.get_model_metadata()
        base_meta["backend"] = self.backend
        return base_meta


# Aliases for backward compatibility
TextRecognitionPyTorchBackend = TextRecognitionPyTorch
TextRecognitionONNXBackend = TextRecognitionONNX
