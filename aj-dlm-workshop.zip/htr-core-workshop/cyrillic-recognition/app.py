from __future__ import annotations

import asyncio
import hashlib
import io
import logging
import os
import shutil
import tempfile
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, Sequence

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("ONNXRUNTIME_ALLOW_EXTERNAL_DATA", "1")

import numpy as np
import onnxruntime as ort
from fastapi import FastAPI, File, HTTPException, UploadFile
from huggingface_hub import snapshot_download
from PIL import Image, UnidentifiedImageError
from transformers import TrOCRProcessor, VisionEncoderDecoderConfig


logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)

logger = logging.getLogger("cyrillic-recognition")


MODEL_ID = os.getenv(
    "MODEL_ID",
    "Kansallisarkisto/cyrillic-large-handwritten-onnx",
)

MODEL_REVISION = os.getenv("MODEL_REVISION", "main")

REQUESTED_PROVIDER = os.getenv(
    "EXECUTION_PROVIDER",
    "CPUExecutionProvider",
)

ONNX_THREADS = int(os.getenv("ONNX_THREADS", "4"))

MAX_NEW_TOKENS = int(
    os.getenv("MAX_NEW_TOKENS", "128")
)

MAX_FILES_PER_REQUEST = int(
    os.getenv("MAX_FILES_PER_REQUEST", "500")
)

MAX_FILE_BYTES = int(
    os.getenv(
        "MAX_FILE_BYTES",
        str(20 * 1024 * 1024),
    )
)

MATERIALIZED_DIR = os.getenv(
    "ARCHXAI_ONNX_MATERIALIZED_DIR",
    "/root/.cache/huggingface/materialized_onnx",
)


class TrOCRProcessorCustom(TrOCRProcessor):
    """
    Processor compatibility class used by the
    Kansallisarkisto Cyrillic model.
    """

    def __init__(self, image_processor, tokenizer):
        self.image_processor = image_processor
        self.tokenizer = tokenizer
        self.current_processor = self.image_processor
        self.chat_template = None


def _same_file_size(
    source: Path,
    target: Path,
) -> bool:
    try:
        return (
            source.exists()
            and target.exists()
            and not target.is_symlink()
            and source.stat().st_size
            == target.stat().st_size
        )
    except OSError:
        return False


def _copy_real_file(
    source: Path,
    target: Path,
) -> None:
    if not source.exists():
        raise FileNotFoundError(
            f"Source file does not exist: {source}"
        )

    target.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    if _same_file_size(source, target):
        return

    temporary_target = target.with_name(
        f"{target.name}.tmp"
    )

    if (
        temporary_target.exists()
        or temporary_target.is_symlink()
    ):
        temporary_target.unlink()

    try:
        shutil.copy2(
            source,
            temporary_target,
            follow_symlinks=True,
        )

        if temporary_target.is_symlink():
            raise RuntimeError(
                "Materialized file is unexpectedly "
                f"still a symlink: {temporary_target}"
            )

        if (
            temporary_target.stat().st_size
            != source.stat().st_size
        ):
            raise RuntimeError(
                "Copied file size does not match source: "
                f"{source} -> {temporary_target}"
            )

        os.replace(
            temporary_target,
            target,
        )

    except Exception:
        if (
            temporary_target.exists()
            or temporary_target.is_symlink()
        ):
            temporary_target.unlink(
                missing_ok=True
            )
        raise


def _materialize_onnx_model(
    model_path: str,
) -> str:
    """
    Copy ONNX model and its possible external .data
    file into one real directory.

    This avoids Hugging Face cache symlink problems
    with ONNX Runtime external data.
    """

    source_model = Path(model_path)

    if not source_model.exists():
        raise FileNotFoundError(
            f"ONNX model does not exist: {source_model}"
        )

    source_data = Path(
        f"{model_path}.data"
    )

    has_external_data = source_data.exists()

    key_parts = [
        str(source_model.resolve()),
        str(source_model.stat().st_size),
    ]

    if has_external_data:
        key_parts.extend(
            [
                str(source_data.resolve()),
                str(source_data.stat().st_size),
            ]
        )

    cache_key = hashlib.sha256(
        "|".join(key_parts).encode("utf-8")
    ).hexdigest()[:20]

    target_dir = (
        Path(MATERIALIZED_DIR)
        / cache_key
    )

    target_model = (
        target_dir
        / source_model.name
    )

    target_data = (
        target_dir
        / source_data.name
    )

    target_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    _copy_real_file(
        source_model,
        target_model,
    )

    if has_external_data:
        _copy_real_file(
            source_data,
            target_data,
        )

    logger.info(
        "Using materialized ONNX model: %s",
        target_model,
    )

    if has_external_data:
        logger.info(
            "Using materialized ONNX external data: %s",
            target_data,
        )

    return str(target_model)


def _create_session_options(
    enable_optimizations: bool = True,
) -> ort.SessionOptions:

    options = ort.SessionOptions()

    if enable_optimizations:
        options.graph_optimization_level = (
            ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        )
    else:
        options.graph_optimization_level = (
            ort.GraphOptimizationLevel.ORT_DISABLE_ALL
        )

    threads = max(
        1,
        ONNX_THREADS,
    )

    options.intra_op_num_threads = threads

    options.inter_op_num_threads = min(
        4,
        max(
            1,
            threads // 2,
        ),
    )

    options.execution_mode = (
        ort.ExecutionMode.ORT_PARALLEL
    )

    return options


def _load_onnx_session(
    model_path: str,
    provider: str,
) -> ort.InferenceSession:

    safe_model_path = _materialize_onnx_model(
        model_path
    )

    available = ort.get_available_providers()

    providers = []

    if provider in available:
        providers.append(provider)

    if (
        "CPUExecutionProvider" in available
        and "CPUExecutionProvider"
        not in providers
    ):
        providers.append(
            "CPUExecutionProvider"
        )

    if not providers:
        raise RuntimeError(
            "No usable ONNX Runtime provider. "
            f"Requested={provider}, "
            f"available={available}"
        )

    logger.info(
        "Loading ONNX model %s with providers %s",
        safe_model_path,
        providers,
    )

    try:
        return ort.InferenceSession(
            safe_model_path,
            sess_options=_create_session_options(
                enable_optimizations=True
            ),
            providers=providers,
        )

    except Exception as first_error:
        logger.warning(
            "ONNX graph optimized loading failed: %s",
            first_error,
        )

        logger.info(
            "Retrying with ONNX graph "
            "optimizations disabled"
        )

        try:
            return ort.InferenceSession(
                safe_model_path,
                sess_options=_create_session_options(
                    enable_optimizations=False
                ),
                providers=providers,
            )

        except Exception as second_error:
            raise RuntimeError(
                "Unable to load ONNX model. "
                f"First error: {first_error}. "
                f"Fallback error: {second_error}."
            ) from second_error


class CyrillicRecognitionEngine:
    """
    Direct ONNX Runtime implementation for the
    Kansallisarkisto Cyrillic VisionEncoderDecoder
    model.

    Optimum is intentionally not used.
    """

    def __init__(
        self,
        model_id: str,
        revision: str,
        requested_provider: str,
        max_new_tokens: int,
    ) -> None:

        if max_new_tokens < 1:
            raise ValueError(
                "MAX_NEW_TOKENS must be at least 1"
            )

        self.model_id = model_id
        self.revision = revision
        self.requested_provider = (
            requested_provider
        )

        self.max_new_tokens = (
            max_new_tokens
        )

        self.model_path: str | None = None

        self.provider: str | None = None

        self.processor: (
            TrOCRProcessorCustom | None
        ) = None

        self.config: (
            VisionEncoderDecoderConfig | None
        ) = None

        self.encoder: (
            ort.InferenceSession | None
        ) = None

        self.decoder: (
            ort.InferenceSession | None
        ) = None

    def _select_provider(self) -> str:
        available = (
            ort.get_available_providers()
        )

        logger.info(
            "Available ONNX Runtime providers: %s",
            available,
        )

        if (
            self.requested_provider
            in available
        ):
            return self.requested_provider

        if (
            "CPUExecutionProvider"
            in available
        ):
            logger.warning(
                "Requested provider %s is not "
                "available. Falling back to CPU.",
                self.requested_provider,
            )

            return "CPUExecutionProvider"

        raise RuntimeError(
            "CPUExecutionProvider is unavailable. "
            f"Available providers: {available}"
        )

    def load(self) -> None:

        logger.info(
            "Downloading/loading model snapshot: %s",
            self.model_id,
        )

        self.model_path = snapshot_download(
            repo_id=self.model_id,
            revision=self.revision,
        )

        logger.info(
            "Model snapshot resolved to: %s",
            self.model_path,
        )

        self.provider = (
            self._select_provider()
        )

        logger.info(
            "Selected ONNX Runtime provider: %s",
            self.provider,
        )

        self.processor = (
            TrOCRProcessorCustom.from_pretrained(
                self.model_path
            )
        )

        self.config = (
            VisionEncoderDecoderConfig
            .from_pretrained(
                self.model_path
            )
        )

        encoder_path = os.path.join(
            self.model_path,
            "encoder_model.onnx",
        )

        decoder_path = os.path.join(
            self.model_path,
            "decoder_model.onnx",
        )

        if not os.path.isfile(
            encoder_path
        ):
            raise FileNotFoundError(
                "ONNX encoder was not found: "
                f"{encoder_path}. "
                "Files in model directory: "
                f"{os.listdir(self.model_path)}"
            )

        if not os.path.isfile(
            decoder_path
        ):
            raise FileNotFoundError(
                "ONNX decoder was not found: "
                f"{decoder_path}. "
                "Files in model directory: "
                f"{os.listdir(self.model_path)}"
            )

        logger.info(
            "Loading ONNX encoder..."
        )

        self.encoder = (
            _load_onnx_session(
                encoder_path,
                self.provider,
            )
        )

        logger.info(
            "ONNX encoder loaded"
        )

        logger.info(
            "Loading ONNX decoder..."
        )

        self.decoder = (
            _load_onnx_session(
                decoder_path,
                self.provider,
            )
        )

        logger.info(
            "ONNX decoder loaded"
        )

        self._log_model_interfaces()

        logger.info(
            "Cyrillic recognition engine ready"
        )

    def _log_model_interfaces(
        self,
    ) -> None:

        if (
            self.encoder is None
            or self.decoder is None
        ):
            return

        logger.info(
            "Encoder inputs: %s",
            [
                (
                    item.name,
                    item.shape,
                    item.type,
                )
                for item
                in self.encoder.get_inputs()
            ],
        )

        logger.info(
            "Encoder outputs: %s",
            [
                (
                    item.name,
                    item.shape,
                    item.type,
                )
                for item
                in self.encoder.get_outputs()
            ],
        )

        logger.info(
            "Decoder inputs: %s",
            [
                (
                    item.name,
                    item.shape,
                    item.type,
                )
                for item
                in self.decoder.get_inputs()
            ],
        )

        logger.info(
            "Decoder outputs: %s",
            [
                (
                    item.name,
                    item.shape,
                    item.type,
                )
                for item
                in self.decoder.get_outputs()
            ],
        )

    def _generate(
        self,
        encoder_outputs: np.ndarray,
    ) -> tuple[np.ndarray, float]:

        if (
            self.decoder is None
            or self.config is None
        ):
            raise RuntimeError(
                "Decoder is not initialized"
            )

        batch_size = (
            encoder_outputs.shape[0]
        )

        decoder_start = (
            self.config.decoder_start_token_id
        )

        eos_token_id = (
            self.config.eos_token_id
        )

        pad_token_id = (
            self.config.pad_token_id
        )

        if decoder_start is None:
            raise RuntimeError(
                "decoder_start_token_id "
                "is missing from model config"
            )

        if pad_token_id is None:
            pad_token_id = (
                eos_token_id
                if eos_token_id is not None
                else 0
            )

        decoder_input_ids = np.full(
            (
                batch_size,
                1,
            ),
            decoder_start,
            dtype=np.int64,
        )

        finished = np.zeros(
            batch_size,
            dtype=bool,
        )

        token_probabilities: list[
            list[float]
        ] = [
            []
            for _ in range(batch_size)
        ]

        for _ in range(
            self.max_new_tokens
        ):

            decoder_outputs = (
                self.decoder.run(
                    None,
                    {
                        "input_ids":
                            decoder_input_ids,
                        "encoder_hidden_states":
                            encoder_outputs,
                    },
                )
            )

            logits = decoder_outputs[0]

            next_token_logits = (
                logits[:, -1, :]
            )

            shifted = (
                next_token_logits
                - np.max(
                    next_token_logits,
                    axis=-1,
                    keepdims=True,
                )
            )

            exp_logits = np.exp(shifted)

            probabilities = (
                exp_logits
                / np.sum(
                    exp_logits,
                    axis=-1,
                    keepdims=True,
                )
            )

            next_tokens = np.argmax(
                next_token_logits,
                axis=-1,
            ).astype(np.int64)

            previously_finished = (
                finished.copy()
            )

            for index in range(
                batch_size
            ):
                if previously_finished[index]:
                    continue

                token = int(
                    next_tokens[index]
                )

                if (
                    eos_token_id is not None
                    and token
                    == eos_token_id
                ):
                    continue

                token_probabilities[
                    index
                ].append(
                    float(
                        probabilities[
                            index,
                            token,
                        ]
                    )
                )

            if eos_token_id is not None:
                just_finished = (
                    next_tokens
                    == eos_token_id
                )

                finished = (
                    finished
                    | just_finished
                )

            tokens_to_append = (
                next_tokens.copy()
            )

            tokens_to_append[
                previously_finished
            ] = pad_token_id

            decoder_input_ids = (
                np.concatenate(
                    [
                        decoder_input_ids,
                        tokens_to_append.reshape(
                            -1,
                            1,
                        ),
                    ],
                    axis=1,
                )
            )

            if np.all(finished):
                break

        confidences = [
            (
                float(np.mean(values))
                if values
                else 0.0
            )
            for values
            in token_probabilities
        ]

        confidence = (
            float(
                np.mean(confidences)
            )
            if confidences
            else 0.0
        )

        return (
            decoder_input_ids,
            confidence,
        )

    def recognize(
        self,
        images: Sequence[Image.Image],
    ) -> list[dict[str, Any]]:

        if (
            self.processor is None
            or self.encoder is None
            or self.decoder is None
            or self.config is None
        ):
            raise RuntimeError(
                "Recognition engine "
                "has not been loaded"
            )

        results: list[
            dict[str, Any]
        ] = []

        # Process each line independently.
        # This also keeps memory use predictable
        # on a CPU-only service.
        for image in images:

            rgb_image = (
                image.convert("RGB")
            )

            pixel_values = (
                self.processor(
                    [rgb_image],
                    return_tensors="np",
                ).pixel_values
            )

            pixel_values = np.asarray(
                pixel_values,
                dtype=np.float32,
            )

            encoder_outputs = (
                self.encoder.run(
                    None,
                    {
                        "pixel_values":
                            pixel_values
                    },
                )[0]
            )

            generated_ids, confidence = (
                self._generate(
                    encoder_outputs
                )
            )

            texts = (
                self.processor.batch_decode(
                    generated_ids,
                    skip_special_tokens=True,
                    clean_up_tokenization_spaces=False,
                )
            )

            text = (
                texts[0].strip()
                if texts
                else ""
            )

            results.append(
                {
                    "text": text,
                    "confidence": confidence,
                }
            )

        return results

    def metadata(self) -> dict[str, Any]:

        return {
            "model_id": self.model_id,
            "revision": self.revision,
            "backend": "onnxruntime",
            "architecture":
                "VisionEncoderDecoder-DINOv2",
            "format": "ONNX",
            "requested_provider":
                self.requested_provider,
            "provider": self.provider,
            "onnx_threads":
                ONNX_THREADS,
            "max_new_tokens":
                self.max_new_tokens,
            "transcription_policy":
                "normalized",
        }


engine = CyrillicRecognitionEngine(
    model_id=MODEL_ID,
    revision=MODEL_REVISION,
    requested_provider=REQUESTED_PROVIDER,
    max_new_tokens=MAX_NEW_TOKENS,
)

inference_lock = asyncio.Lock()


@asynccontextmanager
async def lifespan(
    _: FastAPI,
):    

    yield


app = FastAPI(
    title=(
        "ArchXAI Cyrillic "
        "Line Recognition API"
    ),
    version="2.0.0",
    lifespan=lifespan,
)


@app.get("/health")
async def health() -> dict[str, Any]:

    ready = (
        engine.processor is not None
        and engine.encoder is not None
        and engine.decoder is not None
    )

    return {
        "status":
            "ready"
            if ready
            else "not_ready",
        "model_loaded": ready,
        **engine.metadata(),
    }


@app.get("/metadata")
async def metadata() -> dict[str, Any]:
    return engine.metadata()

@app.post("/recognize-lines")
async def recognize_lines(
    files: list[UploadFile] = File(...),
) -> dict[str, Any]:

    if not files:
        raise HTTPException(
            status_code=400,
            detail=(
                "No line images supplied"
            ),
        )

    if (
        len(files)
        > MAX_FILES_PER_REQUEST
    ):
        raise HTTPException(
            status_code=413,
            detail=(
                "Too many files. Maximum is "
                f"{MAX_FILES_PER_REQUEST} "
                "line images per request"
            ),
        )

    images: list[Image.Image] = []

    for index, upload in enumerate(
        files
    ):
        raw = await upload.read()

        if not raw:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"Line image {index} "
                    "is empty"
                ),
            )

        if len(raw) > MAX_FILE_BYTES:
            raise HTTPException(
                status_code=413,
                detail=(
                    f"Line image {index} "
                    "exceeds maximum size "
                    f"{MAX_FILE_BYTES} bytes"
                ),
            )

        try:
            with Image.open(
                io.BytesIO(raw)
            ) as opened:

                opened.load()

                images.append(
                    opened.convert("RGB")
                )

        except (
            UnidentifiedImageError,
            OSError,
        ) as exc:

            raise HTTPException(
                status_code=400,
                detail=(
                    f"Line image {index} "
                    "is invalid: {exc}"
                ),
            ) from exc

    try:
        async with inference_lock:
            # LAISKA LATAUS: Tarkistetaan onko malli ladattu muistiin.
            # Jos encoder on None, mallia ei ole vielä alustettu.
            if engine.encoder is None:
                logger.info("Lazy loading Cyrillic recognition engine on first request...")
                await asyncio.to_thread(
                    engine.load
                )

            predictions = (
                await asyncio.to_thread(
                    engine.recognize,
                    images,
                )
            )

    except Exception as exc:
        logger.exception(
            "Cyrillic line "
            "recognition failed"
        )

        raise HTTPException(
            status_code=500,
            detail=(
                f"Inference failed: {exc}"
            ),
        ) from exc

    if (
        len(predictions)
        != len(images)
    ):
        raise HTTPException(
            status_code=500,
            detail=(
                "Recognition result count "
                "does not match number of "
                "submitted line images"
            ),
        )

    return {
        "model": engine.metadata(),
        "results": [
            {
                "index": index,
                "text":
                    prediction["text"],
                "confidence":
                    prediction[
                        "confidence"
                    ],
                "error": None,
            }
            for index, prediction
            in enumerate(predictions)
        ],
    }
