# Adding New Languages to ArchXAI HTR

This guide explains how to extend the system's language support by modifying the `languages.json` configuration file. Because the system is designed to be dynamic, adding a new language requires **zero code changes**, provided the model meets the architectural requirements.

## ⚙️ Model Requirements

To ensure a model works with the existing pipeline without causing crashes or inference errors, the model **must** satisfy the following criteria:

### 1. Architecture: TrOCR (VisionEncoderDecoder)
All models used in this system are based on the `microsoft/trocr-large-handwritten` architecture. Specifically, the model must be a **VisionEncoderDecoderModel**.
*   **What this means:** The model must have a Vision Transformer (ViT) as the encoder and a language model (like RoBERTa or GPT-2) as the decoder.
*   **Validation:** The system automatically validates the model's metadata via the Hugging Face API during startup. If the model is not a `VisionEncoderDecoder`, the system will log a warning and skip that language.

### 2. Hosting: Hugging Face Hub
The model must be hosted on the [Hugging Face Model Hub](https://huggingface.co/models). You only need to provide the `repo_id` (e.g., `Kansallisarkisto/estonian-large-handwritten`).

### 3. Input Dimensions
The system is optimized for text-line images resized to:
*   **Height:** 192px
*   **Width:** 1024px
Models based on the standard `trocr-large` architecture handle these dimensions via positional encoding interpolation, which is automatically handled by the internal patching mechanism in `core.py`.

---

## 🛠 How to Add a Language

1.  **Find a Model**: Locate a TrOCR-based handwritten text recognition model on Hugging Face.
2.  **Open `languages.json`**: Open the configuration file in your project root.
3.  **Append the Entry**: Add a new key-value pair using one of the following formats:

### Option A: Extended Format (Recommended)
Use this format to provide a description that will appear in the CLI `--list-langs` command and API metadata.
```json
"language_name": {
    "repo": "huggingface-user/model-repo-id",
    "description": "Brief description of the dataset or time period"
}
```

### Option B: Simple Format
Use this if you only need to map the language to a repository.
```json
"language_name": "huggingface-user/model-repo-id"
```

### 📝 Example `languages.json`
```json
{
  "estonian": {
    "repo": "Kansallisarkisto/estonian-large-handwritten",
    "description": "Estonian 19th-century manuscripts"
  },
  "finnish": {
    "repo": "Kansallisarkisto/multicentury-htr-model",
    "description": "Finnish multi-century HTR"
  },
  "custom_lang": {
    "repo": "username/custom-trocr-model",
    "description": "Custom model for specific historical script"
  }
}
```

---

## 🚀 Verification

After saving `languages.json`, you can verify the new language is active without running a full inference process:

**Using the CLI:**
```bash
python cli.py --list-langs
```
If the model is compatible, you will see:
`✅ Added custom language: 'custom_lang' → 'username/custom-trocr-model'`

**Using the API:**
1. Start the server: `python api.py`
2. Open the Swagger UI (`http://localhost:8081/docs`)
3. Check the `/languages` endpoint or look for the language in the `lang` dropdown of the `/process` endpoint.

---

## ⚠️ Troubleshooting

| Symptom | Possible Cause | Solution |
| :--- | :--- | :--- |
| **`Repo is not a VisionEncoderDecoderModel`** | The model uses a different architecture (e.g., CRNN, Tesseract, or pure BERT). | Ensure the model is a **TrOCR** or **VisionEncoderDecoder** variant. |
| **`Invalid Hugging Face repo`** | Typo in the `repo_id` or the repository is set to "Private". | Verify the URL on Hugging Face. If private, ensure you are logged in via `huggingface-cli login`. |
| **`RuntimeError: No languages loaded`** | `languages.json` has a syntax error (e.g., missing comma). | Use a JSON validator to ensure the file is correctly formatted. |
| **Poor recognition quality** | Model is too small or trained on different handwriting styles. | Try a `large` variant of the TrOCR architecture. |