# ArchXAI HTR Core

A high-performance, production-grade Handwritten Text Recognition (HTR) engine designed for the transcription of historical documents. This library combines **RF-DETR** for precise text line detection and **TrOCR** for sequence-to-sequence transcription, featuring a robust asynchronous persistence layer and S3-compatible object storage for large-scale archival processing.

The engine is designed to be hardware-agnostic and can be integrated into CLI tools, FastAPI servers, or high-throughput batch processing pipelines.

## 🚀 Features

- **Hybrid Storage Architecture**: Integrates **PostgreSQL** for relational metadata and **MinIO** for binary object storage. This ensures that high-resolution images are stored efficiently in an S3-compatible environment while metadata remains searchable.
- **Identity Guard & CAS**: Implements **Content-Addressable Storage (CAS)**. Images are hashed (SHA256) before processing; the hash serves as the unique key in MinIO and the database, automatically preventing duplicate storage and skipping redundant AI inference.
- **Versioned Transcriptions (`--alternative`)**: Supports multi-model evaluation. Users can process the same image with different language models or versions, storing multiple transcription results for the same image for comparison and quality benchmarking.
- **Dynamic Model Metadata**: Automatically extracts and stores model identifiers (Repo ID, Architecture, and Transformers version) from HuggingFace configurations, ensuring full traceability of every transcription.
- **State-Aware Processing**: Integrated tracking of document lifecycles (Detection → Recognition → Finished) with an automatic **Orphan Cleanup** mechanism that purges "ghost" documents from the database on startup.
- **Deep CPU & GPU Optimizations**: 
    - **VRAM Protection**: Implements an asynchronous inference lock to prevent Out-of-Memory (OOM) crashes during high-concurrency batch processing.
    - **Dynamic Quantization (int8)**: Reduces model size and increases inference speed on CPUs.
    - **Smart Thread Management**: Capped at 32 threads to optimize throughput on high-core virtual servers.
    - **Adaptive Batching**: Automatically adjusts batch sizes (e.g., 1 for CPU, 16 for GPU) to optimize memory bandwidth.
- **Smart Text Ordering**: A graph-based topological sort using a Directed Acyclic Graph (DAG) ensures text lines are read in the correct logical sequence, regardless of detection order.
- **Variable Image Support**: Custom monkey-patches to ViT embeddings allow the model to handle long, rectangular text lines (1024x192) without distortion.
- **Remote Model Support**: Cyrillic recognition uses a dedicated microservice for optimized ONNX inference.

---

## 🌍 Supported Languages

| Language | Model | Backend | Notes |
|----------|-------|---------|-------|
| **Finnish** | `Kansallisarkisto/multicentury-htr-model-onnx` | Local ONNX | Multi-century optimized |
| **Swedish** | `Kansallisarkisto/multicentury-htr-model-onnx` | Local ONNX | Multi-century optimized |
| **Estonian** | `Kansallisarkisto/estonian-large-handwritten` | Local PyTorch | 19th-century manuscripts |
| **Latvian** | `Kansallisarkisto/latvian-large-handwritten` | Local PyTorch | Historical texts |
| **Russian** | `Kansallisarkisto/cyrillic-large-handwritten-onnx` | Remote ONNX | Dedicated microservice |

---

## 🚢 Deployment Options

Choose the deployment method that matches your environment:

| Method | Use Case | Full Features* |
|--------|----------|----------------|
| **Docker Compose** | Production / Recommended | ✅ All features |
| **Local Installation** | Development / Custom setup | ✅ All features |
| **Docker Only (API)** | Quick API testing | ⚠️ Limited** |

*Full features = Identity Guard, Alternative Processing, MinIO Storage, DB Persistence
**Local installation still required for CLI and library integration

---

## 🐳 Option A: Docker Compose (Recommended)

This is the recommended deployment method. It starts all services including the HTR API, database, and MinIO storage.

### 1. Clone the Repository
```bash
git clone https://github.com/archxai/htr-core
cd htr-core
```

### 2. Start All Services
```bash
docker compose up -d
```

To see logs in real-time (instead of running in background):
```bash
docker compose up --build
```

### 3. Verify Services
```bash
# Check service health
curl http://localhost:8081/health

# Access Swagger UI
open http://localhost:8081/docs
```

### 4. Access Infrastructure Services
| Service | URL | Credentials |
|---------|-----|-------------|
| **HTR API** | http://localhost:8081 | - |
| **Swagger UI** | http://localhost:8081/docs | - |
| **Adminer (DB GUI)** | http://localhost:8080 | `archxai_user` / `archxai_pass123` |
| **MinIO Console** | http://localhost:9001 | `archxai_admin` / `archxai_secure_password_123` |

### Stopping Services
```bash
docker compose down          # Stop containers
docker compose down -v       # Stop and remove volumes (destructive!)
```

---

## 💻 Option B: Local Installation (Without Containers)

Use this method for development, custom deployments, or when running directly on your machine.

### Prerequisites

| Requirement | Version | Notes |
|-------------|---------|-------|
| Python | 3.10+ | Required |
| Docker | 24+ | For infrastructure only |
| Git | Any | For cloning |

### Step 1: Install System Dependencies

**Ubuntu/Debian:**
```bash
sudo apt-get update
sudo apt-get install -y \
    git \
    libgl1 \
    libglib2.0-0 \
    libsm6 \
    libxext6 \
    libxrender-dev \
    libgomp1 \
    poppler-utils \
    libcairo2-dev \
    pkg-config \
    python3-dev
```

**macOS:**
```bash
brew install poppler glib cairo
```

### Step 2: Install PyTorch

**Critical:** Install PyTorch separately to match your hardware before installing the HTR Core. Visit the [Official PyTorch Page](https://pytorch.org/get-started/locally/).

**NVIDIA GPU (CUDA 12.1):**
```bash
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121
```

**CPU Only:**
```bash
pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu
```

### Step 3: Clone and Install HTR Core
```bash
git clone https://github.com/archxai/htr-core
cd htr-core
pip install -e .
```

### Step 4: Start Infrastructure (Docker Required)

Even with local installation, the infrastructure services (PostgreSQL + MinIO) run in Docker:

```bash
# Start only the infrastructure services
docker compose up -d postgres minio adminer

# Verify infrastructure is running
docker compose ps
```

### Step 5: Configure Environment

Create a `.env` file in the `htr-core` root:

```env
# Database Configuration
DB_HOST=localhost
DB_PORT=5432
DB_NAME=archxai_db
DB_USER=archxai_user
DB_PASS=archxai_pass123

# MinIO Configuration
MINIO_ROOT_USER=archxai_admin
MINIO_ROOT_PASSWORD=archxai_secure_password_123
MINIO_DATA_PATH=./minio_data
MINIO_ENDPOINT=localhost:9000     
MINIO_BUCKET=archxai-images      

# App Settings
LOG_LEVEL=INFO
```

### Step 6: Run the Application

**API Server:**
```bash
python api.py
# Server starts on http://0.0.0.0:8081
```

**CLI:**
```bash
python cli.py /path/to/images/ --lang Finnish
```

**Python Library:**
```python
from htr_core.service import HTRService
import asyncio

async def main():
    service = HTRService(language="Finnish", device="cpu")
    await service.start()
    result = await service.process_image("document.jpg")
    print(f"Transcription: {result['text']}")
    await service.stop()

asyncio.run(main())
```

---

## 🧪 Option C: Docker API Only (Limited)

Use this for quick API testing without setting up the full infrastructure.

### Start API Container
```bash
docker run -p 8081:8081 \
  -e DB_HOST=your-postgres-host \
  -e MINIO_ENDPOINT=your-minio-host:9000 \
  archxai/htr-core:latest
```

> ⚠️ **Note:** This mode has limited functionality. The API will start but database and storage operations will fail without proper infrastructure.

---

## 💻 Usage

### Command Line Interface (CLI)
The CLI orchestrates the full pipeline: **Identity Check → MinIO Upload → Detection → Transcription → DB Persistence**.

#### Running on GPU (CUDA)
```bash
python cli.py /path/to/images/ --lang Estonian --device cuda
```

#### Running on CPU (Optimized)
```bash
python cli.py /path/to/images/ --lang Finnish --device cpu
```

**Key CLI Arguments:**
| Argument | Description | Default |
| :--- | :--- | :--- |
| `input` | Path to image or directory (Required) | N/A |
| `--lang` | `Finnish`, `Swedish`, `Estonian`, `Latvian`, `Russian` | `Finnish` |
| `--mode` | Confidence: `Fast`, `Balanced`, `Accurate` | `Balanced` |
| `--device` | `cuda` or `cpu` | `None` (Auto) |
| `--rerun` | Force re-process: deletes data from both DB and MinIO | `False` |
| `--alternative`| Allow storing multiple model results for the same image | `False` |
| `--doc-type` | Category for DB record | `Historical_Manuscript` |

### API Server (FastAPI)

#### Process an image (Finnish language, default settings):
```bash
curl -X 'POST' \
  'http://localhost:8081/process' \
  -H 'accept: application/json' \
  -F 'file=@document.jpg'
```

#### Process an image with Russian Cyrillic text:
```bash
curl -X 'POST' \
  'http://localhost:8081/process?lang=Russian&doc_type=Historical_Manuscript' \
  -H 'accept: application/json' \
  -F 'file=@russian_document.jpg'
```

#### Check server health:
```bash
curl -X 'GET' 'http://localhost:8081/health' -H 'accept: application/json'
```

**Key API Query Parameters:**
| Parameter | Description | Default |
| :--- | :--- | :--- |
| `lang` | Language: `Finnish`, `Swedish`, `Estonian`, `Latvian`, `Russian` | `Finnish` |
| `mode` | Inference mode: `Fast`, `Balanced`, `Accurate` | `Balanced` |
| `doc_type` | Document category for database | `Historical_Manuscript` |
| `rerun` | Force re-process: deletes previous DB and MinIO data | `false` |
| `alternative` | Allow storing new results for the same image | `false` |
| `merge_lines` | Merge overlapping line detections | `true` |

### Web UI (Gradio)

```bash
# From project root
docker compose up --build -d htr-ui

# Or run directly
cd UI
pip install gradio requests
python ui.py
```

The UI will be available at `http://localhost:7860`.

#### Theme Customization
Edit `UI/theme_config.json` to customize:
- Background, text, and border colors
- Confidence level colors (green/yellow/orange/red thresholds)

---

## 🌍 Extending Language Support

The engine is designed to be dynamically extensible. You can add new languages or custom TrOCR models from HuggingFace without modifying the source code.

📖 **See [Adding New Languages](addinglanguages.md)** for the detailed guide on model requirements and how to configure `languages.json`.

---

## 📁 Project Structure

```text
htr-core/
├── pyproject.toml          # Package metadata and dependencies
├── README.md               # Quick start guide
├── fullreadme.md           # This detailed documentation
├── addinglanguages.md      # Language extension guide
├── docker-compose.yaml     # Docker orchestration
├── Dockerfile              # Container build definition
├── cli.py                  # Async orchestrator and CLI wrapper
├── api.py                  # FastAPI server with interactive docs
├── languages.json          # Language model configuration
└── htr_core/               # Core library source code
    ├── __init__.py         # Package entry point
    ├── core.py             # HTR Engine, Model Logic, and Graph Ordering
    ├── service.py          # Pipeline Orchestrator (MinIO + DB + AI)
    ├── storage.py          # MinIO S3 Client Handler
    ├── database.py         # Asyncpg Handler & Identity Guard logic
    ├── models.py           # Pydantic data models
    ├── config.py           # Configuration and language loading
    ├── segmentation.py     # RF-DETR text detection
    ├── recognition.py      # TrOCR text recognition
    ├── recognition_backends.py  # Local/Remote backend abstraction
    ├── processing.py       # Image processing utilities
    ├── reading_order.py    # Graph-based reading order
    └── exceptions.py       # Custom exception hierarchy
└── UI/                     # Gradio web interface
    ├── ui.py               # Main UI application
    ├── styles.css          # Custom styling
    ├── theme_config.json   # Theme configuration
    ├── requirements.txt    # UI dependencies
    └── README.md           # UI documentation
```

---

## ⚙️ Technical Specifications

- **Line Detection**: `RFDETRSeg2XLarge` (DINOv2 Backbone).
- **Transcription**: `VisionEncoderDecoderModel` (TrOCR) with ONNX optimization.
- **Storage**: Hybrid PostgreSQL 18 + MinIO (S3-Compatible).
- **Concurrency**: Hybrid Async I/O (DB/Storage) and Synchronous compute (PyTorch).
- **Memory Management**: `asyncio.Lock` for GPU VRAM protection and dynamic `qint8` quantization.
- **Positioning**: ViT embedding patches applied to handle non-square aspect ratios.

---

## 📜 License
[Specify your license, e.g., MIT / Apache, etc.]