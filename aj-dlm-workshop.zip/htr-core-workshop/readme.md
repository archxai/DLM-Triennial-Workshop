# ArchXAI HTR-Core

Handwritten Text Recognition (HTR) API for historical manuscripts, with support for Nordic and Baltic languages.

## What It Does

- **Handwritten Text Recognition**: Transcribes handwritten historical documents using RF-DETR for text detection and TrOCR for recognition
- **Multi-Language Support**: Finnish, Swedish, Estonian, Latvian, and more
- **Polygon-Based Detection**: Precise text line boundaries using polygon coordinates
- **Orientation Detection**: Handles upright, rotated, and upside-down text
- **Image Preprocessing**: Automatic image enhancement for optimal results
- **Language Detection**: Verifies transcribed text language

## Architecture

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   Input Image   │────▶│  RF-DETR Detect │────▶│  TrOCR Recognize│
│                 │     │   (regions +    │     │   (lines →      │
│  (JPEG, PNG)    │     │    lines)       │     │    text)        │
└─────────────────┘     └─────────────────┘     └─────────────────┘
                                                            │
                         ┌─────────────────┐                │
                         │  Language       │◀───────────────┘
                         │  Detection      │
                         └─────────────────┘
                                │
                         ┌──────┴──────┐
                         │             │
                    ┌────▼────┐  ┌─────▼─────┐
                    │ MinIO   │  │ PostgreSQL│
                    │ (images)│  │ (results) │
                    └─────────┘  └───────────┘
```

## Quick Start

### Prerequisites

- Docker Engine 24.x+
- Docker Compose 2.20+
- db-core running (PostgreSQL + MinIO)

### Start HTR-Core

```bash
# Navigate to htr-core directory
cd htr-core

# Copy and configure environment
cp htr_core/.env.example htr_core/.env
# Edit .env with your database/storage credentials

# Build and start
docker compose up --build -d

# Verify services are running
docker compose ps
```

## Access Services

| Service | URL | Description |
|---------|-----|-------------|
| HTR API | http://localhost:8081 | REST API for text recognition |
| API Docs | http://localhost:8081/docs | Swagger UI |
| Gradio UI | http://localhost:7860 | Web interface |

## API Usage

### Process Image (REST API)

```bash
# Basic request
curl -X POST 'http://localhost:8081/process?lang=finnish' \
  -F 'file=@document.jpg'

# With all options
curl -X POST 'http://localhost:8081/process?lang=estonian&mode=Accurate' \
  -F 'file=@document.jpg' \
  -F 'doc_type=Church_Record' \
  -F 'rerun=false' \
  -F 'merge_lines=true'
```

**Query Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `lang` | string | required | Language: finnish, swedish, estonian, latvian, etc. |
| `mode` | string | Balanced | Inference mode: Fast, Balanced, Accurate |
| `doc_type` | string | Historical_Manuscript | Document type for database |
| `rerun` | bool | false | Force re-process (delete previous) |
| `alternative` | bool | false | Store as new result |
| `merge_lines` | bool | true | Merge overlapping detections |

### Available Languages

```bash
# List all available languages
curl http://localhost:8081/languages
```

### Health Check

```bash
curl http://localhost:8081/health | jq
```

## Using the Gradio UI

1. Open http://localhost:7860 in your browser
2. Upload an image
3. Select language
4. Click "Process" and wait for results

## Supported Languages

| Language | Model Repository | ONNX Support |
|----------|------------------|--------------|
| Finnish | Kansallisarkisto/finnish-htr-model | Yes |
| Swedish | Kansallisarkisto/swedish-htr-model | Yes |
| Estonian | Kansallisarkisto/estonian-large-handwritten | No |
| Latvian | Kansallisarkisto/latvian-handwritten | No |
| Cyrillic | archxai/cyrillic-recognition | No |

Add more languages in `languages.json`:

```json
{
  "newlanguage": {
    "repo": "Organization/new-lang-htr-model",
    "description": "Description of the model",
    "onnx": false
  }
}
```

## Processing Pipeline

1. **Input Validation**: Verify image format, calculate SHA256 hash
2. **Preprocessing**: Optional image enhancement (denoise, CLAHE, etc.)
3. **Detection**: RF-DETR identifies text regions and lines
4. **Recognition**: TrOCR converts line images to text
5. **Language Detection**: Verify recognized text language
6. **Visualization**: Generate annotated image with overlays
7. **Storage**: Save images to MinIO/S3
8. **Persistence**: Save metadata and results to PostgreSQL

## Inference Modes

| Mode | Confidence Threshold | Speed | Use Case |
|------|---------------------|-------|----------|
| Fast | 0.18 | ⚡⚡⚡ | Quick preview |
| Balanced | 0.15 | ⚡⚡ | Production default |
| Accurate | 0.12 | ⚡ | Best accuracy |

## Environment Variables

```env
# =============================================================================
# DATABASE (db-core PostgreSQL)
# =============================================================================
DB_HOST=postgres-archxai
DB_PORT=5432
DB_NAME=archxai_db
DB_USER=archxai_user
DB_PASS=archxai_pass123

# =============================================================================
# STORAGE (db-core MinIO/SeaweedFS)
# =============================================================================
MINIO_ENDPOINT=minio-archxai:9000
MINIO_ROOT_USER=archxai_admin
MINIO_ROOT_PASSWORD=archxai_secure_password_123
MINIO_BUCKET=archxai-images

# =============================================================================
# INTERNAL SERVICES (db-core microservices)
# =============================================================================
LANGDETECT_ENDPOINT=http://langdetect-archxai/detectlanguage
IMAGE_ENHANCE_URL=http://image-enhance-archxai/preprocess
IMAGE_ENHANCE_URL_ALL=http://image-enhance-archxai/enhance/all
PREPROCESSING_ENABLED=true
PREPROCESSING_METHOD=auto

# =============================================================================
# MODEL CACHE
# =============================================================================
HF_HOME=/root/.cache/huggingface
HF_HUB_CACHE=/root/.cache/huggingface/hub

# =============================================================================
# PERFORMANCE
# =============================================================================
HTR_THREADS=32
ONNX_THREADS=16
HTR_BATCH_SIZE=8

# =============================================================================
# LOGGING
# =============================================================================
LOG_LEVEL=INFO
DEBUG_LOGS=false
```

## Stop & Clean

```bash
# Stop services
docker compose down

# Remove models cache (saves disk space)
rm -rf htr_models/ .htr_cache/

# Full cleanup (removes all data)
docker compose down -v
rm -rf htr_models/ .htr_cache/ images/
```

## Troubleshooting

```bash
# Check logs
docker compose logs htr-api
docker compose logs htr-ui

# View API logs
docker compose logs -f htr-api

# Check GPU availability
docker exec -it htr-api nvidia-smi

# Clear model cache (forces re-download)
rm -rf .htr_cache/

# Restart services
docker compose restart
```

### Common Issues

**"Model not found" error:**
```bash
# Clear cache and restart
rm -rf .htr_cache/
docker compose down && docker compose up -d
```

**"Database connection failed":**
```bash
# Verify db-core is running
docker compose -f ../db-core/docker-compose.yaml ps

# Check database credentials in .env
```

**High CPU usage when idle:**
```bash
# Add CPU limits in docker-compose.yaml
deploy:
  resources:
    limits:
      cpus: '2.0'
```

## CLI Usage

Process images from command line:

```bash
# Basic usage
python cli.py /path/to/images --lang Finnish

# With options
python cli.py /path/to/images --lang Estonian --output-dir ./results --mode Accurate

# Force re-process
python cli.py /path/to/images --lang Finnish --rerun

# Clear validation cache
python cli.py --clear-cache
```

## Development

```bash
# Install locally
pip install -e .

# Run API directly (not in Docker)
python api.py

# Run with custom port
PORT=9000 python api.py

# Enable debug logging
DEBUG_LOGS=true LOG_LEVEL=DEBUG python api.py
```

## Technical Details

For detailed technical documentation, see:
- [fullreadme.md](fullreadme.md) - Comprehensive documentation
- [addinglanguages.md](addinglanguages.md) - Guide for adding new languages
- [Technical readme in db-core](../db-core/technicalreadme.md) - Database schema details