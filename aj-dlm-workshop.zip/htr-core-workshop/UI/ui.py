from pathlib import Path
import base64
import io
import json
import os
import time
import mimetypes
import gradio as gr
import requests
from PIL import Image

# =============================================================================
# TIMEOUT CONFIGURATION
# =============================================================================
# Maximum time to wait for HTR API response (in seconds)
# Large historical documents with many text lines can take 5-10+ minutes
DEFAULT_TIMEOUT = 1200  # 20 minutes

# Timeout for fetching boxed images
IMAGE_FETCH_TIMEOUT = 60  # 1 minute

# Timeout for language API calls
LANGUAGE_API_TIMEOUT = 30  # 30 seconds

BASE_DIR = Path(__file__).resolve().parent
CSS_PATH = BASE_DIR / "styles.css"
THEME_CONFIG_PATH = BASE_DIR / "theme_config.json"
LOGO_PATH = BASE_DIR / "logo.png"

# Load API base URL from environment
# Defaults are set for Docker networking - use service names, not localhost
API_BASE_URL = os.getenv("API_BASE_URL", "http://htr-api:8081")
IMAGES_API_URL = os.getenv("IMAGES_API_URL", "http://data-retriever:8000")
PROCESS_URL = f"{API_BASE_URL}/process"
LANGUAGES_URL = f"{API_BASE_URL}/languages"

DEFAULT_LANGUAGES = ["estonian", "finnish", "latvian", "swedish"]


def load_theme_config():
    """Load theme configuration from JSON file."""
    try:
        with open(THEME_CONFIG_PATH, "r") as f:
            return json.load(f)
    except Exception as e:
        print(f"Could not load theme config: {e}")
        return {
            "background": {
                "primary": "#0b1120",
                "secondary": "#111827",
                "input": "#020617"
            },
            "text": {
                "primary": "#e5e7eb",
                "secondary": "#94a3b8",
                "placeholder": "#64748b",
                "header": "#f8fafc"
            },
            "borders": {
                "default": "#1e3a5f",
                "input_default": "#334155",
                "input_focus": "#38bdf8"
            },
            "confidence": {
                "green": {"threshold_min": 95, "hex": "#22c55e"},
                "yellow": {"threshold_min": 80, "hex": "#eab308"},
                "orange": {"threshold_min": 60, "hex": "#f97316"},
                "red": {"threshold_min": 0, "hex": "#ef4444"}
            },
            "accent": {
                "primary": "#2563eb",
                "hover": "#1d4ed8",
                "glow": "#38bdf8"
            }
        }


def get_css_with_theme():
    """Load styles.css and inject CSS variables from theme config."""
    theme = load_theme_config()
    
    bg = theme.get("background", {})
    txt = theme.get("text", {})
    brd = theme.get("borders", {})
    acc = theme.get("accent", {})
    
    css_vars = f""":root {{
    --bg-primary: {bg.get("primary", "#0b1120")};
    --bg-secondary: {bg.get("secondary", "#111827")};
    --bg-input: {bg.get("input", "#020617")};
    --text-primary: {txt.get("primary", "#e5e7eb")};
    --text-secondary: {txt.get("secondary", "#94a3b8")};
    --text-placeholder: {txt.get("placeholder", "#64748b")};
    --text-header: {txt.get("header", "#f8fafc")};
    --border-default: {brd.get("default", "#1e3a5f")};
    --border-input: {brd.get("input_default", "#334155")};
    --border-focus: {brd.get("input_focus", "#38bdf8")};
    --accent-primary: {acc.get("primary", "#2563eb")};
    --accent-hover: {acc.get("hover", "#1d4ed8")};
    --accent-glow: {acc.get("glow", "#38bdf8")};
}}

"""

    try:
        with open(CSS_PATH, "r") as f:
            base_css = f.read()
    except Exception as e:
        print(f"Could not load styles.css: {e}")
        base_css = ""

    # Remove the :root block from styles.css since we're injecting it
    base_css = base_css.replace(base_css[:base_css.find("/* Whole page")], "")

    return css_vars + base_css


def image_to_base64(path):
    with open(path, "rb") as image_file:
        encoded = base64.b64encode(image_file.read()).decode("utf-8")

    return encoded


def get_languages():
    max_retries = 10
    retry_delay = 4
    
    for attempt in range(max_retries):
        try:
            response = requests.get(LANGUAGES_URL, timeout=LANGUAGE_API_TIMEOUT)
            response.raise_for_status()

            data = response.json()
            
            if isinstance(data, dict) and "available_languages" in data:
                languages = data.get("available_languages", [])
            elif isinstance(data, list):
                languages = data
            else:
                languages = []

            if not languages:
                return DEFAULT_LANGUAGES

            # Convert list of objects to dict mapping code -> name
            if languages and isinstance(languages[0], dict):
                return {lang["code"]: lang["name"] for lang in languages}

            return languages

        except requests.exceptions.RequestException as error:
            if attempt < max_retries - 1:
                print(f"Could not fetch languages (attempt {attempt + 1}/{max_retries}), retrying in {retry_delay}s...")
                time.sleep(retry_delay)
            else:
                print(f"Could not fetch languages from API: {error}")
                return DEFAULT_LANGUAGES

    return DEFAULT_LANGUAGES


def get_confidence_color(value):
    """Returns HTML span with appropriate color based on confidence percentage."""
    if not isinstance(value, (int, float)):
        return f'<span style="color: #94a3b8;">Not available</span>'
    
    percentage = value * 100
    colors = load_theme_config().get("confidence", {})
    
    if percentage >= colors.get("green", {}).get("threshold_min", 95):
        color = colors.get("green", {}).get("hex", "#22c55e")
    elif percentage >= colors.get("yellow", {}).get("threshold_min", 80):
        color = colors.get("yellow", {}).get("hex", "#eab308")
    elif percentage >= colors.get("orange", {}).get("threshold_min", 60):
        color = colors.get("orange", {}).get("hex", "#f97316")
    else:
        color = colors.get("red", {}).get("hex", "#ef4444")
    
    return f'<span style="color: {color}; font-weight: bold;">{percentage:.2f}%</span>'


def format_seconds(value):
    if isinstance(value, (int, float)):
        return f"{value:.2f} seconds"
    return "Not available"


def fetch_boxed_image(doc_id: int):
    """Fetch the boxed image from the images API and return as PIL Image."""
    if not doc_id:
        return None
    
    try:
        url = f"{IMAGES_API_URL}/images/document/{doc_id}"
        print(f"[DEBUG] Fetching boxed image from {url}")
        response = requests.get(url, params={"boxed": "true"}, timeout=IMAGE_FETCH_TIMEOUT)
        response.raise_for_status()
        
        data = response.json()
        images = data.get("images", [])
        
        if images:
            # Get the first image from the list
            first_image = images[0]
            hex_data = first_image.get("data")
            if hex_data:
                image_bytes = bytes.fromhex(hex_data)
                return Image.open(io.BytesIO(image_bytes))
        
        return None
    except requests.exceptions.RequestException as e:
        print(f"[DEBUG] Failed to fetch boxed image: {e}")
        return None
    except Exception as e:
        print(f"[DEBUG] Error processing boxed image: {e}")
        return None


def process_image(image_path, language, doc_type, rerun, alternative):
    """
    Process image through HTR pipeline.
    
    All languages (including Russian) go through the main API,
    which handles:
    1. Image segmentation (detecting text lines)
    2. Cropping line regions
    3. Routing cropped lines to appropriate recognition backend
       (e.g., Russian lines → cyrillic-recognition-api)
    
    Note: Processing large historical documents with many text lines can take
    several minutes. The timeout is set to 10 minutes to accommodate this.
    """
    print(f"[DEBUG] process_image called with language={language}")

    if image_path is None:
        return (
            "Please upload an image first.",
            "",
            "",
            "",
            {},
            None,
        )

    print(f"[DEBUG] Routing all languages (including {language}) to HTR API")

    try:
        with open(image_path, "rb") as image_file:
            content_type, _ = mimetypes.guess_type(image_path)
            if content_type is None:
                content_type = "image/jpeg"

            response = requests.post(
                PROCESS_URL,
                params={
                    "lang": language.lower(),
                    "doc_type": doc_type,
                    "rerun": rerun,
                    "alternative": alternative,
                    "mode": "Balanced",
                },
                files={
                    "file": (os.path.basename(image_path), image_file, content_type),
                },
                timeout=DEFAULT_TIMEOUT,  # Use configured timeout
            )

        print(f"[DEBUG] HTR API response status: {response.status_code}")

        if response.status_code != 200:
            print(f"[DEBUG] HTR API error response: {response.text}")

        response.raise_for_status()
        data = response.json()

        # Debug: log backend info
        model_meta = data.get("model_version", "unknown")
        print(f"[DEBUG] Recognition model: {model_meta}")

        text = data.get("text", "")
        confidence = data.get("confidence", 0.0)
        model_version = data.get("model_version", "Not available")

        # Calculate average confidence from lines if overall confidence is missing
        if not confidence:
            lines = data.get("lines", [])
            if lines:
                confidences = [line.get("recognition_confidence", 0) for line in lines]
                confidence = sum(confidences) / len(confidences) if confidences else 0.0

        # Get detected language
        detected_lang = data.get("detected_language_code")

        # Build metrics from response
        metrics = {}
        total_time = data.get("processing_time_ms")
        if total_time:
            metrics["total_time_sec"] = total_time / 1000

        summary = (
            f"**Status:** {data.get('status', 'unknown')}\n\n"
            f"**Confidence:** {get_confidence_color(confidence)}\n\n"
            f"**Processing time:** {format_seconds(metrics.get('total_time_sec'))}\n\n"
            f"**Model version:** {model_version}\n\n"
            f"**Detected language:** {detected_lang.upper() if detected_lang else 'N/A'}"
        )

        # Fetch boxed image
        doc_id = data.get("doc_id")
        boxed_image = fetch_boxed_image(doc_id) if doc_id else None

        return (
            text,
            summary,
            format_lines(data),
            format_metrics(data),
            data,
            boxed_image,
        )

    except requests.exceptions.Timeout:
        error_msg = (
            f"**Error:** Request timed out after {DEFAULT_TIMEOUT} seconds.\n\n"
            f"The document may be too large or contain many text lines. "
            f"Large historical documents can take several minutes to process.\n\n"
            f"**Troubleshooting:**\n"
            f"- Try with a smaller image\n"
            f"- Check if the HTR API is running properly\n"
            f"- Consider using the CLI for very large batches"
        )
        return (
            "",
            error_msg,
            "",
            "",
            {},
            None,
        )
    except requests.exceptions.RequestException as error:
        error_msg = (
            f"**Error:** API request failed\n\n"
            f"**Details:** {str(error)}\n\n"
            f"**Possible causes:**\n"
            f"- HTR API is not running\n"
            f"- Network connectivity issues\n"
            f"- Invalid image format"
        )
        return (
            "",
            error_msg,
            "",
            "",
            {},
            None,
        )

    except Exception as error:
        error_msg = (
            f"**Error:** Something went wrong\n\n"
            f"**Details:** {str(error)}"
        )
        return (
            "",
            error_msg,
            "",
            "",
            {},
            None,
        )


def format_lines(data):
    lines = data.get("lines", [])

    if not lines:
        return "No line-level results found."

    formatted_lines = []

    for line in lines:
        line_number = line.get("line_number")
        text = line.get("text", "")
        confidence = line.get("recognition_confidence", line.get("confidence", 0))
        formatted_lines.append(
            f"**Line {line_number}:** {text}\n"
            f"&nbsp;&nbsp;&nbsp;&nbsp;Recognition: {get_confidence_color(confidence)}"
        )

    return "\n\n".join(formatted_lines)


def format_metrics(data):
    processing_time_ms = data.get("processing_time_ms")

    if processing_time_ms:
        return (
            f"**Processing time:** {format_seconds(processing_time_ms / 1000)}\n\n"
            f"**Regions detected:** {data.get('regions_detected', 0)}\n\n"
            f"**Preprocessing:** {data.get('preprocessing_method', 'N/A')}"
        )

    return "No metrics found."


available_languages = get_languages()
default_language = "finnish" if "finnish" in available_languages else available_languages[0]


with gr.Blocks(title="Handwritten Text Recognition") as demo:
    logo_base64 = image_to_base64(LOGO_PATH)

    gr.HTML(
        f"""
        <div id="app-header">
            <img
                id="app-logo"
                src="data:image/png;base64,{logo_base64}"
                alt="Application logo"
            />
            <div id="app-header-text">
                <h1>Handwritten Text Recognition</h1>
                <p>
                    Transform handwritten manuscript pages (one page at a time) into digital text using advanced AI HTR. ArchXAI system automatically detects text lines
                    and transcribes them in real-time, preserving the natural reading order of your documents. 
                    Note! currently only supports image files of manuscript pages, not PDFs or multi-page documents.
                </p>
            </div>
        </div>
        """
    )

    with gr.Row():
        with gr.Column(scale=1, elem_classes=["htr-panel"]):
            image_input = gr.Image(
                type="filepath",
                label="Upload image",
            )

            language_input = gr.Radio(
                choices=available_languages,
                value=default_language,
                label="Language of the text",
            )

            doc_type_input = gr.Textbox(
                value="Historical_Manuscript",
                label="Document type",
            )

            rerun_input = gr.Checkbox(
                value=False,
                label="Force re-process",
                info="Run processing again even if a result already exists."
            )

            alternative_input = gr.Checkbox(
                value=False,
                label="Store as alternative result",
                info="Save the result as an alternative version instead of replacing the current one."
            )

            submit_button = gr.Button(
                "Recognize text",
                variant="primary",
            )
            
            # Info text about processing time
            gr.HTML(
                """
                <div style="margin-top: 10px; padding: 10px; background: rgba(37, 99, 235, 0.1); border-radius: 8px; font-size: 12px; color: #94a3b8;">
                    <strong>Note:</strong> Processing large historical documents with many text lines 
                    can take several minutes. Please be patient while the AI analyzes your document.
                </div>
                """
            )

        with gr.Column(scale=2, elem_classes=["result-panel"]):
            text_output = gr.Textbox(
                label="Recognized text",
                lines=18,
                elem_classes=["primary-output"],
            )

            summary_output = gr.Markdown(
                label="Summary",
            )

    with gr.Accordion("Line-level results", open=False):
        with gr.Row():
            with gr.Column(scale=1):
                lines_output = gr.Markdown(
                    label="Lines",
                )
            with gr.Column(scale=1):
                boxed_image_output = gr.Image(
                    label="Boxed Image",
                    elem_classes=["boxed-image-display"],
                )

    with gr.Accordion("Metrics", open=False):
        metrics_output = gr.Markdown(
            label="Processing metrics",
        )

    with gr.Accordion("Raw API response", open=False):
        raw_output = gr.JSON(
            label="Raw JSON",
        )

    submit_button.click(
        fn=process_image,
        inputs=[
            image_input,
            language_input,
            doc_type_input,
            rerun_input,
            alternative_input,
        ],
        outputs=[
            text_output,
            summary_output,
            lines_output,
            metrics_output,
            raw_output,
            boxed_image_output,
        ],
    )


demo.launch(
    theme=gr.themes.Ocean(),
    css=get_css_with_theme(),
    server_name="0.0.0.0",
)