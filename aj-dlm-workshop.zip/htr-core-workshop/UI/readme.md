# ArchXAI User Interface for HTR

This folder contains a Gradio-based user interface for the handwritten text recognition (HTR) API. The UI allows a user to upload an image, select the recognition language, choose optional processing settings, and view the recognized text, processing summary, line-level results, metrics, and raw API response.

## Contents

```text
UI/
├── ui.py
├── styles.css
├── theme_config.json
├── requirements.txt
├── README.md
└── logo.png
```

## What the UI does

The UI connects to an existing HTR backend API. It does not run the recognition model directly. Instead, it sends the uploaded image and selected options to the API and displays the response.

The main UI includes:

- image upload for handwritten material
- language selection
- optional document type field
- option to force re-processing
- option to store the result as an alternative result
- recognized text output
- summary with status, confidence, processing time, and model version
- expandable line-level results
- expandable metrics
- expandable raw JSON response

## API endpoints used

The UI expects the backend API to be available at:

```text
http://localhost:8081
```

The UI uses two endpoints:

```text
GET /languages
```

Used to populate the available language options.

and:
```text
POST /process
```

Used to process the uploaded image.

The request sends:

- `file` as multipart form data
- `lang` as a query parameter
- `doc_type` as a query parameter
- `rerun` as a query parameter
- `alternative` as a query parameter


## Requirements

The UI requires Python and the following Python packages:

```text
gradio
requests
```

A virtual environment is recommended.

## Configuration

The API base URL is defined in `ui.py`:

```python
API_BASE_URL = "http://localhost:8081"
```

If the backend API runs on a different host or port, update this value.

```python
API_BASE_URL = "http://your-server-address:8081"
```

## Theme Configuration

The UI appearance is customizable via `theme_config.json`:

```json
{
    "background": {
        "primary": "#0b1120",
        "secondary": "#111827",
        "input": "#020617"
    },
    "text": {
        "primary": "#e5e7eb",
        "secondary": "#94a3b8",
        "placeholder": "#64748b",
        "header": "#f8fafc"
    },
    "borders": {
        "default": "#1e3a5f",
        "input_default": "#334155",
        "input_focus": "#38bdf8"
    },
    "confidence": {
        "green": {"threshold_min": 95, "hex": "#22c55e"},
        "yellow": {"threshold_min": 80, "hex": "#eab308"},
        "orange": {"threshold_min": 60, "hex": "#f97316"},
        "red": {"threshold_min": 0, "hex": "#ef4444"}
    },
    "accent": {
        "primary": "#2563eb",
        "hover": "#1d4ed8",
        "glow": "#38bdf8"
    }
}
```

Edit `theme_config.json` and start the UI again to see changes.

## Start with Docker

Run the UI as a Docker container from the project root:

```bash
docker compose up --build -d htr-ui
```

Access at `http://localhost:7860`

OR

## Setup manually
Activate the projects shared virtual environment from project root (/htr-core):
```bash
source venv/bin/activate
```

Move to `UI` folder:
```bash
cd UI
```

Install dependencies:
```bash
pip install gradio requests
```

### Running the UI

Start the backend API first. Then run the UI from the `UI` folder:

```bash
cd /htr-core/UI
python ui.py
```

Gradio will print a local URL in the terminal, usually something like:

```text
http://127.0.0.1:7860
```

Open that URL in a browser.