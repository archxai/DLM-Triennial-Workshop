#!/usr/bin/env python3
"""
ArchXAI HTR CLI
Command-line interface for batch processing handwritten text recognition.
"""
import argparse
import asyncio
from pathlib import Path

from htr_core.config import LANGUAGE_MAP
from htr_core.service import HTRService


async def run(args):
    """Run HTR processing for all input files."""
    service = HTRService(language=args.lang, device=args.device, mode=args.mode)
    await service.start()

    try:
        path = Path(args.input)
        if path.is_file():
            files = [path]
        else:
            files = [
                f for f in path.rglob('*')
                if f.suffix.lower() in {'.jpg', '.jpeg', '.png', '.tif', '.tiff', '.bmp'}
            ]

        for file_path in files:
            result = await service.process_image(
                image_input=file_path,
                doc_type=args.doc_type,
                alternative=args.alternative,
                merge_lines=not args.no_merge,
                rerun=args.rerun,
                original_filename=file_path.name,
            )
            print(f"{file_path}: {result.get('status', 'unknown')} | "
                  f"lines={len(result.get('lines', []))} | "
                  f"confidence={result.get('confidence', 0):.3f} | "
                  f"text_id={result.get('text_id')}")
    finally:
        await service.stop()


def main():
    parser = argparse.ArgumentParser(
        description="ArchXAI HTR - Batch process handwritten text recognition"
    )
    parser.add_argument(
        'input',
        help="Input file or directory containing images"
    )
    parser.add_argument(
        '--lang',
        choices=sorted(LANGUAGE_MAP),
        default='finnish',
        help="Language for HTR model"
    )
    parser.add_argument(
        '--mode',
        choices=['Fast', 'Balanced', 'Accurate'],
        default='Balanced',
        help="Inference confidence mode"
    )
    parser.add_argument(
        '--device',
        help="Device for inference (cuda/cpu). Auto-detected if not specified."
    )
    parser.add_argument(
        '--doc-type',
        default='Historical_Manuscript',
        help="Document category for database"
    )
    parser.add_argument(
        '--rerun',
        action='store_true',
        help="Force re-process (delete previous data first)"
    )
    parser.add_argument(
        '--alternative',
        action='store_true',
        help="Store as alternative transcription (reuse existing picture)"
    )
    parser.add_argument(
        '--no-merge',
        action='store_true',
        help="Do not merge overlapping line detections"
    )
    asyncio.run(run(parser.parse_args()))


if __name__ == '__main__':
    main()