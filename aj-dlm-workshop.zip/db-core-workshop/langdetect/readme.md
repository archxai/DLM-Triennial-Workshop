# API‑LangDetect

A tiny FastAPI service that detects the language of a given text.

## Quick start (local)

```bash
# 1. Install dependencies
pip install -r requirements.txt   # create this file with the needed packages (e.g., fastapi, uvicorn, langdetect)

# 2. Run the API
uvicorn <module_name>:app --reload --host 0.0.0.0 --port 8000
```

*Replace `<module_name>` with the name of the Python file that creates the FastAPI `app` instance (e.g., `app.main`).*

## API endpoint

- **POST** `/detect`
  - **Body** (JSON): `{ "text": "Your text here." }`
  - **Response** (JSON):
    ```json
    {
      "language": "en",          // ISO‑639‑1 code
      "confidence": 0.99
    }
    ```

## Configuration (optional)

| Variable          | Default | Description                              |
|-------------------|---------|------------------------------------------|
| `HOST`            | `0.0.0.0`| Interface on which to bind the server.   |
| `PORT`            | `8000`  | Port on which the server listens.        |
| `MODEL` / `LIB`   | `langdetect` | Library or model used for detection.   |

Add any needed variables to a `.env` file or to the parent `docker‑compose.yaml` if you run the service via Docker.

## Docker (optional)

If the parent `docker‑compose.yaml` defines a service for **api‑langdetect**, you can start it with:

```bash
docker-compose up -d api-langdetect
```

Otherwise, create a simple Dockerfile (example):

```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY . /app
RUN pip install -r requirements.txt
CMD ["uvicorn", "<module_name>:app", "--host", "0.0.0.0", "--port", "8000"]