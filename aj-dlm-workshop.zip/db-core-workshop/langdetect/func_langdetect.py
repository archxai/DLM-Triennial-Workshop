# api_langdetect/func_langdetect.py
from typing import Dict
import fasttext
from fastapi import HTTPException
import logging
import re

logger = logging.getLogger("langdetect.service")

def detect_language(text: str) -> Dict:
    try:
        fasttext_model = fasttext.load_model("./fasttext-models/lid.176.ftz")
        
        # 1. Replace newlines and tabs with spaces
        cleaned_text = text.replace("\n", " ").replace("\t", " ")
        
        # 2. Collapse multiple spaces into one and strip leading/trailing spaces
        cleaned_text = " ".join(cleaned_text.split())
        
        # 3. Ensure text is not empty
        if not cleaned_text:
            return {"NA": 0.0}  # Safe fallback
            
        logger.info(f"Detecting language for cleaned text (length: {len(cleaned_text)}): {cleaned_text[:50]}...")
        
        predictions = fasttext_model.predict(cleaned_text, k=3)
        languages = predictions[0]
        probabilities = predictions[1]
        result = {lang.replace("__label__", ""): prob for lang, prob in zip(languages, probabilities)}
       
        return result

    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="FastText model not found. Please ensure lid.176.ftz is in the ./fasttext-models/ directory.")
    except ValueError as ve:
        logger.error(f"FastText ValueError (likely due to text formatting): {ve}")
        raise HTTPException(status_code=400, detail=f"Invalid text format for language detection: {str(ve)}")
    except Exception as e:
        logger.error(f"Error during language detection: {type(e).__name__} - {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error during language detection: {str(e)}")