from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse
from typing import Dict
from pydantic import BaseModel
from func_langdetect import detect_language

app = FastAPI(title="Langdetect API")

# <--- Add this Pydantic model
class LanguageRequest(BaseModel):
    text: str

@app.get("/")
def read_root():
    return {"service": "Langdtect API", "message": "To get endpoints, visit /docs"}

@app.get("/health")
def health_check():
    return JSONResponse(content={"status": "healthy", "service": "Langdetect API"}, status_code=200)

# <--- Update the function signature to use the model
@app.post("/detectlanguage")
def detect_language_endpoint(request: LanguageRequest) -> Dict:
    """
    Detects the language(s) of the input text and returns a dictionary of
    languages with their probabilities.
    """
    try:
        # Access the text via request.text
        result = detect_language(request.text)
        return result

    except HTTPException as e:
        raise e
    except Exception as e:
        print(f"Error during language detection: {type(e).__name__} - {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error during language detection: {str(e)}")