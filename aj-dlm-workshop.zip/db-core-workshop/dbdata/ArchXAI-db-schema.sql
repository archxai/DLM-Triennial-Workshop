-- =============================================================================
-- ArchXAI Database Schema (Region→Line Architecture)
-- Version: 2026-10-05
-- Model:   Kansallisarkisto/rfdetr-textline-textregion-detection-2xl
-- =============================================================================

-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements";

-- =============================================================================
-- 1. ENUMS
-- =============================================================================

CREATE TYPE processing_status AS ENUM ('Pending', 'Processing', 'Completed', 'Failed');
CREATE TYPE text_origin     AS ENUM ('OCR', 'HTR', 'Manual', 'Correction');
CREATE TYPE inference_mode  AS ENUM ('Fast', 'Balanced', 'Accurate');
CREATE TYPE pii_confirmation AS ENUM ('Pending', 'Confirmed', 'Rejected');

-- RF-DETR line orientation categories
CREATE TYPE text_line_orientation AS ENUM (
    'upright',
    'upside_down',
    'rotated_cw',
    'rotated_ccw'
);

-- =============================================================================
-- 2. TABLES (Created in dependency order)
-- =============================================================================

-- Level 1: No dependencies
CREATE TABLE IF NOT EXISTS "Languages" (
    "lang_code"   VARCHAR(10)  PRIMARY KEY,
    "lang_name"   VARCHAR(100),
    "lang_family" VARCHAR(50),
    "script_type" VARCHAR(20)  DEFAULT 'latin',
    "is_active"   BOOLEAN      DEFAULT true,
    "created_at"  TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS "Keywords" (
    "keyword_id" SERIAL PRIMARY KEY,
    "label"      VARCHAR(100) NOT NULL UNIQUE,
    "category"   VARCHAR(50),
    "weight"     REAL         DEFAULT 1.0,
    "is_active"  BOOLEAN      DEFAULT true,
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Level 2: No dependencies
CREATE TABLE IF NOT EXISTS "Documents" (
    "document_id"   SERIAL PRIMARY KEY,
    "document_type" VARCHAR(100) NOT NULL,
    "created_at"    TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    "updated_at"    TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    "deleted_at"    TIMESTAMP WITH TIME ZONE,
    CONSTRAINT "chk_document_type" CHECK (LENGTH(TRIM("document_type")) > 0)
) WITH (fillfactor = 80);

-- Level 2b: Pictures_Metadata (NEW - Image metadata extracted from files)
-- Depends only on itself, referenced by Pictures
CREATE TABLE IF NOT EXISTS "Pictures_Metadata" (
    "metadata_id"           SERIAL PRIMARY KEY,
    
    -- File properties (moved from Pictures)
    "file_size_bytes"       BIGINT,
    "image_width"           INTEGER,
    "image_height"          INTEGER,
    "mime_type"             VARCHAR(50),
    
    -- Original file information
    "original_filename"     VARCHAR(500),
    "original_extension"    VARCHAR(20),
    
    -- EXIF metadata (when available)
    "exif_make"             VARCHAR(100),      -- Camera manufacturer
    "exif_model"            VARCHAR(100),      -- Camera model
    "exif_datetime"         TIMESTAMP WITH TIME ZONE,  -- Date/time taken
    "exif_software"         VARCHAR(100),      -- Software used
    "exif_orientation"      INTEGER,           -- EXIF orientation tag (1-8)
    "exif_x_resolution"     INTEGER,           -- X resolution (DPI)
    "exif_y_resolution"     INTEGER,           -- Y resolution (DPI)
    "exif_resolution_unit"  VARCHAR(20),       -- inch/cm
    
    -- Color and bit depth
    "color_mode"            VARCHAR(20),       -- RGB, CMYK, Grayscale, etc.
    "bit_depth"             INTEGER,           -- bits per channel
    "has_alpha"             BOOLEAN            DEFAULT false,
    
    -- Compression info
    "compression_type"      VARCHAR(50),       -- JPEG, PNG, TIFF, etc.
    "compression_quality"   INTEGER,           -- 1-100 for JPEG
    
    -- Image processing history
    "preprocessing_method"  VARCHAR(50),       -- denoise, clahe, etc.
    "preprocessed_at"       TIMESTAMP WITH TIME ZONE,
    "preprocessing_version" VARCHAR(50),
    "preprocessed_image_path" TEXT,            -- MinIO/S3 path to preprocessed image
    
    -- Raw EXIF data as JSONB for extensibility
    "raw_exif_data"         JSONB,
    
    -- Timestamps
    "created_at"            TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    "updated_at"            TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints
    CONSTRAINT "chk_file_size_positive" CHECK (
        "file_size_bytes" IS NULL OR "file_size_bytes" > 0
    ),
    CONSTRAINT "chk_image_dimensions" CHECK (
        ("image_width" IS NULL OR "image_width" > 0) AND
        ("image_height" IS NULL OR "image_height" > 0)
    ),
    CONSTRAINT "chk_compression_quality" CHECK (
        "compression_quality" IS NULL OR 
        ("compression_quality" >= 1 AND "compression_quality" <= 100)
    )
) WITH (fillfactor = 90);

-- Level 3: Depends on Documents, Pictures_Metadata
CREATE TABLE IF NOT EXISTS "Pictures" (
    "picture_id"        SERIAL PRIMARY KEY,
    "document_id"       INTEGER NOT NULL,
    "metadata_id"       INTEGER,                        -- FK to Pictures_Metadata (NEW)
    "sha256_hash"       CHAR(64)        NOT NULL,
    "file_path"         TEXT            NOT NULL,
    "boxed_image_path"  TEXT,
    "archive_origin"    VARCHAR(50),
    "collection_type"   VARCHAR(100),
    "processed_at"      TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    "updated_at"        TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    -- Foreign keys
    FOREIGN KEY("document_id") REFERENCES "Documents"("document_id") ON DELETE CASCADE,
    FOREIGN KEY("metadata_id") REFERENCES "Pictures_Metadata"("metadata_id") ON DELETE SET NULL,
    
    -- Constraints
    CONSTRAINT "chk_sha256_length" CHECK (LENGTH("sha256_hash") = 64)
) WITH (fillfactor = 90);

CREATE UNIQUE INDEX IF NOT EXISTS "idx_pictures_hash_unique" ON "Pictures" ("sha256_hash");

-- Level 4: Depends on Documents, Pictures
CREATE TABLE IF NOT EXISTS "Texts" (
    "text_id"                  SERIAL PRIMARY KEY,
    "document_id"              INTEGER NOT NULL,
    "picture_id"               INTEGER,
    "original_raw_text"        TEXT NOT NULL,
    "corrected_text"           TEXT,
    "raw_text_sha256"          CHAR(64),
    "confidence_score"         REAL
                               CHECK ("confidence_score" IS NULL
                                   OR ("confidence_score" >= 0 AND "confidence_score" <= 1)),
    "user_chosen_language"     VARCHAR(10),
    "detected_language_code"   VARCHAR(10),
    "model_version"            VARCHAR(200),
    "model_details"            JSONB,
    "inference_mode"           inference_mode DEFAULT 'Balanced',
    "text_origin"              text_origin NOT NULL DEFAULT 'OCR',
    "character_count"          INTEGER GENERATED ALWAYS AS (LENGTH("original_raw_text")) STORED,
    "word_count"               INTEGER GENERATED ALWAYS AS (
                                   CASE
                                       WHEN "original_raw_text" = '' THEN 0
                                       ELSE array_length(regexp_split_to_array(trim("original_raw_text"), '\s+'), 1)
                                   END
                               ) STORED,
    "processed_at"             TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    "last_corrected_at"        TIMESTAMP WITH TIME ZONE,
    "created_at"               TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    "updated_at"               TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY("document_id") REFERENCES "Documents"("document_id") ON DELETE CASCADE,
    FOREIGN KEY("picture_id")  REFERENCES "Pictures"("picture_id")  ON DELETE SET NULL,
    CONSTRAINT "chk_raw_text_sha256" CHECK ("raw_text_sha256" IS NULL OR LENGTH("raw_text_sha256") = 64)
) WITH (fillfactor = 80);

-- Level 5: Depends on Texts
CREATE TABLE IF NOT EXISTS "Text_Segments" (
    "segment_id"       SERIAL PRIMARY KEY,
    "text_id"          INTEGER NOT NULL,
    "segment_number"   INTEGER NOT NULL,
    "category"         VARCHAR(50)    DEFAULT 'text_region',
    "confidence_score" REAL
                       CHECK ("confidence_score" IS NULL
                           OR ("confidence_score" >= 0 AND "confidence_score" <= 1)),
    "bbox_xmin"        REAL,
    "bbox_ymin"        REAL,
    "bbox_xmax"        REAL,
    "bbox_ymax"        REAL,
    "bbox_area"        REAL GENERATED ALWAYS AS (
                           CASE WHEN "bbox_xmin" IS NOT NULL AND "bbox_ymax" IS NOT NULL
                           THEN ("bbox_xmax" - "bbox_xmin") * ("bbox_ymax" - "bbox_ymin")
                           ELSE NULL END
                       ) STORED,
    "polygon_coords"   JSONB,
    "line_count"       INTEGER DEFAULT 0,
    "created_at"       TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    "updated_at"       TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY("text_id") REFERENCES "Texts"("text_id") ON DELETE CASCADE,
    CONSTRAINT "chk_segment_number" CHECK ("segment_number" > 0),
    CONSTRAINT "chk_bbox_coords"    CHECK (
        "bbox_xmax" IS NULL OR "bbox_xmin" IS NULL OR "bbox_xmax" >= "bbox_xmin"
    )
) WITH (fillfactor = 90);

-- Level 5: Depends on Texts, Text_Segments
CREATE TABLE IF NOT EXISTS "Text_Lines" (
    "line_id"          SERIAL PRIMARY KEY,
    "text_id"          INTEGER NOT NULL,
    "segment_id"       INTEGER,
    "line_segment_id"  INTEGER,
    "line_number"      INTEGER NOT NULL,
    "line_text"        TEXT        NOT NULL,
    "confidence_score" REAL
                       CHECK ("confidence_score" IS NULL
                           OR ("confidence_score" >= 0 AND "confidence_score" <= 1)),
    "bbox_xmin"        REAL,
    "bbox_ymin"        REAL,
    "bbox_xmax"        REAL,
    "bbox_ymax"        REAL,
    "polygon_coords"   JSONB,
    "orientation"      text_line_orientation DEFAULT 'upright',
    "is_corrected"     BOOLEAN DEFAULT false,
    "corrected_at"     TIMESTAMP WITH TIME ZONE,
    "corrected_by"     VARCHAR(100),
    "created_at"       TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    "updated_at"       TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY("text_id")         REFERENCES "Texts"("text_id")         ON DELETE CASCADE,
    FOREIGN KEY("line_segment_id") REFERENCES "Text_Segments"("segment_id") ON DELETE SET NULL,
    CONSTRAINT "chk_line_number"   CHECK ("line_number" > 0),
    CONSTRAINT "chk_line_bbox"     CHECK (
        "bbox_xmax" IS NULL OR "bbox_xmin" IS NULL OR "bbox_xmax" >= "bbox_xmin"
    )
) WITH (fillfactor = 90);

-- Level 5: Depends on Texts, Languages
CREATE TABLE IF NOT EXISTS "Text_Language_Detections" (
    "detection_id"     SERIAL PRIMARY KEY,
    "text_id"          INTEGER NOT NULL,
    "lang_code"        VARCHAR(10) NOT NULL,
    "confidence"       REAL        NOT NULL CHECK ("confidence" >= 0 AND "confidence" <= 1),
    "rank"             INTEGER     NOT NULL CHECK ("rank" >= 0),
    "detection_method" VARCHAR(50) DEFAULT 'fasttext',
    "detected_at"      TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY ("text_id")  REFERENCES "Texts"("text_id")     ON DELETE CASCADE,
    FOREIGN KEY ("lang_code") REFERENCES "Languages" ("lang_code"),
    CONSTRAINT "uq_text_lang_rank" UNIQUE ("text_id", "rank")
) WITH (fillfactor = 90);

-- Level 6: Depends on Documents, Texts
CREATE TABLE IF NOT EXISTS "Processing_Status" (
    "document_id"   INTEGER          NOT NULL,
    "status"        processing_status NOT NULL DEFAULT 'Pending',
    "current_stage" VARCHAR(50),
    "error_log"     TEXT,
    "retry_count"   INTEGER DEFAULT 0,
    "text_id"       INTEGER,
    "created_at"    TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    "updated_at"    TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY("document_id"),
    FOREIGN KEY("document_id") REFERENCES "Documents"("document_id") ON DELETE CASCADE,
    FOREIGN KEY("text_id")     REFERENCES "Texts"("text_id")         ON DELETE SET NULL
) WITH (fillfactor = 70);

-- Level 6: Depends on Texts
CREATE TABLE IF NOT EXISTS "Metadata_Entities" (
    "entity_id"          SERIAL PRIMARY KEY,
    "text_id"            INTEGER NOT NULL,
    "entity_type"        VARCHAR(50) NOT NULL,
    "entity_value"       TEXT        NOT NULL,
    "start_char"         INTEGER,
    "end_char"           INTEGER,
    "confidence_score"   REAL
                         CHECK ("confidence_score" IS NULL
                             OR ("confidence_score" >= 0 AND "confidence_score" <= 1)),
    "extraction_method"  VARCHAR(50) DEFAULT 'rule-based',
    "verified"           BOOLEAN DEFAULT false,
    "verified_by"        VARCHAR(100),
    "verified_at"        TIMESTAMP WITH TIME ZONE,
    "created_at"         TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY("text_id") REFERENCES "Texts"("text_id") ON DELETE CASCADE,
    CONSTRAINT "chk_char_positions" CHECK (
        "start_char" IS NULL OR "end_char" IS NULL OR "end_char" >= "start_char"
    )
);

CREATE TABLE IF NOT EXISTS "Metadata_Sensitive" (
    "pii_id"              SERIAL PRIMARY KEY,
    "text_id"             INTEGER NOT NULL,
    "pii_type"            VARCHAR(100) NOT NULL,
    "pii_value"           TEXT        NOT NULL,
    "start_char"          INTEGER,
    "end_char"            INTEGER,
    "detection_method"    VARCHAR(100) NOT NULL,
    "confidence_score"    REAL
                          CHECK ("confidence_score" IS NULL
                              OR ("confidence_score" >= 0 AND "confidence_score" <= 1)),
    "is_confirmed"        BOOLEAN         DEFAULT false,
    "confirmation_status" pii_confirmation DEFAULT 'Pending',
    "confirmed_by"        VARCHAR(100),
    "confirmed_at"        TIMESTAMP WITH TIME ZONE,
    "masked_value"        TEXT,
    "created_at"          TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY("text_id") REFERENCES "Texts"("text_id") ON DELETE CASCADE,
    CONSTRAINT "chk_pii_char_positions" CHECK (
        "start_char" IS NULL OR "end_char" IS NULL OR "end_char" >= "start_char"
    )
);

CREATE TABLE IF NOT EXISTS "Sentiment_Analysis" (
    "sentiment_id"   SERIAL PRIMARY KEY,
    "text_id"        INTEGER NOT NULL,
    "label"          VARCHAR(20) NOT NULL,
    "score"          REAL        NOT NULL CHECK ("score" >= 0 AND "score" <= 1),
    "model_version"  VARCHAR(100),
    "model_name"     VARCHAR(100),
    "analyzed_at"    TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY("text_id") REFERENCES "Texts"("text_id") ON DELETE CASCADE,
    CONSTRAINT "chk_sentiment_label" CHECK ("label" IN ('positive', 'negative', 'neutral'))
);

-- Level 6: Depends on Documents
CREATE TABLE IF NOT EXISTS "Metadata_General" (
    "gen_meta_id"       SERIAL PRIMARY KEY,
    "document_id"       INTEGER NOT NULL,
    "category"          VARCHAR(100) NOT NULL,
    "key"               VARCHAR(100) NOT NULL,
    "value_text"        TEXT,
    "value_number"      REAL,
    "value_boolean"     BOOLEAN,
    "value_json"        JSONB,
    "metadata_sha256"   CHAR(64),
    "indexer_version"   VARCHAR(100),
    "created_at"        TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    "updated_at"        TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY("document_id") REFERENCES "Documents"("document_id") ON DELETE CASCADE,
    CONSTRAINT "uq_doc_category_key" UNIQUE ("document_id", "category", "key")
);

-- Level 7: Depends on Documents, Keywords
CREATE TABLE IF NOT EXISTS "Document_Keywords" (
    "document_id"         INTEGER NOT NULL,
    "keyword_id"          INTEGER NOT NULL,
    "relevance_score"     REAL
                          CHECK ("relevance_score" IS NULL OR ("relevance_score" >= 0 AND "relevance_score" <= 1)),
    "frequency"           INTEGER DEFAULT 1,
    "first_occurrence_at" TIMESTAMP WITH TIME ZONE,
    "created_at"          TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY("document_id", "keyword_id"),
    FOREIGN KEY("document_id") REFERENCES "Documents"("document_id") ON DELETE CASCADE,
    FOREIGN KEY("keyword_id")  REFERENCES "Keywords"("keyword_id")   ON DELETE CASCADE
);

-- =============================================================================
-- 3. INDEXES
-- =============================================================================

CREATE INDEX "idx_pictures_hash"        ON "Pictures"        ("sha256_hash");
CREATE INDEX "idx_pictures_doc_id"      ON "Pictures"        ("document_id");
CREATE INDEX "idx_pictures_metadata_id" ON "Pictures"        ("metadata_id");

CREATE INDEX "idx_metadata_original_filename" ON "Pictures_Metadata" ("original_filename")
                                               WHERE "original_filename" IS NOT NULL;
CREATE INDEX "idx_metadata_mime_type"         ON "Pictures_Metadata" ("mime_type");
CREATE INDEX "idx_metadata_exif_datetime"     ON "Pictures_Metadata" ("exif_datetime")
                                               WHERE "exif_datetime" IS NOT NULL;
CREATE INDEX "idx_metadata_preprocessed_path" ON "Pictures_Metadata" ("preprocessed_image_path")
                                               WHERE "preprocessed_image_path" IS NOT NULL;

CREATE INDEX "idx_texts_document_id"    ON "Texts"           ("document_id");

CREATE INDEX "idx_segments_text_id"     ON "Text_Segments"   ("text_id");
CREATE INDEX "idx_segments_polygon"     ON "Text_Segments"   ("text_id")
                                        WHERE "polygon_coords" IS NOT NULL;

CREATE INDEX "idx_lines_text_id"        ON "Text_Lines"      ("text_id");
CREATE INDEX "idx_lines_segment_id"     ON "Text_Lines"      ("line_segment_id")
                                        WHERE "line_segment_id" IS NOT NULL;
CREATE INDEX "idx_lines_polygon"        ON "Text_Lines"      ("text_id")
                                        WHERE "polygon_coords" IS NOT NULL;
CREATE INDEX "idx_lines_orientation"    ON "Text_Lines"      ("text_id", "orientation");

CREATE INDEX "idx_langdetect_text_id"   ON "Text_Language_Detections" ("text_id");
CREATE INDEX "idx_langdetect_lang_code" ON "Text_Language_Detections" ("lang_code");

CREATE INDEX "idx_entities_text_id"     ON "Metadata_Entities"   ("text_id");
CREATE INDEX "idx_sensitive_text_id"   ON "Metadata_Sensitive"  ("text_id");
CREATE INDEX "idx_sentiment_text_id"   ON "Sentiment_Analysis"  ("text_id");
CREATE INDEX "idx_genmeta_document_id" ON "Metadata_General"    ("document_id");

-- =============================================================================
-- 4. COMMENTS
-- =============================================================================

COMMENT ON TABLE "Pictures_Metadata" IS
    'Stores comprehensive metadata extracted from image files including EXIF data, '
    'file properties, and preprocessing information. One-to-one relationship with Pictures.';

COMMENT ON COLUMN "Pictures_Metadata"."original_filename" IS
    'Alkuperäinen ladatun kuvatiedoston nimi (esim. "kirkonkirja_1890_sivu5.jpg"). '
    'Säilytetään viittauksen ja käyttöliittymän näyttöä varten.';

COMMENT ON COLUMN "Pictures_Metadata"."raw_exif_data" IS
    'Raaka EXIF-metadata JSON-muodossa. Sisältää kaikki kuvatiedoston EXIF-kentät '
    'joita ei ole erikseen tallennettu. Mahdollistaa myöhempien kenttien lisäämisen.';

COMMENT ON COLUMN "Pictures_Metadata"."preprocessing_method" IS
    'Kuvankäsittelymenetelmä jota käytettiin ennen HTR-inferenssiä: '
    'denoise, clahe, stretch, auto, none.';

COMMENT ON COLUMN "Pictures_Metadata"."preprocessed_image_path" IS
    'MinIO/S3 polku esikäsitellylle kuvalle. Muoto: {sha256}_preprocessed.jpg. '
    'NULL jos kuvaa ei esikäsitelty (preprocessing_method = none).';

COMMENT ON TABLE "Text_Segments" IS
    'Text regions detected by RF-DETR (class_id=1, text_region). '
    'Each row is one container polygon that encloses one or more individual text lines. '
    'Links to Text_Lines via Text_Lines.line_segment_id → Text_Segments.segment_id.';

COMMENT ON COLUMN "Text_Segments"."polygon_coords" IS
    'Full polygon vertex array as JSONB: [[x1,y1],[x2,y2],[x3,y3],...]. '
    'Describes the exact boundary of the text region.';

COMMENT ON COLUMN "Text_Segments"."line_count" IS
    'Denormalised count of Text_Lines rows whose line_segment_id references this segment_id.';

COMMENT ON TABLE "Text_Lines" IS
    'Individual text lines detected by RF-DETR (class_id 2-5). '
    'Each row is one line of text. line_segment_id points to the parent Text_Segments region '
    '(or NULL if the line has no parent region). '
    'polygon_coords stores the line''s own polygon — NOT the region polygon.';

COMMENT ON COLUMN "Text_Lines"."polygon_coords" IS
    'Full polygon vertex array as JSONB: [[x1,y1],[x2,y2],[x3,y3],...]. '
    'Describes the exact boundary of this individual text line.';

COMMENT ON COLUMN "Text_Lines"."orientation" IS
    'Text line orientation from RF-DETR: upright | upside_down | rotated_cw | rotated_ccw. '
    'Maps to model class_ids 2-5 respectively.';

COMMENT ON COLUMN "Text_Lines"."line_segment_id" IS
    'FK to Text_Segments.segment_id — the parent text region that contains this line. '
    'NULL if this line was detected without a parent region (standalone detection).';

COMMENT ON COLUMN "Text_Lines"."segment_id" IS
    'Parent region ID from RF-DETR detection. NULL when inserting, matches line_segment_id.';

-- =============================================================================
-- 5. INITIAL DATA: Populate Languages Table
-- =============================================================================

INSERT INTO "Languages" ("lang_code", "lang_name", "lang_family", "script_type", "is_active")
VALUES
    -- Germanic
    ('en', 'English',      'Germanic', 'latin',    true),
    ('de', 'German',       'Germanic', 'latin',    true),
    ('nl', 'Dutch',        'Germanic', 'latin',    true),
    ('sv', 'Swedish',      'Germanic', 'latin',    true),
    ('da', 'Danish',       'Germanic', 'latin',    true),
    ('no', 'Norwegian',    'Germanic', 'latin',    true),
    ('is', 'Icelandic',    'Germanic', 'latin',    true),
    
    -- Uralic
    ('fi', 'Finnish',      'Uralic',   'latin',    true),
    ('et', 'Estonian',     'Uralic',   'latin',    true),
    ('hu', 'Hungarian',    'Uralic',   'latin',    true),
    
    -- Baltic
    ('lv', 'Latvian',      'Baltic',   'latin',    true),
    ('lt', 'Lithuanian',   'Baltic',   'latin',    true),
    
    -- Slavic
    ('ru', 'Russian',      'Slavic',   'cyrillic', true),
    ('pl', 'Polish',       'Slavic',   'latin',    true),
    ('cs', 'Czech',        'Slavic',   'latin',    true),
    ('sk', 'Slovak',       'Slavic',   'latin',    true),
    ('uk', 'Ukrainian',    'Slavic',   'cyrillic', true),
    
    -- Romance
    ('fr', 'French',       'Romance',  'latin',    true),
    ('es', 'Spanish',      'Romance',  'latin',    true),
    ('it', 'Italian',      'Romance',  'latin',    true),
    ('pt', 'Portuguese',   'Romance',  'latin',    true),
    ('ro', 'Romanian',     'Romance',  'latin',    true),
    ('la', 'Latin',        'Romance',  'latin',    true)
ON CONFLICT ("lang_code") DO UPDATE SET
    "lang_name"   = EXCLUDED."lang_name",
    "lang_family" = EXCLUDED."lang_family",
    "script_type" = EXCLUDED."script_type";