from pydantic import BaseModel, ConfigDict, Field
from typing import List, Optional


class EnhanceRequest(BaseModel):
    """Request to enhance a single image (post-inference)."""
    model_config = ConfigDict(frozen=True)
    
    image_base64: str = Field(..., description="Base64-encoded PNG/JPEG image")
    method: str = Field(
        default="contrast",
        description="Method: 'default', 'contrast', 'binary', 'sharpen', 'denoise', 'upscale'"
    )
    return_base64: bool = Field(default=True)


class EnhanceBatchRequest(BaseModel):
    """Request to enhance multiple images."""
    model_config = ConfigDict(frozen=True)
    
    images_base64: List[str] = Field(..., description="List of base64-encoded images")
    method: str = Field(default="contrast")
    return_base64: bool = Field(default=True)


class EnhanceResponse(BaseModel):
    """Response with enhanced image."""
    model_config = ConfigDict(frozen=True)
    
    enhanced_base64: Optional[str] = Field(None)
    enhanced_size_bytes: Optional[int] = Field(None)
    method_used: str
    original_size_bytes: int


class EnhanceBatchResponse(BaseModel):
    """Response with multiple enhanced images."""
    model_config = ConfigDict(frozen=True)
    
    results: List[EnhanceResponse]
    total_count: int
    success_count: int
    failed_count: int


class MethodResult(BaseModel):
    """Result for a single enhancement method."""
    model_config = ConfigDict(frozen=True)
    
    method: str
    enhanced_base64: Optional[str] = None
    enhanced_size_bytes: Optional[int] = None
    success: bool
    error: Optional[str] = None


class EnhanceAllMethodsRequest(BaseModel):
    """Request to apply ALL enhancement methods at once."""
    model_config = ConfigDict(frozen=True)
    
    image_base64: str = Field(..., description="Base64-encoded image")
    return_base64: bool = Field(default=True)


class EnhanceAllMethodsResponse(BaseModel):
    """Response with all enhancement methods applied."""
    model_config = ConfigDict(frozen=True)
    
    original_size_bytes: int
    methods: List[MethodResult]
    available_methods: List[str] = [
        "default", "contrast", "binary", "sharpen", "denoise", "upscale"
    ]


class PreprocessRequest(BaseModel):
    """Request to preprocess image for historical manuscripts (pre-inference)."""
    model_config = ConfigDict(frozen=True)
    
    image_base64: str = Field(..., description="Base64-encoded PNG/JPEG image")
    method: str = Field(
        default="auto",
        description="Method: 'auto' (recommended), 'denoise', 'denoise_strong', 'clahe', 'stretch', 'none'"
    )
    return_base64: bool = Field(default=True)


class PreprocessResponse(BaseModel):
    """Response with preprocessed image."""
    model_config = ConfigDict(frozen=True)
    
    preprocessed_base64: Optional[str] = Field(None)
    preprocessed_size_bytes: Optional[int] = Field(None)
    method_used: str
    original_size_bytes: int
    description: str = "Preprocessed image"


class HealthResponse(BaseModel):
    """Health check response."""
    model_config = ConfigDict(frozen=True)
    
    status: str = "healthy"
    service: str = "image-enhance"
    available_methods: List[str] = [
        "default", "contrast", "binary", "sharpen", "denoise", "upscale"
    ]
    preprocessing_methods: List[str] = ["auto", "denoise", "denoise_strong", "clahe", "stretch", "none"]