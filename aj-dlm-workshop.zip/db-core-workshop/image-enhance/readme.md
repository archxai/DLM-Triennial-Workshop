# Image Enhancement Service

A FastAPI microservice for image enhancement and preprocessing in HTR (Handwritten Text Recognition) pipelines. Designed to optimize historical manuscript images for better OCR/HTR recognition accuracy.

## 📋 Overview

This service provides preprocessing and enhancement methods for historical documents. It analyzes image quality metrics and automatically selects the optimal preprocessing method, or allows manual method selection.

**Key Features:**
- Automatic quality analysis and method selection
- Multiple preprocessing methods optimized for manuscripts
- Post-inference enhancement options
- Batch processing support
- Environment-configurable parameters

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                      htr-core (Main Service)                     │
│                                                                   │
│   ┌─────────────┐    ┌────────────────────┐    ┌─────────────┐  │
│   │ Image Input │───▶│ /preprocess        │───▶│ TrOCR HTR   │  │
│   │ (bytes)     │    │ (denoise/auto/etc) │    │ (Inference) │  │
│   └─────────────┘    └────────────────────┘    └─────────────┘  │
│                              ▲                                    │
│                              │                                    │
│                    ┌─────────┴─────────┐                        │
│                    │ image-enhance     │                        │
│                    │ (FastAPI :8102)   │                        │
│                    └───────────────────┘                        │
└─────────────────────────────────────────────────────────────────┘
```

### Integration Points

| Integration | Endpoint Used | Purpose |
|-------------|---------------|---------|
| htr-core | `POST /preprocess` | Pre-inference image preparation |
| htr-core | `POST /enhance` | Post-inference enhancement |
| htr-core | `POST /enhance/all` | Compare all enhancement methods |
| htr-core | `POST /analyze` | Get quality metrics & recommendations |

---

## 🔧 Preprocessing Methods

Preprocessing is applied **before** HTR inference to prepare raw document images.

### Available Methods

| Method | Description | Best For |
|--------|-------------|----------|
| `auto` | **Recommended.** Automatically detects best method based on image quality | Unknown document conditions |
| `denoise` | Light non-local means denoising | Standard historical manuscripts |
| `denoise_strong` | Stronger denoising (2× strength) | Very noisy, degraded documents |
| `clahe` | Contrast Limited Adaptive Histogram Equalization | Low contrast documents |
| `stretch` | Histogram normalization | Documents with poor dynamic range |
| `none` | Grayscale conversion only | Already clean documents |

### Method Selection Logic

When `method=auto` is used, the service analyzes the image and selects based on:

```
Image Analysis Metrics:
├── contrast       → RMS contrast (0-1)
├── brightness     → Mean pixel value (0-255)
├── dynamic_range  → 1st-99th percentile spread
├── noise_level    → High-frequency variance ratio
└── bleed_through  → Dark/light pixel distribution

Decision Tree:
┌────────────────────────────────────────────────────────────┐
│ contrast < 0.15 AND dynamic_range < 0.4                    │
│     └──▶ clahe (low contrast needs contrast enhancement)   │
├────────────────────────────────────────────────────────────┤
│ noise_level > 0.5                                          │
│     └──▶ denoise_strong (very noisy)                       │
├────────────────────────────────────────────────────────────┤
│ noise_level > 0.3                                          │
│     └──▶ denoise (moderately noisy)                        │
├────────────────────────────────────────────────────────────┤
│ bleed_through > 0.4                                        │
│     └──▶ denoise_strong (bleed-through reduction)          │
├────────────────────────────────────────────────────────────┤
│ dynamic_range < 0.3                                        │
│     └──▶ stretch (normalize histogram range)               │
├────────────────────────────────────────────────────────────┤
│ quality_score > 70                                         │
│     └──▶ none (already good quality)                       │
├────────────────────────────────────────────────────────────┤
│ DEFAULT                                                    │
│     └──▶ denoise (fallback)                                │
└────────────────────────────────────────────────────────────┘
```

---

## ✨ Enhancement Methods

Enhancement is applied **after** HTR inference for visualization or comparison.

### Available Methods

| Method | Description |
|--------|-------------|
| `default` | Return original image |
| `contrast` | CLAHE-based contrast enhancement |
| `binary` | Adaptive thresholding (black/white) |
| `sharpen` | Unsharp masking |
| `denoise` | Non-local means denoising |
| `upscale` | 2× upscaling with cubic interpolation |

---

## 🌐 API Reference

### Base URL
```
http://localhost:8102  # Docker
http://localhost:80    # Local development
```

### Endpoints

#### Health Check
```http
GET /health
```

**Response:**
```json
{
  "status": "healthy",
  "service": "image-enhance",
  "available_methods": ["default", "contrast", "binary", "sharpen", "denoise", "upscale"],
  "preprocessing_methods": ["auto", "denoise", "denoise_strong", "clahe", "stretch", "none"]
}
```

---

#### Preprocess Image (Primary Endpoint)
```http
POST /preprocess
Content-Type: application/json

{
  "image_base64": "...",
  "method": "auto",
  "return_base64": true
}
```

**Parameters:**
| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `image_base64` | string | required | Base64-encoded RGB image |
| `method` | string | `"auto"` | Preprocessing method |
| `return_base64` | boolean | `true` | Return image data or just metrics |

**Response:**
```json
{
  "preprocessed_base64": "...",
  "preprocessed_size_bytes": 321625,
  "method_used": "denoise",
  "original_size_bytes": 414075,
  "description": "Preprocessed image"
}
```

---

#### Analyze Image Quality
```http
POST /analyze
Content-Type: application/json

{
  "image_base64": "..."
}
```

**Response:**
```json
{
  "original_size_bytes": 7143796,
  "metrics": {
    "contrast": 0.18,
    "brightness": 180.5,
    "dynamic_range": 0.65,
    "noise_level": 0.25,
    "bleed_through": 0.35,
    "overall_quality": 72.5,
    "recommended_method": "denoise",
    "issues_detected": ["low_contrast"]
  },
  "recommended_method": "denoise",
  "quality_score": 72.5,
  "issues": ["low_contrast"]
}
```

---

#### Enhance Single Image
```http
POST /enhance
Content-Type: application/json

{
  "image_base64": "...",
  "method": "contrast",
  "return_base64": true
}
```

---

#### Enhance All Methods
```http
POST /enhance/all
Content-Type: application/json

{
  "image_base64": "...",
  "return_base64": true
}
```

Returns all enhancement methods in a single request for comparison.

---

#### Batch Enhancement
```http
POST /enhance/batch
Content-Type: application/json

{
  "images_base64": ["...", "...", "..."],
  "method": "denoise",
  "return_base64": true
}
```

---

## ⚙️ Configuration

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `DENOISE_STRENGTH` | `2.0` | Denoising intensity (1.0-10.0) |
| `CLAHE_CLIP_LIMIT` | `1.5` | CLAHE contrast limit (0.5-4.0) |

### Docker Configuration

```yaml
# docker-compose.yaml (db-core)
image-enhance-archxai:
  build:
    context: ./image-enhance
    dockerfile: Dockerfile
  container_name: image_enhance_api
  ports:
    - "8102:80"
  healthcheck:
    test: ["CMD", "curl", "-f", "http://localhost:80/health"]
    interval: 10s
    timeout: 5s
    retries: 3
```

---

## 🐳 Docker Deployment

### Build
```bash
cd db-core/image-enhance
docker build -t image-enhance:latest .
```

### Run
```bash
docker run -d \
  --name image-enhance \
  -p 8102:80 \
  -e DENOISE_STRENGTH=2.0 \
  -e CLAHE_CLIP_LIMIT=1.5 \
  image-enhance:latest
```

### Or via Docker Compose
```bash
cd db-core
docker compose up -d image-enhance-archxai
```

---

## 📝 Usage Examples

### Python (httpx)
```python
import httpx
import base64

# Load image
with open("manuscript.jpg", "rb") as f:
    image_b64 = base64.b64encode(f.read()).decode()

# Preprocess
async with httpx.AsyncClient() as client:
    response = await client.post(
        "http://localhost:8102/preprocess",
        json={
            "image_base64": image_b64,
            "method": "auto"
        }
    )
    result = response.json()
    
# Get preprocessed image
preprocessed_bytes = base64.b64decode(result["preprocessed_base64"])
```

### cURL
```bash
# Preprocess with auto-detection
curl -X POST "http://localhost:8102/preprocess" \
  -H "Content-Type: application/json" \
  -d '{
    "image_base64": "'$(base64 -w 0 manuscript.jpg)'",
    "method": "auto"
  }'

# Analyze image quality
curl -X POST "http://localhost:8102/analyze" \
  -H "Content-Type: application/json" \
  -d '{
    "image_base64": "'$(base64 -w 0 manuscript.jpg)'"
  }'
```

---

## 📁 Project Structure

```
image-enhance/
├── api_image_enhance.py      # FastAPI application & endpoints
├── func_image_enhance.py     # Core image processing functions
├── schemas/
│   └── image_enhance.py      # Pydantic models
├── Dockerfile
└── README.md
```

---

## 🔬 Technical Details

### Image Format
- **Input:** Base64-encoded RGB image (JPEG/PNG)
- **Output:** Base64-encoded RGB PNG image
- **Processing:** OpenCV (cv2) + NumPy

### Quality Metrics Calculation

```python
contrast       = gray.std() / 255.0                    # RMS contrast
brightness     = gray.mean()                           # Mean intensity
dynamic_range  = (np.percentile(gray, 99) - np.percentile(gray, 1)) / 255.0
noise_level    = min(1.0, cv2.Laplacian(gray).var() / (gray.var() + 1e-6))
bleed_through  = max(dark_area_ratio, light_area_ratio, bimodal_score)
quality_score  = contrast_contrib + dynamic_range_contrib - noise_penalty - bleed_penalty
```

### Denoising Parameters

```python
_light_denoise():
  h = DENOISE_STRENGTH (default: 2.0, range: 1.0-10.0)
  templateWindowSize = 5
  searchWindowSize = 11
  algorithm = cv2.fastNlMeansDenoising()
```

### CLAHE Parameters

```python
_light_clahe():
  clipLimit = CLAHE_CLIP_LIMIT (default: 1.5, range: 0.5-4.0)
  tileGridSize = (8, 8)
```

---

## 🚀 Performance

| Operation | Typical Latency |
|-----------|-----------------|
| Preprocess (denoise) | ~50-100ms for 1024×1024 image |
| Analyze (quality metrics) | ~20-30ms |
| Batch (10 images) | ~300-500ms total |

---

## 🔗 Related Services

| Service | Port | Purpose |
|---------|------|---------|
| PostgreSQL | 5432 | Metadata storage |
| MinIO | 9000 | Image storage |
| htr-core | 8081 | Main HTR inference |
| langdetect | 8101 | Language detection |
| **image-enhance** | **8102** | **Image preprocessing** |

---

## 📄 License

Part of the ArchXAI HTR ecosystem. See main repository for details.