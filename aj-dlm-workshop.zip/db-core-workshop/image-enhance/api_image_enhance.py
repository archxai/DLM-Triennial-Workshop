"""
Image Enhancement Service API
=============================
FastAPI microservice for image enhancement and preprocessing.
"""
import logging
from typing import List

import cv2
from fastapi import FastAPI, HTTPException

from func_image_enhance import (
    enhance_line_image,
    decode_base64_image,
    encode_image_to_base64,
    process_enhancement,
    process_preprocessing,
    analyze_image_quality,
)
from schemas.image_enhance import (
    EnhanceRequest,
    EnhanceBatchRequest,
    EnhanceResponse,
    EnhanceBatchResponse,
    EnhanceAllMethodsRequest,
    EnhanceAllMethodsResponse,
    MethodResult,
    PreprocessRequest,
    PreprocessResponse,
    HealthResponse,
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Image Enhancement Service",
    description="Microservice for image enhancement and preprocessing in HTR pipelines",
    version="1.0.0",
)

AVAILABLE_METHODS = ["default", "contrast", "binary", "sharpen", "denoise", "upscale"]
PREPROCESSING_METHODS = ["auto", "denoise", "denoise_strong", "clahe", "stretch", "none"]


@app.get("/health", response_model=HealthResponse)
async def health_check() -> HealthResponse:
    """Health check endpoint."""
    return HealthResponse(
        status="healthy",
        service="image-enhance",
        available_methods=AVAILABLE_METHODS,
        preprocessing_methods=PREPROCESSING_METHODS,
    )


@app.get("/", response_model=dict)
async def root() -> dict:
    """Root endpoint with service info."""
    return {
        "service": "image-enhance",
        "version": "1.0.0",
        "endpoints": {
            "health": "GET /health",
            "enhance_single": "POST /enhance",
            "enhance_batch": "POST /enhance/batch",
            "enhance_all_methods": "POST /enhance/all",
            "preprocess": "POST /preprocess",
            "analyze": "POST /analyze",
        },
        "enhance_methods": AVAILABLE_METHODS,
        "preprocessing_methods": PREPROCESSING_METHODS,
    }


@app.post("/analyze")
async def analyze_image(request: PreprocessRequest):
    """
    Analyze image quality and get preprocessing recommendations.
    
    Returns detailed metrics about the image and suggests the best
    preprocessing method based on detected issues.
    
    Example response:
    {
        "original_size_bytes": 7143796,
        "metrics": {
            "contrast": 0.18,
            "brightness": 180.5,
            "dynamic_range": 0.65,
            "noise_level": 0.25,
            "bleed_through": 0.35,
            "overall_quality": 72.5,
            "recommended_method": "denoise",
            "issues_detected": ["low_contrast"]
        },
        "recommended_method": "denoise",
        "quality_score": 72.5,
        "issues": ["low_contrast"]
    }
    """
    try:
        image_np, original_size = decode_base64_image(request.image_base64)
        gray = cv2.cvtColor(image_np, cv2.COLOR_RGB2GRAY)
        
        metrics = analyze_image_quality(gray)
        
        return {
            "original_size_bytes": original_size,
            "metrics": metrics,
            "recommended_method": metrics["recommended_method"],
            "quality_score": metrics["overall_quality"],
            "issues": metrics["issues_detected"],
        }
        
    except Exception as e:
        logger.error(f"Analysis failed: {e}")
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/enhance", response_model=EnhanceResponse)
async def enhance_image(request: EnhanceRequest) -> EnhanceResponse:
    """Enhance a single image using post-inference enhancement methods."""
    if request.method not in AVAILABLE_METHODS:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid method '{request.method}'. Available: {AVAILABLE_METHODS}"
        )
    
    try:
        enhanced_base64, enhanced_size, original_size, method_used = process_enhancement(
            base64_str=request.image_base64,
            method=request.method,
            return_base64=request.return_base64,
        )
        
        return EnhanceResponse(
            enhanced_base64=enhanced_base64 if request.return_base64 else None,
            enhanced_size_bytes=enhanced_size if request.return_base64 else None,
            method_used=method_used,
            original_size_bytes=original_size,
        )
        
    except ValueError as e:
        logger.error(f"Enhancement failed: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@app.post("/enhance/batch", response_model=EnhanceBatchResponse)
async def enhance_batch(request: EnhanceBatchRequest) -> EnhanceBatchResponse:
    """Enhance multiple images with the same method in one request."""
    if request.method not in AVAILABLE_METHODS:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid method '{request.method}'. Available: {AVAILABLE_METHODS}"
        )
    
    results: List[EnhanceResponse] = []
    success_count = 0
    failed_count = 0
    
    for i, image_base64 in enumerate(request.images_base64):
        try:
            enhanced_base64, enhanced_size, original_size, method_used = process_enhancement(
                base64_str=image_base64,
                method=request.method,
                return_base64=request.return_base64,
            )
            
            results.append(EnhanceResponse(
                enhanced_base64=enhanced_base64 if request.return_base64 else None,
                enhanced_size_bytes=enhanced_size if request.return_base64 else None,
                method_used=method_used,
                original_size_bytes=original_size,
            ))
            success_count += 1
            
        except Exception as e:
            logger.warning(f"Failed to enhance image {i}: {e}")
            results.append(EnhanceResponse(
                enhanced_base64=None,
                enhanced_size_bytes=None,
                method_used=request.method,
                original_size_bytes=0,
            ))
            failed_count += 1
    
    return EnhanceBatchResponse(
        results=results,
        total_count=len(request.images_base64),
        success_count=success_count,
        failed_count=failed_count,
    )


@app.post("/enhance/all", response_model=EnhanceAllMethodsResponse)
async def enhance_all_methods(request: EnhanceAllMethodsRequest) -> EnhanceAllMethodsResponse:
    """Apply ALL enhancement methods at once in a single request."""
    methods_results: List[MethodResult] = []
    original_size = 0
    
    try:
        image_np, original_size = decode_base64_image(request.image_base64)
        
        for method in AVAILABLE_METHODS:
            try:
                enhanced_np = enhance_line_image(image_np, method)
                
                if request.return_base64:
                    enhanced_base64, enhanced_size = encode_image_to_base64(enhanced_np)
                else:
                    enhanced_base64 = None
                    enhanced_size = None
                
                methods_results.append(MethodResult(
                    method=method,
                    enhanced_base64=enhanced_base64,
                    enhanced_size_bytes=enhanced_size,
                    success=True,
                    error=None,
                ))
            except Exception as e:
                logger.warning(f"Method '{method}' failed: {e}")
                methods_results.append(MethodResult(
                    method=method,
                    enhanced_base64=None,
                    enhanced_size_bytes=None,
                    success=False,
                    error=str(e),
                ))
        
        return EnhanceAllMethodsResponse(
            original_size_bytes=original_size,
            methods=methods_results,
        )
        
    except Exception as e:
        logger.error(f"Failed to process image: {e}")
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/preprocess", response_model=PreprocessResponse)
async def preprocess_image(request: PreprocessRequest) -> PreprocessResponse:
    """
    Preprocess image for historical manuscripts.
    
    Methods:
    - auto: Automatically detect best method based on image quality (recommended)
    - denoise: Light non-local means denoising (recommended)
    - denoise_strong: Stronger denoising for very noisy documents
    - clahe: Light CLAHE for subtle contrast enhancement
    - stretch: Mild histogram stretch (preserves contrast, just normalizes range)
    - none: No preprocessing - return grayscale copy
    
    The 'auto' method analyzes the image and selects the best preprocessing
    based on detected issues (low contrast, noise, bleed-through, etc.)
    """
    if request.method not in PREPROCESSING_METHODS:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid method '{request.method}'. Available: {PREPROCESSING_METHODS}"
        )
    
    try:
        preprocessed_base64, preprocessed_size, original_size, method_used = process_preprocessing(
            base64_str=request.image_base64,
            method=request.method,
            return_base64=request.return_base64,
        )
        
        logger.info(f"Preprocessed | Method: {method_used} | "
                   f"Original: {original_size}B -> Preprocessed: {preprocessed_size}B")
        
        return PreprocessResponse(
            preprocessed_base64=preprocessed_base64 if request.return_base64 else None,
            preprocessed_size_bytes=preprocessed_size if request.return_base64 else None,
            method_used=method_used,
            original_size_bytes=original_size,
            description="Preprocessed image"
        )
        
    except ValueError as e:
        logger.error(f"Preprocessing failed: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=80)