"""
Image Enhancement Functions
===========================
Provides preprocessing and enhancement methods for HTR/OCR processing.
"""
import base64
import io
import logging
import os
from typing import Tuple, List, Dict, Any

import cv2
import numpy as np
from PIL import Image

logger = logging.getLogger(__name__)


def enhance_line_image(image_np: np.ndarray, method: str = "default") -> np.ndarray:
    """
    Apply image enhancement for better OCR recognition (post-inference).
    """
    if method == "default":
        return image_np

    gray = cv2.cvtColor(image_np, cv2.COLOR_RGB2GRAY)

    if method == "contrast":
        clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
        enhanced = clahe.apply(gray)
        return cv2.cvtColor(enhanced, cv2.COLOR_GRAY2RGB)

    elif method == "binary":
        binary = cv2.adaptiveThreshold(
            gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            cv2.THRESH_BINARY, 21, 10
        )
        return cv2.cvtColor(binary, cv2.COLOR_GRAY2RGB)

    elif method == "sharpen":
        blurred = cv2.GaussianBlur(gray, (0, 0), 3)
        sharpened = cv2.addWeighted(gray, 1.5, blurred, -0.5, 0)
        return cv2.cvtColor(sharpened, cv2.COLOR_GRAY2RGB)

    elif method == "denoise":
        denoised = cv2.fastNlMeansDenoising(gray, None, 10, 7, 21)
        return cv2.cvtColor(denoised, cv2.COLOR_GRAY2RGB)

    elif method == "upscale":
        h, w = gray.shape
        upscaled = cv2.resize(gray, (w * 2, h * 2), interpolation=cv2.INTER_CUBIC)
        return cv2.cvtColor(upscaled, cv2.COLOR_GRAY2RGB)

    return image_np


def _light_denoise(gray: np.ndarray, strength: float = 2.0) -> np.ndarray:
    """
    Light denoising using non-local means.
    """
    h_param = float(os.getenv("DENOISE_STRENGTH", str(strength)))
    h_param = max(1.0, min(10.0, h_param))
    
    denoised = cv2.fastNlMeansDenoising(
        gray,
        None,
        h=h_param,
        templateWindowSize=5,
        searchWindowSize=11
    )
    
    return denoised


def _light_clahe(gray: np.ndarray, clip_limit: float = 1.5, tile_size: int = 8) -> np.ndarray:
    """
    Light CLAHE (Contrast Limited Adaptive Histogram Equalization).
    """
    clip_limit = float(os.getenv("CLAHE_CLIP_LIMIT", str(clip_limit)))
    clip_limit = max(0.5, min(4.0, clip_limit))
    
    clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=(tile_size, tile_size))
    return clahe.apply(gray)


def analyze_image_quality(gray: np.ndarray) -> Dict[str, Any]:
    """
    Analyze image quality metrics to determine best preprocessing method.
    
    Returns a dictionary with:
    - contrast: RMS contrast (0-1)
    - brightness: Mean brightness (0-255)
    - noise_level: Estimated noise level (0-1)
    - dynamic_range: How much of 0-255 range is used (0-1)
    - bleed_through: Estimated bleed-through level (0-1)
    - overall_quality: 0-100 quality score
    - recommended_method: Best preprocessing method
    """
    metrics = {}
    
    # 1. Calculate RMS Contrast (Michelson contrast on normalized image)
    contrast = gray.std() / 255.0
    metrics["contrast"] = float(contrast)
    
    # 2. Brightness (mean intensity)
    brightness = gray.mean()
    metrics["brightness"] = float(brightness)
    
    # 3. Dynamic range (percentile spread)
    p1, p99 = np.percentile(gray, [1, 99])
    dynamic_range = (p99 - p1) / 255.0
    metrics["dynamic_range"] = float(dynamic_range)
    
    # 4. Noise estimation using high-frequency component
    # Apply Laplacian and measure variance (high variance = more noise)
    laplacian = cv2.Laplacian(gray, cv2.CV_64F)
    noise_estimate = laplacian.var() / (gray.var() + 1e-6)
    noise_level = min(1.0, float(noise_estimate))
    metrics["noise_level"] = noise_level
    
    # 5. Bleed-through detection
    # High variance in background areas (very dark or very light regions)
    # indicates bleed-through from the other side of the page
    dark_pixels = gray[gray < 50]
    light_pixels = gray[gray > 200]
    
    bleed_indicator = 0.0
    if len(dark_pixels) > 0 and len(light_pixels) > 0:
        # If there are significant dark AND light areas, might have bleed-through
        bleed_indicator = min(1.0, (len(dark_pixels) + len(light_pixels)) / (gray.size * 0.3))
    
    # Also check for bimodal distribution (two peaks = bleed-through)
    hist = cv2.calcHist([gray], [0], None, [256], [0, 256]).flatten()
    hist_norm = hist / hist.sum()
    
    # Find if histogram has two distinct peaks (indicates bleed-through)
    threshold = gray.max() // 2
    left_mass = hist_norm[:threshold].sum()
    right_mass = hist_norm[threshold:].sum()
    
    bimodal_score = abs(left_mass - right_mass)
    if bimodal_score < 0.3:  # Roughly balanced histogram
        bleed_indicator = max(bleed_indicator, 0.5)
    
    metrics["bleed_through"] = bleed_indicator
    
    # 6. Calculate overall quality score (0-100)
    quality_score = 0.0
    
    # Contrast contribution (optimal around 0.2-0.4)
    if 0.15 <= contrast <= 0.5:
        quality_score += 30
    elif contrast < 0.15:
        quality_score += contrast * 200  # Low contrast penalty
    else:
        quality_score += max(0, 30 - (contrast - 0.5) * 50)
    
    # Dynamic range contribution
    quality_score += dynamic_range * 25
    
    # Noise penalty
    quality_score += max(0, 25 - noise_level * 50)
    
    # Bleed-through penalty
    quality_score += max(0, 20 - bleed_indicator * 40)
    
    metrics["overall_quality"] = float(quality_score)
    
    # 7. Determine recommended method
    recommended = "denoise"  # Default
    
    if contrast < 0.15 and dynamic_range < 0.4:
        # Very low contrast - needs CLAHE
        recommended = "clahe"
    elif noise_level > 0.3:
        # High noise - needs denoising
        recommended = "denoise_strong" if noise_level > 0.5 else "denoise"
    elif bleed_indicator > 0.4:
        # Significant bleed-through - denoise to reduce
        recommended = "denoise_strong"
    elif dynamic_range < 0.3:
        # Poor dynamic range - stretch might help
        recommended = "stretch"
    elif quality_score > 70:
        # Good quality - minimal processing
        recommended = "none"
    
    metrics["recommended_method"] = recommended
    
    # Add human-readable analysis
    issues = []
    if contrast < 0.15:
        issues.append("low_contrast")
    if noise_level > 0.3:
        issues.append("noisy")
    if bleed_indicator > 0.4:
        issues.append("bleed_through")
    if dynamic_range < 0.3:
        issues.append("poor_dynamic_range")
    
    metrics["issues_detected"] = issues
    
    return metrics


def preprocess_adaptive_threshold(image_np: np.ndarray, method: str = "denoise") -> np.ndarray:
    """
    Preprocess image for historical manuscripts.
    
    Methods:
    - denoise: Light non-local means denoising (recommended)
    - denoise_strong: Stronger denoising for very noisy documents
    - clahe: Light CLAHE for subtle contrast enhancement
    - stretch: Mild histogram stretch (preserves contrast, just normalizes range)
    - none: Return original grayscale (no preprocessing)
    - auto: Automatically detect best method based on image quality
    """
    # Convert to grayscale
    gray = cv2.cvtColor(image_np, cv2.COLOR_RGB2GRAY)
    
    # Get parameters from environment
    denoise_strength = float(os.getenv("DENOISE_STRENGTH", "2.0"))
    
    # Auto-detect method if requested
    if method == "auto":
        quality_metrics = analyze_image_quality(gray)
        method = quality_metrics["recommended_method"]
        logger.info(f"Auto-detected method: {method} | Quality: {quality_metrics['overall_quality']:.1f} | Issues: {quality_metrics['issues_detected']}")
    
    if method == "denoise":
        denoised = _light_denoise(gray, strength=denoise_strength)
        return cv2.cvtColor(denoised, cv2.COLOR_GRAY2RGB)
    
    elif method == "denoise_strong":
        denoised = _light_denoise(gray, strength=denoise_strength * 2.0)
        return cv2.cvtColor(denoised, cv2.COLOR_GRAY2RGB)
    
    elif method == "clahe":
        denoised = _light_denoise(gray, strength=denoise_strength * 1.5)
        clahe_applied = _light_clahe(denoised, clip_limit=1.5, tile_size=8)
        return cv2.cvtColor(clahe_applied, cv2.COLOR_GRAY2RGB)
    
    elif method == "stretch":
        in_min = np.percentile(gray, 1)
        in_max = np.percentile(gray, 99)
        
        if in_max > in_min:
            stretched = np.clip((gray - in_min) * 255.0 / (in_max - in_min), 0, 255)
        else:
            stretched = gray
        
        stretched = _light_denoise(stretched.astype(np.uint8), strength=denoise_strength * 0.5)
        return cv2.cvtColor(stretched, cv2.COLOR_GRAY2RGB)
    
    elif method == "none":
        return cv2.cvtColor(gray, cv2.COLOR_GRAY2RGB)
    
    else:
        denoised = _light_denoise(gray, strength=denoise_strength)
        return cv2.cvtColor(denoised, cv2.COLOR_GRAY2RGB)


def decode_base64_image(base64_str: str) -> Tuple[np.ndarray, int]:
    """Decode base64 string to numpy image array."""
    image_bytes = base64.b64decode(base64_str)
    original_size = len(image_bytes)
    
    image = Image.open(io.BytesIO(image_bytes))
    image_np = np.array(image.convert("RGB"))
    
    return image_np, original_size


def encode_image_to_base64(image_np: np.ndarray) -> Tuple[str, int]:
    """Encode numpy image array to base64 string."""
    pil_image = Image.fromarray(image_np)
    buffer = io.BytesIO()
    pil_image.save(buffer, format="PNG")
    image_bytes = buffer.getvalue()
    
    return base64.b64encode(image_bytes).decode("utf-8"), len(image_bytes)


def process_enhancement(
    base64_str: str, 
    method: str = "contrast",
    return_base64: bool = True
) -> Tuple[str, int, int, str]:
    """Process a single image enhancement (post-inference)."""
    try:
        image_np, original_size = decode_base64_image(base64_str)
        enhanced_np = enhance_line_image(image_np, method)
        
        if return_base64:
            enhanced_base64, enhanced_size = encode_image_to_base64(enhanced_np)
        else:
            enhanced_base64 = ""
            buffer = io.BytesIO()
            Image.fromarray(enhanced_np).save(buffer, format="PNG")
            enhanced_size = len(buffer.getvalue())
        
        return enhanced_base64, enhanced_size, original_size, method
        
    except Exception as e:
        raise ValueError(f"Failed to process image: {str(e)}")


def process_preprocessing(
    base64_str: str,
    method: str = "denoise",
    return_base64: bool = True
) -> Tuple[str, int, int, str]:
    """Process image preprocessing (pre-inference) using light denoising."""
    try:
        image_np, original_size = decode_base64_image(base64_str)
        preprocessed_np = preprocess_adaptive_threshold(image_np, method)
        
        if return_base64:
            preprocessed_base64, preprocessed_size = encode_image_to_base64(preprocessed_np)
        else:
            preprocessed_base64 = ""
            buffer = io.BytesIO()
            Image.fromarray(preprocessed_np).save(buffer, format="PNG")
            preprocessed_size = len(buffer.getvalue())
        
        return preprocessed_base64, preprocessed_size, original_size, method
        
    except Exception as e:
        raise ValueError(f"Failed to preprocess image: {str(e)}")