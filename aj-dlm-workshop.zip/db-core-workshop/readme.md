# ArchXAI DB-Core

Database and storage infrastructure for the ArchXAI HTR and OCR pipelines.

![ArchXAI DB-Core Architecture](./docs/images/db-core-visual.jpg)

## What It Does

- **PostgreSQL Database**: Stores document metadata, HTR results, text lines with bounding boxes, detected languages, and processing status.
- **SeaweedFS (S3-Compatible)**: Object storage for original and processed images using content-addressable storage (SHA256).
- **Adminer**: Web-based database management interface.

## Quick Start

```bash
cd db-core

# Copy and adjust environment variables
cp .env.example .env

# Start infrastructure
docker compose up -d

# Verify services are running
docker compose ps
```

## Access Services

The services below are exposed to the host machine. If running on a remote server, replace `localhost` with the server's IP address.

| Service | Local URL | IP:Port | Default Port |
|---------|-----------|---------|--------------|
| Adminer (DB GUI) | http://localhost:13100 | http://`<server_ip>`:13100 | 13100 |
| SeaweedFS (S3 API) | http://localhost:13101 | http://`<server_ip>`:13101 | 13101 |
| SeaweedFS (File Browser) | http://localhost:13105 | http://`<server_ip>`:13105 | 13105 |

### File Browser (Testing Only)

> **Warning:** The Filer UI has no authentication by default. Do NOT use in production!

Browse stored files in your browser:
```
http://localhost:12105
```

Navigate to `archxai-images` bucket to see uploaded images.

## Environment Variables

Default values from `.env.example`:

```env
# GENERAL
TZ=Europe/Helsinki

# DATABASE
DB_USER=archxai_user
DB_PASSWORD=archxai_pass123
DB_NAME=archxai_db
DB_DATA_PATH=./dbdata/postgres_archxai

# ADMINER
ADMINER_PORT=12100

# S3 STORAGE (SeaweedFS)
MINIO_ROOT_USER=archxai_admin
MINIO_ROOT_PASSWORD=archxai_secure_password_123
MINIO_DATA_PATH=./minio_data
MINIO_S3_PORT=12101
MINIO_FILER_PORT=12105
```

### Exposing Internal Services (Optional)

Internal services (language detection, image enhancement, metadata extraction) run in the Docker network by default. They are **not exposed** to the host unless explicitly enabled.

To expose them for debugging:

1. Uncomment the debug port lines in `.env`:
```env
# DEBUG PORTS - uncomment to enable host access
LANGDETECT_PORT=13102
IMAGE_ENHANCE_PORT=13103
METADATA_PORT=13104
DATA_RETRIEVER_PORT=13110
```

2. Restart the services:
```bash
docker compose down
docker compose up -d
```

| Service | Internal URL (Docker) | Debug Port |
|---------|----------------------|------------|
| Language Detection | http://langdetect-archxai/detectlanguage | 13102 |
| Image Enhancement | http://image-enhance-archxai/preprocess | 13103 |
| Metadata Extraction | http://metadata-archxai/extract | 13104 |
| Data Retriever API | http://data-retriever:8000 | 13110 |

### Direct Database Access

PostgreSQL is accessible only through Adminer by default. If you need direct `psql` access or desktop database tools (pgAdmin, DBeaver), enable the port in `docker-compose.yaml`:

```yaml
# In postgres-archxai service, uncomment the ports section:
ports:
  - "127.0.0.1:5432:5432"  # Bind to localhost only for security
```

Then connect with:
```bash
psql -h localhost -p 5432 -U archxai_user archxai_db
```

## Key Tables

| Table | Description |
|-------|-------------|
| **Documents** | Top-level grouping for related images |
| **Pictures** | Image metadata with SHA256 content-addressable storage |
| **Pictures_Metadata** | Comprehensive image metadata (EXIF, file properties) |
| **Texts** | HTR/OCR transcription results with confidence scores |
| **Text_Segments** | Text regions detected by RF-DETR |
| **Text_Lines** | Individual text lines with polygon boundaries |
| **Text_Language_Detections** | Detected languages with confidence rankings |
| **Processing_Status** | Pipeline status tracking |


## Database Schema

```mermaid
erDiagram
    Languages ||--o{ Text_Language_Detections : "detects"
    Keywords ||--o{ Document_Keywords : "tags"
    Documents ||--o{ Pictures : "contains"
    Documents ||--o{ Processing_Status : "tracks"
    Documents ||--o{ Metadata_General : "metadata"
    Documents ||--o{ Document_Keywords : "keywords"
    Pictures }o--|| Pictures_Metadata : "metadata"
    Pictures ||--o{ Texts : "transcribed"
    Texts ||--o{ Text_Segments : "regions"
    Texts ||--o{ Text_Lines : "lines"
    Texts ||--o{ Text_Language_Detections : "languages"
    Texts ||--o{ Processing_Status : "status"
    Texts ||--o{ Metadata_Entities : "entities"
    Texts ||--o{ Metadata_Sensitive : "pii"
    Texts ||--o{ Sentiment_Analysis : "sentiment"
    Text_Segments ||--o{ Text_Lines : "contains"

    Languages {
        varchar lang_code PK
        varchar lang_name
        varchar lang_family
        varchar script_type
        boolean is_active
        timestamptz created_at
    }

    Keywords {
        int keyword_id PK
        varchar label UK
        varchar category
        real weight
        boolean is_active
        timestamptz created_at
    }

    Documents {
        int document_id PK
        varchar document_type
        timestamptz created_at
        timestamptz updated_at
        timestamptz deleted_at
    }

    Pictures_Metadata {
        int metadata_id PK
        bigint file_size_bytes
        int image_width
        int image_height
        varchar mime_type
        varchar original_filename
        varchar original_extension
        varchar exif_make
        varchar exif_model
        timestamptz exif_datetime
        varchar exif_software
        int exif_orientation
        int exif_x_resolution
        int exif_y_resolution
        varchar exif_resolution_unit
        varchar color_mode
        int bit_depth
        boolean has_alpha
        varchar compression_type
        int compression_quality
        varchar preprocessing_method
        timestamptz preprocessed_at
        varchar preprocessing_version
        text preprocessed_image_path
        jsonb raw_exif_data
        timestamptz created_at
        timestamptz updated_at
    }

    Pictures {
        int picture_id PK
        int document_id FK
        int metadata_id FK
        char sha256_hash UK
        text file_path
        text boxed_image_path
        varchar archive_origin
        varchar collection_type
        timestamptz processed_at
        timestamptz updated_at
    }

    Texts {
        int text_id PK
        int document_id FK
        int picture_id FK
        text original_raw_text
        text corrected_text
        char raw_text_sha256
        real confidence_score
        varchar user_chosen_language
        varchar detected_language_code
        varchar model_version
        jsonb model_details
        inference_mode inference_mode
        text_origin text_origin
        int character_count
        int word_count
        timestamptz processed_at
        timestamptz last_corrected_at
        timestamptz created_at
        timestamptz updated_at
    }

    Text_Segments {
        int segment_id PK
        int text_id FK
        int segment_number
        varchar category
        real confidence_score
        real bbox_xmin
        real bbox_ymin
        real bbox_xmax
        real bbox_ymax
        real bbox_area
        jsonb polygon_coords
        int line_count
        timestamptz created_at
        timestamptz updated_at
    }

    Text_Lines {
        int line_id PK
        int text_id FK
        int segment_id
        int line_segment_id FK
        int line_number
        text line_text
        real confidence_score
        real bbox_xmin
        real bbox_ymin
        real bbox_xmax
        real bbox_ymax
        jsonb polygon_coords
        text_line_orientation orientation
        boolean is_corrected
        timestamptz corrected_at
        varchar corrected_by
        timestamptz created_at
        timestamptz updated_at
    }

    Text_Language_Detections {
        int detection_id PK
        int text_id FK
        varchar lang_code FK
        real confidence
        int rank
        varchar detection_method
        timestamptz detected_at
    }

    Processing_Status {
        int document_id PK, FK
        processing_status status
        varchar current_stage
        text error_log
        int retry_count
        int text_id FK
        timestamptz created_at
        timestamptz updated_at
    }

    Metadata_Entities {
        int entity_id PK
        int text_id FK
        varchar entity_type
        text entity_value
        int start_char
        int end_char
        real confidence_score
        varchar extraction_method
        boolean verified
        varchar verified_by
        timestamptz verified_at
        timestamptz created_at
    }

    Metadata_Sensitive {
        int pii_id PK
        int text_id FK
        varchar pii_type
        text pii_value
        int start_char
        int end_char
        varchar detection_method
        real confidence_score
        boolean is_confirmed
        pii_confirmation confirmation_status
        varchar confirmed_by
        timestamptz confirmed_at
        text masked_value
        timestamptz created_at
    }

    Sentiment_Analysis {
        int sentiment_id PK
        int text_id FK
        varchar label
        real score
        varchar model_version
        varchar model_name
        timestamptz analyzed_at
    }

    Metadata_General {
        int gen_meta_id PK
        int document_id FK
        varchar category
        varchar key
        text value_text
        real value_number
        boolean value_boolean
        jsonb value_json
        char metadata_sha256
        varchar indexer_version
        timestamptz created_at
        timestamptz updated_at
    }

    Document_Keywords {
        int document_id PK, FK
        int keyword_id PK, FK
        real relevance_score
        int frequency
        timestamptz first_occurrence_at
        timestamptz created_at
    }
```

**Legend:**
- `PK` = Primary Key
- `FK` = Foreign Key  
- `UK` = Unique Constraint
- `o--` = Optional relationship (zero or more)
- `||--` = Required relationship (one or more)


## Stop & Clean

```bash
# Stop services
docker compose down

# Remove all data (careful!)
docker compose down -v
rm -rf ./dbdata/postgres_archxai ./minio_data
```

## Troubleshooting

```bash
# Check logs
docker compose logs postgres-archxai
docker compose logs minio-archxai
docker compose logs adminer-archxai
```