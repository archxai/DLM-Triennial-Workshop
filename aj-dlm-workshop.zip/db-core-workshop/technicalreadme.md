# ArchXAI DB-Core - Technical Documentation

## Overview

The ArchXAI Data Infrastructure provides a robust, production-ready backend for storing and managing HTR (Handwritten Text Recognition) pipeline data. It combines PostgreSQL for relational data with SeaweedFS (S3-compatible) for binary object storage.

## Architecture

### Detection Model

The system uses **RF-DETR** (Kansallisarkisto/rfdetr-textline-textregion-detection-2xl) for text detection, which produces a hierarchical Region→Line structure:

| Class ID | Category | Description |
|----------|----------|-------------|
| 1 | `text_region` | Parent container polygon enclosing text lines |
| 2 | `upright` | Individual text line (normal orientation) |
| 3 | `upside_down` | Text line rotated 180° |
| 4 | `rotated_cw` | Text line rotated 90° clockwise |
| 5 | `rotated_ccw` | Text line rotated 90° counter-clockwise |

### Data Flow

1. **Image Ingestion**: Image uploaded to HTR API
2. **Preprocessing**: Optional image enhancement via image-enhance service
3. **Hash Generation**: SHA256 computed for content-addressable storage
4. **S3 Upload**: Image stored with hash as key (deduplication automatic)
5. **HTR Processing**: RF-DETR detection + TrOCR recognition produces text and polygons
6. **Language Detection**: FastText service analyzes text for language probabilities
7. **Persistence**: All results stored in PostgreSQL with proper relationships

## Database Connection

### Adminer (Default)

Use Adminer in your browser for database management:

```
http://localhost:12100
```

Connection settings:
- **Server**: `postgres-archxai`
- **Database**: `archxai_db`
- **User/Password**: from `.env`

### Direct psql Access (Optional)

PostgreSQL port is not exposed by default. To enable direct `psql` access:

1. Uncomment the ports section in `docker-compose.yaml`:
```yaml
# In postgres-archxai service:
ports:
  - "127.0.0.1:5432:5432"  # Bind to localhost only
```

2. Restart and connect:
```bash
docker compose down && docker compose up -d
psql -h localhost -p 5432 -U archxai_user archxai_db
```

### S3 Storage

The storage uses SeaweedFS with an S3-compatible API. Use any S3 client:

```bash
# AWS CLI
aws s3 ls s3://archxai-images --endpoint-url http://localhost:12101

# Python boto3
python3 << 'EOF'
import boto3

client = boto3.client(
    's3',
    endpoint_url='http://localhost:12101',
    aws_access_key_id='archxai_admin',
    aws_secret_access_key='archxai_secure_password_123'
)

# List buckets
response = client.list_buckets()
for bucket in response['Buckets']:
    print(f"  {bucket['Name']}")

# List objects in archxai-images bucket
response = client.list_objects_v2(Bucket='archxai-images')
for obj in response.get('Contents', []):
    print(f"  {obj['Key']} ({obj['Size']} bytes)")
EOF
```

## Database Schema

### Entity Relationship Diagram

```
Documents
    │
    ├── Pictures (1:N)
    │       │
    │       └── Texts (1:N)
    │               │
    │               ├── Text_Segments (1:N)  ← text_region containers
    │               │       │
    │               │       └── Text_Lines (N:1 via line_segment_id)
    │               │               ├── polygon_coords (exact line boundary)
    │               │               └── orientation (upright/rotated)
    │               │
    │               ├── Text_Language_Detections (1:N)
    │               │
    │               ├── Metadata_Entities (1:N)
    │               │
    │               ├── Metadata_Sensitive (1:N)
    │               │
    │               └── Sentiment_Analysis (1:N)
    │
    └── Processing_Status (1:1)
            │
            └── Metadata_General (1:N)
```

### Table Definitions

#### 1. Documents

Top-level logical grouping for HTR documents.

```sql
CREATE TABLE "Documents" (
    "document_id" SERIAL PRIMARY KEY,
    "document_type" VARCHAR(100) NOT NULL,
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP WITH TIME ZONE,  -- Soft delete for audit
    CONSTRAINT "chk_document_type" CHECK (LENGTH(TRIM("document_type")) > 0)
);
```

#### 2. Processing_Status

Real-time processing audit trail per document.

```sql
CREATE TABLE "Processing_Status" (
    "document_id" INTEGER PRIMARY KEY REFERENCES "Documents" ON DELETE CASCADE,
    "status" processing_status DEFAULT 'Pending',  -- Pending, Processing, Completed, Failed
    "current_stage" VARCHAR(50),
    "error_log" TEXT,
    "retry_count" INTEGER DEFAULT 0,
    "text_id" INTEGER REFERENCES "Texts" ON DELETE SET NULL,
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
```

#### 3. Pictures

Represents a single scanned page with metadata.

```sql
CREATE TABLE "Pictures" (
    "picture_id" SERIAL PRIMARY KEY,
    "document_id" INTEGER NOT NULL REFERENCES "Documents" ON DELETE CASCADE,
    "sha256_hash" CHAR(64) NOT NULL,  -- Content-addressable ID
    "file_path" TEXT NOT NULL,         -- S3 storage key
    "boxed_image_path" TEXT,           -- Visualization with polygon overlays
    "archive_origin" VARCHAR(50),
    "collection_type" VARCHAR(100),
    "file_size_bytes" BIGINT,
    "image_width" INTEGER,
    "image_height" INTEGER,
    "mime_type" VARCHAR(50),
    "processed_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
```

#### 4. Texts

Core result table storing HTR/OCR transcription results.

```sql
CREATE TABLE "Texts" (
    "text_id" SERIAL PRIMARY KEY,
    "document_id" INTEGER NOT NULL REFERENCES "Documents" ON DELETE CASCADE,
    "picture_id" INTEGER REFERENCES "Pictures" ON DELETE SET NULL,
    "original_raw_text" TEXT NOT NULL,
    "corrected_text" TEXT,  -- Updated by trigger when Text_Lines change
    "raw_text_sha256" CHAR(64),
    "confidence_score" REAL CHECK ("confidence_score" >= 0 AND "confidence_score" <= 1),
    "user_chosen_language" VARCHAR(10),      -- Language selected by user
    "detected_language_code" VARCHAR(10),    -- Language detected by FastText
    "model_version" VARCHAR(200),
    "model_details" JSONB,
    "inference_mode" inference_mode DEFAULT 'Balanced',
    "text_origin" text_origin DEFAULT 'OCR',
    "character_count" INTEGER GENERATED ALWAYS AS (LENGTH("original_raw_text")) STORED,
    "word_count" INTEGER GENERATED ALWAYS AS (
        CASE WHEN "original_raw_text" = '' THEN 0 
        ELSE array_length(regexp_split_to_array(trim("original_raw_text"), '\s+'), 1)
        END
    ) STORED,
    "processed_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    "last_corrected_at" TIMESTAMP WITH TIME ZONE,
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
```

#### 5. Text_Segments

Text regions detected by RF-DETR (class_id=1). Each row is one container polygon that encloses one or more individual text lines.

```sql
CREATE TABLE "Text_Segments" (
    "segment_id" SERIAL PRIMARY KEY,
    "text_id" INTEGER NOT NULL REFERENCES "Texts" ON DELETE CASCADE,
    "segment_number" INTEGER NOT NULL,
    "category" VARCHAR(50) DEFAULT 'text_region',  -- RF-DETR class: text_region
    "confidence_score" REAL,
    "bbox_xmin" REAL,
    "bbox_ymin" REAL,
    "bbox_xmax" REAL,
    "bbox_ymax" REAL,
    "bbox_area" REAL GENERATED ALWAYS AS (
        CASE WHEN "bbox_xmin" IS NOT NULL AND "bbox_ymax" IS NOT NULL 
        THEN ("bbox_xmax" - "bbox_xmin") * ("bbox_ymax" - "bbox_ymin") 
        ELSE NULL END
    ) STORED,
    "polygon_coords" JSONB,  -- [[x1,y1],[x2,y2],[x3,y3],...] full region boundary
    "line_count" INTEGER DEFAULT 0,  -- Denormalized count of child lines
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
```

#### 6. Text_Lines

Individual text lines detected by RF-DETR (class_id 2-5). Each row is one line of text with its own polygon boundary.

```sql
CREATE TABLE "Text_Lines" (
    "line_id" SERIAL PRIMARY KEY,
    "text_id" INTEGER NOT NULL REFERENCES "Texts" ON DELETE CASCADE,
    "segment_id" INTEGER,  -- Parent region ID from RF-DETR (NULL when inserting)
    "line_segment_id" INTEGER REFERENCES "Text_Segments" ON DELETE SET NULL,  -- Parent text region
    "line_number" INTEGER NOT NULL,
    "line_text" TEXT NOT NULL,
    "confidence_score" REAL,
    "bbox_xmin" REAL,
    "bbox_ymin" REAL,
    "bbox_xmax" REAL,
    "bbox_ymax" REAL,
    "polygon_coords" JSONB,  -- [[x1,y1],[x2,y2],[x3,y3],...] exact line boundary
    "orientation" text_line_orientation DEFAULT 'upright',  -- upright|upside_down|rotated_cw|rotated_ccw
    "is_corrected" BOOLEAN DEFAULT false,
    "corrected_at" TIMESTAMP WITH TIME ZONE,
    "corrected_by" VARCHAR(100),
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
```

### Enums

```sql
CREATE TYPE processing_status AS ENUM ('Pending', 'Processing', 'Completed', 'Failed');
CREATE TYPE text_origin AS ENUM ('OCR', 'HTR', 'Manual', 'Correction');
CREATE TYPE inference_mode AS ENUM ('Fast', 'Balanced', 'Accurate');
CREATE TYPE pii_confirmation AS ENUM ('Pending', 'Confirmed', 'Rejected');
CREATE TYPE text_line_orientation AS ENUM ('upright', 'upside_down', 'rotated_cw', 'rotated_ccw');
```

## Polygon Storage

Both `Text_Segments` and `Text_Lines` store exact polygon boundaries as JSONB arrays:

```json
[[x1, y1], [x2, y2], [x3, y3], [x4, y4]]
```

### Polygon Types

| Table | Polygon Description | Purpose |
|-------|---------------------|---------|
| `Text_Segments.polygon_coords` | Full region boundary | Container polygon enclosing multiple lines |
| `Text_Lines.polygon_coords` | Exact line boundary | Precise text line boundary for visualization |

### Example Usage

```sql
-- Get all lines with their region polygons
SELECT 
    l."line_text",
    l."orientation",
    l."polygon_coords" AS line_polygon,
    s."polygon_coords" AS region_polygon
FROM "Text_Lines" l
LEFT JOIN "Text_Segments" s ON l."line_segment_id" = s."segment_id"
WHERE l."text_id" = 123;

-- Count lines by orientation
SELECT "orientation", COUNT(*) 
FROM "Text_Lines" 
GROUP BY "orientation";
```

## Triggers

### Automatic corrected_text Update

```sql
CREATE OR REPLACE FUNCTION update_master_text()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'DELETE' THEN
        UPDATE "Texts"
        SET "corrected_text" = (
            SELECT string_agg("line_text", E'\n' ORDER BY "line_number")
            FROM "Text_Lines" WHERE "text_id" = OLD."text_id"
        ),
        "last_corrected_at" = CURRENT_TIMESTAMP,
        "updated_at" = CURRENT_TIMESTAMP
        WHERE "text_id" = OLD."text_id";
        RETURN OLD;
    ELSE
        UPDATE "Texts"
        SET "corrected_text" = (
            SELECT string_agg("line_text", E'\n' ORDER BY "line_number")
            FROM "Text_Lines" WHERE "text_id" = NEW."text_id"
        ),
        "last_corrected_at" = CURRENT_TIMESTAMP,
        "updated_at" = CURRENT_TIMESTAMP
        WHERE "text_id" = NEW."text_id";
        RETURN NEW;
    END IF;
END;$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_update_master_text
AFTER INSERT OR UPDATE OR DELETE ON "Text_Lines"
FOR EACH ROW EXECUTE FUNCTION update_master_text();
```

## Indexes

### Performance Indexes

```sql
-- Content-addressable lookup
CREATE INDEX "idx_pictures_hash" ON "Pictures" ("sha256_hash");

-- Document relationships
CREATE INDEX "idx_pictures_document_id" ON "Pictures" ("document_id");
CREATE INDEX "idx_texts_document_id" ON "Texts" ("document_id");

-- Segment and line relationships
CREATE INDEX "idx_segments_text_id" ON "Text_Segments" ("text_id");
CREATE INDEX "idx_segments_polygon" ON "Text_Segments" ("text_id") 
    WHERE "polygon_coords" IS NOT NULL;

CREATE INDEX "idx_lines_text_id" ON "Text_Lines" ("text_id");
CREATE INDEX "idx_lines_segment_id" ON "Text_Lines" ("line_segment_id") 
    WHERE "line_segment_id" IS NOT NULL;
CREATE INDEX "idx_lines_polygon" ON "Text_Lines" ("text_id") 
    WHERE "polygon_coords" IS NOT NULL;
CREATE INDEX "idx_lines_orientation" ON "Text_Lines" ("text_id", "orientation");

-- Language queries
CREATE INDEX "idx_langdetect_text_id" ON "Text_Language_Detections" ("text_id");
CREATE INDEX "idx_langdetect_lang_code" ON "Text_Language_Detections" ("lang_code");
```

## API Integration

### HTR Service Flow

```
POST /process
├── Validate input image
├── Calculate SHA256 hash
├── Check cache (skip if exists, unless rerun=true)
├── Upload to S3
├── Initialize document/picture in DB
├── Run HTR inference (RF-DETR + TrOCR)
│   ├── Detect text regions (class_id=1) → Text_Segments
│   ├── Detect text lines (class_id 2-5) → Text_Lines
│   └── Store polygon_coords for both
├── Call langdetect service
├── Save results
│   ├── Texts (transcription)
│   ├── Text_Segments (region polygons)
│   ├── Text_Lines (line polygons + orientation)
│   └── Text_Language_Detections
└── Update Processing_Status
```

### Processing Modes

| Mode | Behavior |
|------|----------|
| Normal | Skip if already processed (cache hit) |
| `rerun=true` | Clear previous data, reprocess |
| `alternative=true` | Store as new document, keep existing |

### Image Enhancement Integration

The HTR service integrates with the image-enhance microservice for preprocessing:

```bash
# Preprocessing methods
POST http://image-enhance-archxai/preprocess
{
    "image_base64": "...",
    "method": "auto"  # auto, denoise, denoise_strong, clahe, stretch, none
}
```

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `DB_HOST` | Yes | PostgreSQL host (internal: `postgres-archxai`) |
| `DB_PORT` | Yes | PostgreSQL port (internal: `5432`) |
| `DB_USER` | Yes | Database username |
| `DB_PASSWORD` | Yes | Database password |
| `DB_NAME` | Yes | Database name (default: `archxai_db`) |
| `DB_DATA_PATH` | Yes | Host path for PostgreSQL data |
| `MINIO_ROOT_USER` | Yes | S3 admin username |
| `MINIO_ROOT_PASSWORD` | Yes | S3 admin password |
| `MINIO_DATA_PATH` | Yes | Host path for S3 data |
| `TZ` | No | Timezone (default: `Europe/Helsinki`) |
| `LANGDETECT_ENDPOINT` | No | Language detection URL |
| `PREPROCESS_URL` | No | Image enhancement URL |
| `PREPROCESSING_METHOD` | No | Default preprocessing method (default: `auto`) |

## Performance Tuning

### PostgreSQL Settings

```sql
-- Connection pooling (handled by application)
-- min_size=5, max_size=20

-- Memory for sorting
ALTER SYSTEM SET work_mem = '256MB';

-- Parallel query execution
ALTER SYSTEM SET max_parallel_workers_per_gather = 4;
ALTER SYSTEM SET parallel_tuple_cost = 0.01;

-- JIT compilation
ALTER SYSTEM SET jit = on;
ALTER SYSTEM SET jit_above_cost = 100000;

-- Autovacuum tuning
ALTER TABLE "Documents" SET (autovacuum_vacuum_scale_factor = 0.05);
ALTER TABLE "Text_Lines" SET (autovacuum_vacuum_scale_factor = 0.1);
```

### Index Strategy

- **BRIN indexes** for time-series data (smaller footprint)
- **Partial indexes** for NULL-filtered columns (polygon lookups)
- **Covering indexes** for frequently accessed column combinations
- **GIN indexes** for full-text search

## Troubleshooting

### Common Issues

| Issue | Diagnosis | Solution |
|-------|-----------|----------|
| Tables not created | Schema init failed | Check logs: `docker compose logs postgres-archxai` |
| Unique constraint violation | sha256_hash conflict | Drop unique index, keep regular index |
| Slow queries | Missing index | Analyze with `EXPLAIN ANALYZE` |
| Connection timeout | Pool exhausted | Increase `max_size` in connection pool |
| Preprocessing 400 error | Invalid method | Check PREPROCESSING_METHODS includes method |

### Diagnostic Queries

```sql
-- Check table sizes
SELECT pg_size_pretty(pg_total_relation_size('"Texts"'));

-- Check missing indexes
SELECT * FROM pg_stat_user_indexes WHERE idx_scan = 0;

-- Check active connections
SELECT * FROM pg_stat_activity WHERE datname = 'archxai_db';

-- Check processing status distribution
SELECT status, COUNT(*) FROM "Processing_Status" GROUP BY status;

-- Check line orientation distribution
SELECT orientation, COUNT(*) FROM "Text_Lines" GROUP BY orientation;

-- Check polygon coverage
SELECT 
    COUNT(*) AS total_lines,
    COUNT("polygon_coords") AS lines_with_polygon
FROM "Text_Lines";
```

## Security

- **Password-protected**: All database connections require authentication
- **Network isolation**: Services communicate only via internal Docker network
- **Minimal exposure**: Only Adminer, S3 API, and Filer ports exposed to host
- **Soft delete**: Records marked with `deleted_at` rather than hard deleted
- **No sensitive data in logs**: Passwords and tokens are masked

## Backup & Recovery

```bash
# Backup database (via docker exec - works without host port)
docker exec archxai_db pg_dump -U archxai_user archxai_db > backup.sql

# Restore database
docker exec -i archxai_db psql -U archxai_user archxai_db < backup.sql

# Backup S3 storage
docker run --rm -v db-core_minio_data:/data -v $(pwd):/backup alpine tar czf /backup/s3_backup.tar.gz /data
```

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 2026-08-20 | Current | Region→Line architecture, polygon_coords, text_line_orientation, line_count |
| 2026-08-11 | Previous | Added line_segment_id, optimized indexes |
| 2026-07-10 | Initial | Full schema with all tables and triggers |