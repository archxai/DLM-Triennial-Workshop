"""
Pydantic Schemas for Metadata Service
=====================================
Request and response models for the metadata API.
"""
from __future__ import annotations

from typing import Dict, Any, Optional
from pydantic import BaseModel, Field


class MetadataRequest(BaseModel):
    """Request model for base64 metadata extraction."""
    image_base64: str = Field(..., description="Base64-encoded image data")
    filename: Optional[str] = Field(None, description="Original filename")


class MetadataResponse(BaseModel):
    """Response model containing all extracted metadata."""
    
    # File properties
    file_size_bytes: Optional[int] = Field(None, description="File size in bytes")
    image_width: Optional[int] = Field(None, description="Image width in pixels")
    image_height: Optional[int] = Field(None, description="Image height in pixels")
    mime_type: Optional[str] = Field(None, description="MIME type (e.g., image/jpeg)")
    
    # Original file info
    original_filename: Optional[str] = Field(None, description="Original filename")
    original_extension: Optional[str] = Field(None, description="File extension")
    
    # EXIF metadata
    exif_make: Optional[str] = Field(None, description="Camera manufacturer")
    exif_model: Optional[str] = Field(None, description="Camera model")
    exif_datetime: Optional[str] = Field(None, description="Date/time taken (ISO format)")
    exif_software: Optional[str] = Field(None, description="Software used")
    exif_orientation: Optional[int] = Field(None, description="EXIF orientation (1-8)")
    exif_x_resolution: Optional[int] = Field(None, description="X resolution (DPI)")
    exif_y_resolution: Optional[int] = Field(None, description="Y resolution (DPI)")
    exif_resolution_unit: Optional[str] = Field(None, description="Resolution unit (inch/cm)")
    
    # Color info
    color_mode: Optional[str] = Field(None, description="PIL color mode (RGB, RGBA, etc.)")
    bit_depth: Optional[int] = Field(None, description="Bit depth per channel")
    has_alpha: bool = Field(False, description="Whether image has alpha channel")
    
    # Compression
    compression_type: Optional[str] = Field(None, description="Compression format (JPEG, PNG, etc.)")
    compression_quality: Optional[int] = Field(None, description="Compression quality (1-100)")
    
    # Raw data
    raw_exif_data: Optional[Dict[str, Any]] = Field(None, description="All raw EXIF data")


class HealthResponse(BaseModel):
    """Health check response."""
    status: str
    service: str