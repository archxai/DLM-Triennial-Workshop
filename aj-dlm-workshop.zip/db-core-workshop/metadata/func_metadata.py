"""
Metadata Extraction Functions
=============================
Core logic for extracting metadata from images.
"""
from __future__ import annotations

import io
import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any, Optional, Union

from PIL import Image, ExifTags
from PIL.ExifTags import TAGS

logger = logging.getLogger("metadata_func")

# MIME type mapping
MIME_TYPES = {
    "JPEG": "image/jpeg",
    "PNG": "image/png",
    "GIF": "image/gif",
    "TIFF": "image/tiff",
    "WEBP": "image/webp",
    "BMP": "image/bmp",
    "ICO": "image/x-icon",
}

# Resolution unit mapping
RESOLUTION_UNITS = {
    1: "none",
    2: "inch",
    3: "cm",
}

# Bit depth by mode
MODE_BIT_DEPTH = {
    "1": 1,
    "L": 8,
    "LA": 8,
    "RGB": 24,
    "RGBA": 32,
    "RGBX": 32,
    "I": 16,
    "F": 32,
    "P": 8,
    "PA": 8,
}


def _parse_exif_datetime(value: Any) -> Optional[datetime]:
    """
    Parse EXIF datetime string to datetime object.
    
    EXIF format: "YYYY:MM:DD HH:MM:SS"
    Example: "2018:11:22 15:35:51"
    
    Returns:
        datetime object with timezone UTC, or None if parsing fails
    """
    if not isinstance(value, str):
        return None
    
    try:
        dt = datetime.strptime(value, "%Y:%m:%d %H:%M:%S")
        return dt.replace(tzinfo=timezone.utc)
    except ValueError:
        logger.debug(f"Failed to parse EXIF datetime: {value}")
        return None


def _parse_exif_datetime_iso(value: Any) -> Optional[str]:
    """
    Parse EXIF datetime string to ISO format string.
    
    EXIF format: "YYYY:MM:DD HH:MM:SS"
    Example: "2018:11:22 15:35:51"
    
    Returns:
        ISO format string, or None if parsing fails
    """
    if not isinstance(value, str):
        return None
    
    try:
        dt = datetime.strptime(value, "%Y:%m:%d %H:%M:%S")
        return dt.isoformat()
    except ValueError:
        return None


def _parse_resolution(value: Any) -> Optional[int]:
    """Parse resolution value to integer."""
    if isinstance(value, (int, float)):
        return int(value)
    if isinstance(value, tuple):
        # Sometimes resolution is (value, denominator)
        return int(value[0])
    return None


def _serialize_exif_value(value: Any) -> Any:
    """
    Serialize EXIF value to JSON-compatible type.
    """
    if isinstance(value, bytes):
        try:
            return value.decode("utf-8", errors="replace")
        except Exception:
            return "<binary data>"
    elif isinstance(value, tuple):
        return [_serialize_exif_value(v) for v in value]
    elif isinstance(value, (int, float, str, bool)):
        return value
    else:
        return str(value)


def extract_metadata_from_bytes(
    image_bytes: bytes,
    original_filename: Optional[str] = None,
    return_datetime_object: bool = True
) -> Dict[str, Any]:
    """
    Extract metadata from image bytes.
    
    Args:
        image_bytes: Raw image bytes
        original_filename: Original filename if known
        return_datetime_object: If True, exif_datetime is datetime object (for DB).
                                If False, exif_datetime is ISO string (for JSON API).
        
    Returns:
        Dictionary containing all extracted metadata
    """
    try:
        # Open image from bytes
        img = Image.open(io.BytesIO(image_bytes))
        
        # Get basic properties
        width, height = img.size
        format_str = img.format or "UNKNOWN"
        mime_type = MIME_TYPES.get(format_str.upper(), "application/octet-stream")
        
        # Get extension
        extension = None
        if original_filename:
            ext = Path(original_filename).suffix.lower()
            extension = ext.lstrip(".") if ext else None
        
        # Initialize result
        result = {
            "file_size_bytes": len(image_bytes),
            "image_width": width,
            "image_height": height,
            "mime_type": mime_type,
            "original_filename": original_filename,
            "original_extension": extension,
            "color_mode": img.mode,
            "bit_depth": MODE_BIT_DEPTH.get(img.mode),
            "has_alpha": img.mode in ("RGBA", "LA", "PA"),
            "compression_type": format_str,
        }
        
        # Extract EXIF data
        exif_data = _extract_exif(img, return_datetime_object=return_datetime_object)
        result.update(exif_data)
        
        return result
        
    except Exception as e:
        logger.warning(f"Metadata extraction failed: {e}")
        return {"file_size_bytes": len(image_bytes) if image_bytes else None}


def extract_metadata_from_file(
    file_path: str,
    return_datetime_object: bool = True
) -> Dict[str, Any]:
    """
    Extract metadata from an image file.
    
    Args:
        file_path: Path to the image file
        return_datetime_object: If True, exif_datetime is datetime object (for DB).
        
    Returns:
        Dictionary containing all extracted metadata
    """
    path = Path(file_path)
    
    if not path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")
    
    if not path.is_file():
        raise ValueError(f"Not a file: {file_path}")
    
    # Read file bytes
    image_bytes = path.read_bytes()
    
    # Extract metadata
    return extract_metadata_from_bytes(image_bytes, path.name, return_datetime_object)


def _extract_exif(
    img: Image.Image,
    return_datetime_object: bool = True
) -> Dict[str, Any]:
    """
    Extract EXIF metadata from PIL Image.
    
    Args:
        img: PIL Image object
        return_datetime_object: If True, exif_datetime is datetime object (for DB).
        
    Returns:
        Dictionary with EXIF fields
    """
    result = {}
    raw_exif = {}
    
    try:
        exif_data = img.getexif()
        
        if not exif_data:
            return result
        
        for tag_id, value in exif_data.items():
            tag_name = TAGS.get(tag_id, str(tag_id))
            
            # Store raw EXIF data
            raw_exif[tag_name] = _serialize_exif_value(value)
            
            # Map specific tags to result
            if tag_name == "Make":
                result["exif_make"] = str(value)
            elif tag_name == "Model":
                result["exif_model"] = str(value)
            elif tag_name == "DateTime":
                # FIX: Return datetime object for DB, ISO string for API
                if return_datetime_object:
                    result["exif_datetime"] = _parse_exif_datetime(value)
                else:
                    result["exif_datetime"] = _parse_exif_datetime_iso(value)
            elif tag_name == "Software":
                result["exif_software"] = str(value)
            elif tag_name == "Orientation":
                result["exif_orientation"] = int(value) if isinstance(value, (int, float)) else None
            elif tag_name == "XResolution":
                result["exif_x_resolution"] = _parse_resolution(value)
            elif tag_name == "YResolution":
                result["exif_y_resolution"] = _parse_resolution(value)
            elif tag_name == "ResolutionUnit":
                result["exif_resolution_unit"] = RESOLUTION_UNITS.get(
                    int(value) if isinstance(value, int) else 0
                )
        
        # Store raw EXIF as JSON-compatible dict
        if raw_exif:
            result["raw_exif_data"] = raw_exif
        
    except Exception as e:
        logger.debug(f"EXIF extraction failed: {e}")
    
    return result