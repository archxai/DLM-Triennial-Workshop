# ArchXAI Metadata Service

Extracts comprehensive metadata from uploaded images including EXIF data, file properties, and color information.

## Overview

This service provides a centralized way to extract metadata from images. It's used by both HTR and OCR cores to store image information in the database.

## Features

- **File Properties**: Size, dimensions, MIME type
- **Original Filename**: Preserves the uploaded filename
- **EXIF Data**: Camera make/model, date taken, orientation, resolution
- **Color Information**: Color mode, bit depth, alpha channel
- **Compression Info**: Format and quality settings
- **Raw EXIF Backup**: All raw EXIF data stored as JSON

## API Endpoints

### Health Check
```http
GET /health
```

**Response:**
```json
{
  "status": "healthy",
  "service": "metadata"
}
```

### Extract Metadata (Multipart Upload)
```http
POST /extract
Content-Type: multipart/form-data

file: <image file>
filename: <optional original filename>
```

**Response:**
```json
{
  "file_size_bytes": 154321,
  "image_width": 2480,
  "image_height": 3508,
  "mime_type": "image/jpeg",
  "original_filename": "document_1890_page1.jpg",
  "original_extension": "jpg",
  "exif_make": "Canon",
  "exif_model": "EOS 5D",
  "exif_datetime": "2024-01-15T10:30:00",
  "exif_orientation": 1,
  "color_mode": "RGB",
  "bit_depth": 24,
  "has_alpha": false,
  "compression_type": "JPEG",
  "raw_exif_data": { ... }
}
```

### Extract Metadata (Base64)
```http
POST /extract/base64
Content-Type: application/x-www-form-urlencoded

image_base64: <base64 encoded image>
filename: <optional original filename>
```

## Usage

### Docker Compose Integration

The service is automatically started with the db-core infrastructure:

```yaml
metadata-archxai:
  build: ./metadata
  container_name: archxai_metadata
  networks:
    - archxai-internal
  ports:
    - "8103:80"  # Optional: expose for debugging
  healthcheck:
    test: ["CMD", "curl", "-f", "http://localhost:80/health"]
    interval: 30s
    timeout: 10s
    retries: 3
```

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `80` | Service port |

### Integration with HTR/OCR Cores

Set the metadata service URL in the core's environment:

```env
METADATA_SERVICE_URL=http://metadata-archxai/extract
```

The core will automatically call this endpoint when processing images.

## Error Handling

| Status Code | Description |
|-------------|-------------|
| 200 | Success |
| 400 | Invalid image data |
| 404 | File not found (file endpoint only) |
| 500 | Internal error |

## Dependencies

- Python 3.12+
- FastAPI
- Pillow (PIL)
- python-multipart
```

---

## 6. Päivitetty docker-compose.yaml

```yaml docker-compose.yaml
services:
  # --- PostgreSQL Database ---
  postgres-archxai:
    image: postgres:18-alpine
    container_name: archxai_db
    restart: unless-stopped    
    networks:
      - archxai-internal
    environment:
      POSTGRES_USER: ${DB_USER}
      POSTGRES_PASSWORD: ${DB_PASSWORD}
      POSTGRES_DB: ${DB_NAME}
      PGDATA: /var/lib/postgresql/data/pgdata
      TZ: ${TZ}
    ports:
      - "5432:5432"
    volumes:
      - ./dbdata/ArchXAI-db-schema.sql:/docker-entrypoint-initdb.d/01-schema.sql:ro
      - ${DB_DATA_PATH}:/var/lib/postgresql/data/pgdata
    healthcheck:      
      test: ["CMD-SHELL", "pg_isready -U ${DB_USER} -d ${DB_NAME}"]
      interval: 10s
      timeout: 5s
      retries: 5
      start_period: 15s

  # --- Database Management UI ---
  adminer-archxai:
    image: adminer:latest
    container_name: adminer_archxai
    restart: unless-stopped
    networks:
      - archxai-internal
    ports:
      - "8080:8080"
    environment:
      - ADMINER_DEFAULT_SERVER=postgres-archxai
      - ADMINER_DEFAULT_PORT=5432
    depends_on:
      - postgres-archxai

  # --- SeaweedFS (Community Image for easy distribution) ---
  minio-archxai:
    image: chrislusf/seaweedfs:latest
    container_name: archxai_storage
    restart: unless-stopped
    networks:
      - archxai-internal
    ports:
      - "9000:9000" # S3 API
      - "9001:8888" # UI: Host 9001 -> Container 8888
    environment:
      TZ: ${TZ}
    volumes:
      - ${MINIO_DATA_PATH}:/data
    command: server -s3 -s3.port=9000
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:9000"]
      interval: 10s
      timeout: 5s
      retries: 5

  # --- Storage Bucket Provisioning ---
  minio-setup:
    image: amazon/aws-cli:latest
    container_name: archxai_storage_setup
    networks:
      - archxai-internal
    depends_on:
      minio-archxai:
        condition: service_healthy
    environment:
      AWS_ACCESS_KEY_ID: ${MINIO_ROOT_USER}
      AWS_SECRET_ACCESS_KEY: ${MINIO_ROOT_PASSWORD}
    entrypoint: >
      /bin/sh -c "
      aws s3 mb s3://archxai-images --endpoint-url http://minio-archxai:9000 || true;
      echo 'Bucket archxai-images is ready in SeaweedFS!'"

  # --- Language Detection Service ---
  langdetect-archxai:
    build: ./langdetect
    container_name: langdetect_archxai
    restart: unless-stopped
    networks:
      - archxai-internal
    ports:
      - "8101:80"
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:80/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 10s

  # --- Image Enhancement Service ---
  image-enhance-archxai:
    build: ./image-enhance
    container_name: image_enhance_archxai
    restart: unless-stopped
    networks:
      - archxai-internal
    ports:
      - "8102:80"
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:80/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 10s

  # --- Metadata Extraction Service (NEW) ---
  metadata-archxai:
    build: ./metadata
    container_name: metadata_archxai
    restart: unless-stopped
    networks:
      - archxai-internal
    ports:
      - "8103:80"  # Optional: for debugging
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:80/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 10s

# --- NETWORK DEFINITION ---
networks:
  archxai-internal:
    driver: bridge
    name: archxai-internal
```

---

## Yhteenveto

| Tiedosto | Kuvaus |
|----------|--------|
| `metadata/api_metadata.py` | FastAPI endpointit |
| `metadata/func_metadata.py` | Metadata extraction logiikka |
| `metadata/schemas.py` | Pydantic mallit |
| `metadata/Dockerfile` | Container build |
| `metadata/readme.md` | Dokumentaatio |
| `docker-compose.yaml` | Päivitetty sisältämään metadata-palvelu |

**Palvelun URL htr-core/ocr-core -kontekstissa:**
```
http://metadata-archxai/extract