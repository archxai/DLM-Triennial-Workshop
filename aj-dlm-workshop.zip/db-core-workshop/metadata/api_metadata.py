"""
Metadata Extraction API
=======================
FastAPI endpoints for extracting image metadata.
"""
from __future__ import annotations

import logging
from typing import Dict, Any, Optional

from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from func_metadata import extract_metadata_from_bytes, extract_metadata_from_file

logger = logging.getLogger("metadata_api")

app = FastAPI(
    title="ArchXAI Metadata Service",
    description="Extracts comprehensive metadata from uploaded images including EXIF data, "
                "file properties, and color information. Used by HTR and OCR cores.",
    version="1.0.0",
)


class MetadataResponse(BaseModel):
    """Response model for metadata extraction."""
    file_size_bytes: Optional[int] = None
    image_width: Optional[int] = None
    image_height: Optional[int] = None
    mime_type: Optional[str] = None
    original_filename: Optional[str] = None
    original_extension: Optional[str] = None
    exif_make: Optional[str] = None
    exif_model: Optional[str] = None
    exif_datetime: Optional[str] = None
    exif_software: Optional[str] = None
    exif_orientation: Optional[int] = None
    exif_x_resolution: Optional[int] = None
    exif_y_resolution: Optional[int] = None
    exif_resolution_unit: Optional[str] = None
    color_mode: Optional[str] = None
    bit_depth: Optional[int] = None
    has_alpha: bool = False
    compression_type: Optional[str] = None
    compression_quality: Optional[int] = None
    raw_exif_data: Optional[Dict[str, Any]] = None


@app.get("/")
def root():
    """Root endpoint with service information."""
    return {
        "service": "ArchXAI Metadata Service",
        "version": "1.0.0",
        "endpoints": {
            "POST /extract": "Extract metadata from uploaded file",
            "POST /extract/base64": "Extract metadata from base64-encoded image",
            "GET /health": "Health check"
        }
    }


@app.get("/health")
def health_check():
    """Health check endpoint."""
    return JSONResponse(
        content={"status": "healthy", "service": "metadata"},
        status_code=200
    )


@app.post("/extract", response_model=MetadataResponse)
async def extract_metadata_endpoint(
    file: UploadFile = File(..., description="Image file to extract metadata from"),
    filename: Optional[str] = Form(None, description="Original filename if different from uploaded")
) -> MetadataResponse:
    """
    Extract metadata from an uploaded image file.
    
    Returns comprehensive metadata including:
    - File properties (size, dimensions, MIME type)
    - Original filename and extension
    - EXIF data (camera, date, orientation, resolution)
    - Color information
    """
    try:
        # Read file contents
        contents = await file.read()
        
        # Use provided filename or the uploaded filename
        original_name = filename or file.filename
        
        # Extract metadata
        metadata = extract_metadata_from_bytes(contents, original_name)
        
        return MetadataResponse(**metadata)
        
    except ValueError as e:
        logger.error(f"Invalid image data: {e}")
        raise HTTPException(status_code=400, detail=f"Invalid image data: {str(e)}")
    except Exception as e:
        logger.error(f"Metadata extraction failed: {e}")
        raise HTTPException(status_code=500, detail=f"Metadata extraction failed: {str(e)}")


@app.post("/extract/base64", response_model=MetadataResponse)
async def extract_metadata_base64(
    image_base64: str = Form(..., description="Base64-encoded image data"),
    filename: Optional[str] = Form(None, description="Original filename")
) -> MetadataResponse:
    """
    Extract metadata from a base64-encoded image.
    
    Useful when the image is already being transmitted as base64
    (e.g., from preprocessing services).
    """
    try:
        import base64
        
        # Decode base64
        image_bytes = base64.b64decode(image_base64)
        
        # Extract metadata
        metadata = extract_metadata_from_bytes(image_bytes, filename)
        
        return MetadataResponse(**metadata)
        
    except ValueError as e:
        logger.error(f"Invalid base64 data: {e}")
        raise HTTPException(status_code=400, detail=f"Invalid base64 data: {str(e)}")
    except Exception as e:
        logger.error(f"Metadata extraction failed: {e}")
        raise HTTPException(status_code=500, detail=f"Metadata extraction failed: {str(e)}")


@app.post("/extract/file", response_model=MetadataResponse)
async def extract_metadata_from_file_path(
    file_path: str = Form(..., description="Path to image file (for testing)")
) -> MetadataResponse:
    """
    Extract metadata from a file path.
    
    Note: This endpoint is primarily for testing purposes.
    In production, use the /extract endpoint with multipart upload.
    """
    try:
        metadata = extract_metadata_from_file(file_path)
        return MetadataResponse(**metadata)
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail=f"File not found: {file_path}")
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Metadata extraction failed: {e}")
        raise HTTPException(status_code=500, detail=f"Metadata extraction failed: {str(e)}")