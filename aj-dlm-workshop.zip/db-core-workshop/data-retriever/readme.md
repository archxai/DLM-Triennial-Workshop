# ArchXAI Data Retriever API

A minimal FastAPI service that fetches documents with their texts, lines, metadata, and keywords from the ArchXAI PostgreSQL database.

## Quick Start

### 1. Start the database

```bash
cd db-core
docker compose up -d postgres-archxai
```

### 2. Build and run the API

```bash
docker compose up -d --build data-retriever
```

The API will be available at `http://localhost:8000`

## Local Development

For faster development with auto-reload:

```bash
cd data-retriever
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/documents` | Fetch all documents with texts, lines, metadata, and keywords |
| GET | `/docs` | Swagger UI documentation |
| GET | `/openapi.json` | OpenAPI specification |

## Example Response

```json
{
  "documents": [
    {
      "document_id": 1,
      "document_type": "Invoice",
      "created_at": "2024-01-15T10:30:00Z",
      "texts": [
        {
          "text_id": 1,
          "document_id": 1,
          "original_raw_text": "Invoice #12345\nDate: 2024-01-15",
          "corrected_text": null,
          "text_origin": "OCR",
          "lines": [
            {
              "line_id": 1,
              "line_number": 1,
              "line_text": "Invoice #12345",
              "is_corrected": false
            }
          ]
        }
      ],
      "doc_metadata": [
        {
          "gen_meta_id": 1,
          "category": "financial",
          "key": "amount",
          "value_text": "$500.00",
          "value_number": 500,
          "value_json": null
        }
      ],
      "keywords": [
        {
          "keyword_id": 1,
          "relevance_score": 1.0,
          "frequency": 1,
          "keyword": {
            "keyword_id": 1,
            "label": "invoice",
            "category": "document_type",
            "weight": 1.0
          }
        }
      ]
    }
  ],
  "total": 1
}
```

## Tech Stack

- **FastAPI** - Modern Python web framework
- **SQLAlchemy** - SQL toolkit and ORM
- **asyncpg** - Async PostgreSQL driver
- **Pydantic** - Data validation
- **Uvicorn** - ASGI server