from sqlalchemy import Column, Integer, String, ForeignKey, DateTime, Boolean, Text as SQLText, JSON
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from database import Base


class Document(Base):
    __tablename__ = "Documents"

    document_id = Column(Integer, primary_key=True)
    document_type = Column(String(100), nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now())
    deleted_at = Column(DateTime(timezone=True))

    texts = relationship("Text", back_populates="document")
    doc_metadata = relationship("MetadataGeneral", back_populates="document")
    keywords = relationship("DocumentKeyword", back_populates="document")
    pictures = relationship("Picture", back_populates="document")


class Text(Base):
    __tablename__ = "Texts"

    text_id = Column(Integer, primary_key=True)
    document_id = Column(Integer, ForeignKey("Documents.document_id", ondelete="CASCADE"), nullable=False)
    original_raw_text = Column(SQLText, nullable=False)
    corrected_text = Column(SQLText)
    text_origin = Column(String(20), nullable=False, default="OCR")
    confidence_score = Column(Integer)
    detected_language_code = Column(String(10))
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    document = relationship("Document", back_populates="texts")
    lines = relationship("TextLine", back_populates="text")


class TextLine(Base):
    __tablename__ = "Text_Lines"

    line_id = Column(Integer, primary_key=True)
    text_id = Column(Integer, ForeignKey("Texts.text_id", ondelete="CASCADE"), nullable=False)
    line_number = Column(Integer, nullable=False)
    line_text = Column(SQLText, nullable=False)
    is_corrected = Column(Boolean, default=False)
    orientation = Column(String(20), default='upright')
    bbox_xmin = Column(Integer)
    bbox_ymin = Column(Integer)
    bbox_xmax = Column(Integer)
    bbox_ymax = Column(Integer)
    confidence_score = Column(Integer)

    text = relationship("Text", back_populates="lines")


class MetadataGeneral(Base):
    __tablename__ = "Metadata_General"

    gen_meta_id = Column(Integer, primary_key=True)
    document_id = Column(Integer, ForeignKey("Documents.document_id", ondelete="CASCADE"), nullable=False)
    category = Column(String(100), nullable=False)
    key = Column(String(100), nullable=False)
    value_text = Column(SQLText)
    value_number = Column(Integer)
    value_json = Column(JSON)

    document = relationship("Document", back_populates="doc_metadata")


class Keyword(Base):
    __tablename__ = "Keywords"

    keyword_id = Column(Integer, primary_key=True)
    label = Column(String(100), nullable=False)
    category = Column(String(50))
    weight = Column(Integer, default=1)

    documents = relationship("DocumentKeyword", back_populates="keyword")


class DocumentKeyword(Base):
    __tablename__ = "Document_Keywords"

    document_id = Column(Integer, ForeignKey("Documents.document_id", ondelete="CASCADE"), primary_key=True)
    keyword_id = Column(Integer, ForeignKey("Keywords.keyword_id", ondelete="CASCADE"), primary_key=True)
    relevance_score = Column(Integer)
    frequency = Column(Integer, default=1)

    document = relationship("Document", back_populates="keywords")
    keyword = relationship("Keyword", back_populates="documents")


class PicturesMetadata(Base):
    __tablename__ = "Pictures_Metadata"

    metadata_id = Column(Integer, primary_key=True)
    file_size_bytes = Column(Integer)
    image_width = Column(Integer)
    image_height = Column(Integer)
    mime_type = Column(String(50))
    original_filename = Column(String(500))
    original_extension = Column(String(20))
    preprocessing_method = Column(String(50))
    preprocessed_image_path = Column(SQLText)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    picture = relationship("Picture", back_populates="picture_metadata")


class Picture(Base):
    __tablename__ = "Pictures"

    picture_id = Column(Integer, primary_key=True)
    document_id = Column(Integer, ForeignKey("Documents.document_id", ondelete="CASCADE"), nullable=False)
    metadata_id = Column(Integer, ForeignKey("Pictures_Metadata.metadata_id", ondelete="SET NULL"))
    sha256_hash = Column(String(64), nullable=False)
    file_path = Column(SQLText, nullable=False)
    boxed_image_path = Column(SQLText)
    archive_origin = Column(String(50))
    collection_type = Column(String(100))
    processed_at = Column(DateTime(timezone=True))
    updated_at = Column(DateTime(timezone=True), server_default=func.now())

    document = relationship("Document", back_populates="pictures")
    picture_metadata = relationship("PicturesMetadata", back_populates="picture")  # Renamed from 'metadata'
