from fastapi import APIRouter, Depends, Query, HTTPException
from fastapi.responses import Response
from sqlalchemy.ext.asyncio import AsyncSession
import json
from datetime import datetime

from database import get_db
from .base import get_document_by_id, get_all_documents, document_to_dict

router = APIRouter(prefix="/export", tags=["Exports - JSON"])


def datetime_serializer(obj):
    """Custom JSON serializer for datetime objects."""
    if isinstance(obj, datetime):
        return obj.isoformat()
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


@router.get("/json", response_class=Response)
async def export_document_json(
    doc_id: int = Query(..., description="Document ID to export"),
    db: AsyncSession = Depends(get_db)
):
    """Export a single document as JSON."""
    doc = await get_document_by_id(db, doc_id)
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")
    
    data = document_to_dict(doc)
    json_str = json.dumps(data, indent=2, ensure_ascii=False, default=datetime_serializer)
    
    return Response(
        content=json_str,
        media_type="application/json",
        headers={"Content-Disposition": f"attachment; filename=document_{doc_id}.json"}
    )


@router.get("/all/json", response_class=Response)
async def export_all_documents_json(db: AsyncSession = Depends(get_db)):
    """Export all documents as JSON."""
    documents = await get_all_documents(db)
    
    data = {
        "total": len(documents),
        "documents": [document_to_dict(doc) for doc in documents]
    }
    json_str = json.dumps(data, indent=2, ensure_ascii=False, default=datetime_serializer)
    
    return Response(
        content=json_str,
        media_type="application/json",
        headers={"Content-Disposition": "attachment; filename=all_documents.json"}
    )