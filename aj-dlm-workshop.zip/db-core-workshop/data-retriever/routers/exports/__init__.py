from fastapi import APIRouter
from .json import router as json_router
from .xml import router as xml_router
from .alto import router as alto_router
from .zip import router as zip_router

router = APIRouter()
router.include_router(json_router)
router.include_router(xml_router)
router.include_router(alto_router)
router.include_router(zip_router)
