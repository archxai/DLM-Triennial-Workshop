from fastapi import APIRouter, Depends, Query, HTTPException
from fastapi.responses import Response
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload
from sqlalchemy import select
import zipfile
import io
from datetime import datetime, timezone
import json
import boto3
from botocore.config import Config
from botocore.exceptions import ClientError
import os

from database import get_db
from models import Picture
from .base import get_document_by_id, get_all_documents, document_to_dict

router = APIRouter(prefix="/export", tags=["Exports - ZIP"])


def datetime_serializer(obj):
    """Custom JSON serializer for datetime objects."""
    if isinstance(obj, datetime):
        return obj.isoformat()
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


def get_minio_client():
    """Create MinIO client."""
    return boto3.client(
        's3',
        endpoint_url=os.getenv('MINIO_ENDPOINT', 'http://minio-archxai:9000'),
        aws_access_key_id=os.getenv('MINIO_ROOT_USER', 'archxai_admin'),
        aws_secret_access_key=os.getenv('MINIO_ROOT_PASSWORD', 'archxai_secure_password_123'),
        config=Config(signature_version='s3v4', connect_timeout=5, read_timeout=30)
    )


def fetch_image_from_minio(picture, boxed: bool = False, preprocessed: bool = False) -> tuple:
    """
    Fetch image from MinIO.
    Returns (bytes, filename, size) on success.
    Raises ClientError for connection issues, returns None for not found.
    """
    bucket = os.getenv('MINIO_BUCKET', 'archxai-images')
    s3_client = get_minio_client()
    
    if preprocessed:
        key = picture.picture_metadata.preprocessed_image_path if picture.picture_metadata else None
    elif boxed and picture.boxed_image_path:
        key = picture.boxed_image_path
    else:
        filename = picture.file_path.replace('original/', '')
        if filename.endswith('.png'):
            filename = filename[:-4] + '.jpg'
        key = filename
    
    if not key:
        return None, None, None
    
    try:
        response = s3_client.get_object(Bucket=bucket, Key=key)
        image_data = response['Body'].read()
        filename = key.split('/')[-1] if '/' in key else key
        return image_data, filename, len(image_data)
    except ClientError as e:
        error_code = e.response.get('Error', {}).get('Code', '')
        if error_code == 'NoSuchKey':
            return None, None, None
        raise


async def get_picture_with_metadata(db: AsyncSession, picture_id: int) -> Picture:
    """Fetch a picture with its metadata."""
    query = select(Picture).options(
        selectinload(Picture.picture_metadata)
    ).where(Picture.picture_id == picture_id)
    result = await db.execute(query)
    return result.scalar_one_or_none()


async def build_single_document_zip(doc, db: AsyncSession) -> tuple:
    """Build a zip file for a single document with flat structure."""
    doc_id = doc.document_id
    
    manifest = {
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "total_documents": 1,
        "total_image_files": 0,
        "total_images_not_found": 0,
        "export_status": "success",
        "documents": []
    }
    
    zip_buffer = io.BytesIO()
    
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
        doc_data = document_to_dict(doc)
        json_bytes = json.dumps(doc_data, indent=2, ensure_ascii=False, default=datetime_serializer).encode('utf-8')
        zip_file.writestr("document.json", json_bytes)
        
        doc_info = {
            "document_id": doc_id,
            "document_type": doc.document_type,
            "created_at": doc.created_at.isoformat() if doc.created_at else None,
            "json_path": "document.json",
            "image_files": 0,
            "images_not_found": 0,
            "images": []
        }
        
        pictures = list(doc.pictures) if hasattr(doc, 'pictures') and doc.pictures else []
        
        for picture in pictures:
            picture = await get_picture_with_metadata(db, picture.picture_id)
            image_types = [{"type": "original", "required": True}]
            
            if picture.boxed_image_path:
                image_types.append({"type": "boxed", "required": False})
            
            if picture.picture_metadata and picture.picture_metadata.preprocessed_image_path:
                image_types.append({"type": "preprocessed", "required": False})
            
            for img_type in image_types:
                image_info = {
                    "picture_id": picture.picture_id,
                    "type": img_type["type"],
                    "status": "pending",
                    "size_bytes": 0
                }
                
                doc_info["image_files"] += 1
                manifest["total_image_files"] += 1
                
                try:
                    is_boxed = img_type["type"] == "boxed"
                    is_preprocessed = img_type["type"] == "preprocessed"
                    
                    image_data, filename, size = fetch_image_from_minio(picture, boxed=is_boxed, preprocessed=is_preprocessed)
                    
                    if image_data is None:
                        image_info["status"] = "not_found"
                        image_info["filename"] = filename
                        doc_info["images_not_found"] += 1
                        manifest["total_images_not_found"] += 1
                    else:
                        if img_type["type"] == "boxed":
                            name_part, ext = os.path.splitext(filename)
                            filename = f"{name_part}_boxed{ext}"
                        elif img_type["type"] == "preprocessed":
                            name_part, ext = os.path.splitext(filename)
                            filename = f"{name_part}_preprocessed{ext}"
                        
                        image_info["filename"] = filename
                        image_info["zip_path"] = f"images/{filename}"
                        image_info["status"] = "success"
                        image_info["size_bytes"] = size
                        zip_file.writestr(image_info["zip_path"], image_data)
                        
                except Exception as e:
                    if img_type["required"]:
                        raise Exception(f"Failed to load {img_type['type']} image {picture.picture_id}: {str(e)}")
                    image_info["status"] = "skipped"
                    image_info["error"] = str(e)
                    doc_info["images_not_found"] += 1
                    manifest["total_images_not_found"] += 1
                
                doc_info["images"].append(image_info)
        
        manifest["documents"].append(doc_info)
    
    zip_buffer.seek(0)
    return zip_buffer.getvalue(), manifest


async def build_all_documents_zip(documents: list, db: AsyncSession) -> tuple:
    """Build a zip file for all documents with nested structure."""
    manifest = {
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "total_documents": len(documents),
        "total_image_files": 0,
        "total_images_not_found": 0,
        "export_status": "success",
        "documents": []
    }
    
    zip_buffer = io.BytesIO()
    
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
        for doc in documents:
            doc_id = doc.document_id
            
            doc_data = document_to_dict(doc)
            json_bytes = json.dumps(doc_data, indent=2, ensure_ascii=False, default=datetime_serializer).encode('utf-8')
            zip_file.writestr(f"documents/{doc_id}/document.json", json_bytes)
            
            doc_info = {
                "document_id": doc_id,
                "document_type": doc.document_type,
                "created_at": doc.created_at.isoformat() if doc.created_at else None,
                "json_path": f"documents/{doc_id}/document.json",
                "image_files": 0,
                "images_not_found": 0,
                "images": []
            }
            
            pictures = list(doc.pictures) if hasattr(doc, 'pictures') and doc.pictures else []
            
            for picture in pictures:
                picture = await get_picture_with_metadata(db, picture.picture_id)
                image_types = [{"type": "original", "required": True}]
                
                if picture.boxed_image_path:
                    image_types.append({"type": "boxed", "required": False})
                
                if picture.picture_metadata and picture.picture_metadata.preprocessed_image_path:
                    image_types.append({"type": "preprocessed", "required": False})
                
                for img_type in image_types:
                    image_info = {
                        "picture_id": picture.picture_id,
                        "type": img_type["type"],
                        "status": "pending",
                        "size_bytes": 0
                    }
                    
                    doc_info["image_files"] += 1
                    manifest["total_image_files"] += 1
                    
                    try:
                        is_boxed = img_type["type"] == "boxed"
                        is_preprocessed = img_type["type"] == "preprocessed"
                        
                        image_data, filename, size = fetch_image_from_minio(picture, boxed=is_boxed, preprocessed=is_preprocessed)
                        
                        if image_data is None:
                            image_info["status"] = "not_found"
                            image_info["filename"] = filename
                            doc_info["images_not_found"] += 1
                            manifest["total_images_not_found"] += 1
                        else:
                            if img_type["type"] == "boxed":
                                name_part, ext = os.path.splitext(filename)
                                filename = f"{name_part}_boxed{ext}"
                            elif img_type["type"] == "preprocessed":
                                name_part, ext = os.path.splitext(filename)
                                filename = f"{name_part}_preprocessed{ext}"
                            
                            image_info["filename"] = filename
                            image_info["zip_path"] = f"documents/{doc_id}/images/{filename}"
                            image_info["status"] = "success"
                            image_info["size_bytes"] = size
                            zip_file.writestr(image_info["zip_path"], image_data)
                            
                    except Exception as e:
                        if img_type["required"]:
                            raise Exception(f"Failed to load {img_type['type']} image {picture.picture_id}: {str(e)}")
                        image_info["status"] = "skipped"
                        image_info["error"] = str(e)
                        doc_info["images_not_found"] += 1
                        manifest["total_images_not_found"] += 1
                    
                    doc_info["images"].append(image_info)
            
            manifest["documents"].append(doc_info)
    
    zip_buffer.seek(0)
    return zip_buffer.getvalue(), manifest


@router.get("/zip", response_class=Response)
async def export_document_zip(
    doc_id: int = Query(..., description="Document ID to export"),
    db: AsyncSession = Depends(get_db)
):
    """Export a single document as a ZIP file containing JSON and images."""
    doc = await get_document_by_id(db, doc_id)
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")
    
    try:
        zip_bytes, manifest = await build_single_document_zip(doc, db)
        
        zip_buffer = io.BytesIO(zip_bytes)
        with zipfile.ZipFile(zip_buffer, 'a', zipfile.ZIP_DEFLATED) as zip_file:
            zip_file.writestr("manifest.json", json.dumps(manifest, indent=2))
        zip_buffer.seek(0)
        zip_bytes = zip_buffer.getvalue()
        
        return Response(
            content=zip_bytes,
            media_type="application/zip",
            headers={"Content-Disposition": f"attachment; filename=document_{doc_id}.zip"}
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to create zip export: {str(e)}")


@router.get("/all/zip", response_class=Response)
async def export_all_documents_zip(db: AsyncSession = Depends(get_db)):
    """Export all documents as a ZIP file containing JSON and images for each document."""
    documents = await get_all_documents(db)
    
    if not documents:
        raise HTTPException(status_code=404, detail="No documents found")
    
    try:
        zip_bytes, manifest = await build_all_documents_zip(documents, db)
        
        zip_buffer = io.BytesIO(zip_bytes)
        with zipfile.ZipFile(zip_buffer, 'a', zipfile.ZIP_DEFLATED) as zip_file:
            zip_file.writestr("manifest.json", json.dumps(manifest, indent=2))
        zip_buffer.seek(0)
        zip_bytes = zip_buffer.getvalue()
        
        return Response(
            content=zip_bytes,
            media_type="application/zip",
            headers={"Content-Disposition": "attachment; filename=all_documents.zip"}
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to create zip export: {str(e)}")