from fastapi import APIRouter, Depends, Query, HTTPException
from fastapi.responses import Response
from sqlalchemy.ext.asyncio import AsyncSession
import xml.etree.ElementTree as ET
from xml.dom import minidom

from database import get_db
from .base import get_document_by_id, get_all_documents, document_to_dict

router = APIRouter(prefix="/export", tags=["Exports - XML"])


def add_xml_element(parent, key: str, value):
    """Helper to add elements to XML."""
    tag = key.replace(" ", "_").replace("-", "_")
    
    if isinstance(value, dict):
        elem = ET.SubElement(parent, tag)
        for k, v in value.items():
            add_xml_element(elem, k, v)
    elif isinstance(value, list):
        for item in value:
            if isinstance(item, dict):
                sub_elem = ET.SubElement(parent, tag)
                for k, v in item.items():
                    add_xml_element(sub_elem, k, v)
            else:
                item_elem = ET.SubElement(parent, tag)
                item_elem.text = str(item)
    elif value is not None:
        elem = ET.SubElement(parent, tag)
        elem.text = str(value)
    else:
        ET.SubElement(parent, tag)


def dict_to_xml(data: dict, root_name: str = "document") -> str:
    """Convert a dictionary to formatted XML string."""
    root = ET.Element(root_name)
    
    for key, value in data.items():
        add_xml_element(root, key, value)
    
    xml_str = ET.tostring(root, encoding="unicode")
    dom = minidom.parseString(xml_str)
    return dom.toprettyxml(indent="  ")


@router.get("/xml", response_class=Response)
async def export_document_xml(
    doc_id: int = Query(..., description="Document ID to export"),
    db: AsyncSession = Depends(get_db)
):
    """Export a single document as XML."""
    doc = await get_document_by_id(db, doc_id)
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")
    
    data = document_to_dict(doc)
    xml_str = dict_to_xml(data, "document")
    
    return Response(
        content=xml_str,
        media_type="application/xml",
        headers={"Content-Disposition": f"attachment; filename=document_{doc_id}.xml"}
    )


@router.get("/all/xml", response_class=Response)
async def export_all_documents_xml(db: AsyncSession = Depends(get_db)):
    """Export all documents as XML."""
    documents = await get_all_documents(db)
    
    root = ET.Element("documents")
    root.set("total", str(len(documents)))
    
    for doc in documents:
        doc_elem = ET.SubElement(root, "document")
        data = document_to_dict(doc)
        for key, value in data.items():
            add_xml_element(doc_elem, key, value)
    
    xml_str = ET.tostring(root, encoding="unicode")
    dom = minidom.parseString(xml_str)
    formatted_xml = dom.toprettyxml(indent="  ")
    
    return Response(
        content=formatted_xml,
        media_type="application/xml",
        headers={"Content-Disposition": "attachment; filename=all_documents.xml"}
    )