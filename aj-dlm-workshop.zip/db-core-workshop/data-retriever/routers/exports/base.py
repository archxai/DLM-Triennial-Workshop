from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.orm import selectinload, joinedload

from database import get_db
from models import Document, Text, MetadataGeneral, DocumentKeyword, Picture


async def get_document_by_id(db: AsyncSession, doc_id: int) -> Document:
    """Helper to fetch a single document with all relations."""
    query = (
        select(Document)
        .options(
            selectinload(Document.texts).selectinload(Text.lines),
            selectinload(Document.doc_metadata),
            selectinload(Document.keywords).selectinload(DocumentKeyword.keyword),
            joinedload(Document.pictures).joinedload(Picture.picture_metadata)
        )
        .where(Document.document_id == doc_id)
        .where(Document.deleted_at.is_(None))
    )
    result = await db.execute(query)
    return result.unique().scalar_one_or_none()


async def get_all_documents(db: AsyncSession):
    """Helper to fetch all documents with all relations."""
    query = (
        select(Document)
        .options(
            selectinload(Document.texts).selectinload(Text.lines),
            selectinload(Document.doc_metadata),
            selectinload(Document.keywords).selectinload(DocumentKeyword.keyword),
            joinedload(Document.pictures).joinedload(Picture.picture_metadata)
        )
        .where(Document.deleted_at.is_(None))
        .order_by(Document.document_id.desc())
    )
    result = await db.execute(query)
    return result.scalars().unique().all()


def document_to_dict(doc: Document) -> dict:
    """Convert a document to a dictionary (matches DocumentSchema)."""
    return {
        "document_id": doc.document_id,
        "document_type": doc.document_type,
        "created_at": doc.created_at,
        "texts": [
            {
                "text_id": text.text_id,
                "document_id": text.document_id,
                "original_raw_text": text.original_raw_text,
                "corrected_text": text.corrected_text,
                "text_origin": text.text_origin,
                "detected_language_code": getattr(text, 'detected_language_code', None),
                "confidence_score": getattr(text, 'confidence_score', None),
                "lines": [
                    {
                        "line_id": line.line_id,
                        "line_number": line.line_number,
                        "line_text": line.line_text,
                        "is_corrected": line.is_corrected,
                        "orientation": getattr(line, 'orientation', 'upright'),
                        "confidence_score": getattr(line, 'confidence_score', None)
                    }
                    for line in text.lines
                ]
            }
            for text in doc.texts
        ],
        "metadata": [
            {
                "gen_meta_id": meta.gen_meta_id,
                "category": meta.category,
                "key": meta.key,
                "value_text": meta.value_text,
                "value_number": meta.value_number,
                "value_json": meta.value_json
            }
            for meta in doc.doc_metadata
        ],
        "keywords": [
            {
                "keyword_id": dk.keyword_id,
                "relevance_score": getattr(dk, 'relevance_score', None),
                "frequency": getattr(dk, 'frequency', None),
                "keyword": {
                    "keyword_id": dk.keyword.keyword_id,
                    "label": dk.keyword.label,
                    "category": getattr(dk.keyword, 'category', None),
                    "weight": getattr(dk.keyword, 'weight', None)
                } if dk.keyword else None
            }
            for dk in doc.keywords
        ],
        "pictures": [
            {
                "picture_id": pic.picture_id,
                "document_id": pic.document_id,
                "sha256_hash": pic.sha256_hash,
                "file_path": pic.file_path,
                "boxed_image_path": getattr(pic, 'boxed_image_path', None),
                "archive_origin": getattr(pic, 'archive_origin', None),
                "collection_type": getattr(pic, 'collection_type', None),
                "processed_at": getattr(pic, 'processed_at', None),
                "original_filename": getattr(pic.picture_metadata, 'original_filename', None) if pic.picture_metadata else None
            }
            for pic in doc.pictures
        ]
    }

