from fastapi import APIRouter, Depends, Query, HTTPException
from fastapi.responses import Response
from sqlalchemy.ext.asyncio import AsyncSession
import xml.etree.ElementTree as ET
from xml.dom import minidom

from database import get_db
from .base import get_document_by_id, get_all_documents

router = APIRouter(prefix="/export", tags=["Exports - ALTO"])


ALTO_NS = "http://www.loc.gov/standards/alto/ns-v4#"


def create_alto_xml(doc) -> str:
    """Convert a document to ALTO XML format."""
    alto = ET.Element("alto")
    alto.set("xmlns", ALTO_NS)
    alto.set("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance")
    alto.set("xsi:schemaLocation", "http://www.loc.gov/standards/alto/ns-v4# http://www.loc.gov/standards/alto/v4/alto.xsd")
    alto.set("version", "4.1")
    
    desc = ET.SubElement(alto, "Description")
    measurement_unit = ET.SubElement(desc, "MeasurementUnit")
    measurement_unit.text = "pixel"
    
    if doc.created_at:
        created = ET.SubElement(desc, "created")
        created.text = doc.created_at.isoformat()
    
    source = ET.SubElement(desc, "sourceInformation")
    source_name = ET.SubElement(source, "sourceName")
    source_name.text = f"ArchXAI Document {doc.document_id}"
    fileIdentifier = ET.SubElement(source, "fileIdentifier")
    file_identifier = ET.SubElement(fileIdentifier, "fileIdentifier")
    file_identifier.text = f"document_{doc.document_id}"
    
    layout = ET.SubElement(alto, "Layout")
    
    page_idx = 1
    
    # Handle texts safely
    if not hasattr(doc, 'texts') or doc.texts is None:
        texts = []
    else:
        texts = list(doc.texts)
    
    for text in texts:
        if text is None:
            continue
            
        page = ET.SubElement(layout, "Page")
        page.set("ID", f"page_{page_idx}")
        page.set("WIDTH", "2480")
        page.set("HEIGHT", "3508")
        
        print_space = ET.SubElement(page, "PrintSpace")
        print_space.set("HPOS", "0")
        print_space.set("VPOS", "0")
        print_space.set("WIDTH", "2480")
        print_space.set("HEIGHT", "3508")
        
        top_margin = ET.SubElement(print_space, "TopMargin")
        top_margin.set("HPOS", "100")
        top_margin.set("VPOS", "100")
        top_margin.set("WIDTH", "2280")
        top_margin.set("HEIGHT", "100")
        
        text_block = ET.SubElement(print_space, "TextBlock")
        text_block.set("ID", f"block_{text.text_id}")
        
        # Handle lines safely
        if not hasattr(text, 'lines') or text.lines is None:
            lines = []
        else:
            lines = list(text.lines)
        
        # Filter out None values
        lines = [l for l in lines if l is not None]
        
        # Sort lines that have line_number
        valid_lines = [l for l in lines if l is not None and hasattr(l, 'line_number')]
        valid_lines.sort(key=lambda l: l.line_number)
        
        for line in valid_lines:
            text_line = ET.SubElement(text_block, "TextLine")
            text_line.set("ID", f"line_{line.line_id}")
            
            hpos = str(int(line.bbox_xmin)) if getattr(line, 'bbox_xmin', None) is not None else "100"
            vpos = str(int(line.bbox_ymin)) if getattr(line, 'bbox_ymin', None) is not None else str(200 + (line.line_number * 30))
            width = str(int(line.bbox_xmax - line.bbox_xmin)) if getattr(line, 'bbox_xmax', None) is not None and getattr(line, 'bbox_xmin', None) is not None else "2280"
            height = str(int(line.bbox_ymax - line.bbox_ymin)) if getattr(line, 'bbox_ymax', None) is not None and getattr(line, 'bbox_ymin', None) is not None else "30"
            
            text_line.set("HPOS", hpos)
            text_line.set("VPOS", vpos)
            text_line.set("WIDTH", width)
            text_line.set("HEIGHT", height)
            
            # Add orientation if not upright
            orientation = getattr(line, 'orientation', 'upright')
            if orientation and orientation != 'upright':
                text_line.set("ORIENTATION", orientation)
            
            string_elem = ET.SubElement(text_line, "String")
            string_elem.set("CONTENT", line.line_text)
            string_elem.set("HPOS", hpos)
            string_elem.set("VPOS", vpos)
            string_elem.set("WIDTH", width)
            string_elem.set("HEIGHT", height)
            
            confidence = getattr(line, 'confidence_score', None)
            if confidence is not None:
                string_elem.set("WC", f"{confidence:.2f}")
        
        left_margin = ET.SubElement(print_space, "LeftMargin")
        left_margin.set("HPOS", "0")
        left_margin.set("VPOS", "100")
        left_margin.set("WIDTH", "100")
        left_margin.set("HEIGHT", "3208")
        
        right_margin = ET.SubElement(print_space, "RightMargin")
        right_margin.set("HPOS", "2380")
        right_margin.set("VPOS", "100")
        right_margin.set("WIDTH", "100")
        right_margin.set("HEIGHT", "3208")
        
        bottom_margin = ET.SubElement(print_space, "BottomMargin")
        bottom_margin.set("HPOS", "100")
        bottom_margin.set("VPOS", "3308")
        bottom_margin.set("WIDTH", "2280")
        bottom_margin.set("HEIGHT", "100")
        
        page_idx += 1
    
    xml_str = ET.tostring(alto, encoding="unicode")
    dom = minidom.parseString(xml_str)
    return dom.toprettyxml(indent="  ")


@router.get("/alto", response_class=Response)
async def export_document_alto(
    doc_id: int = Query(..., description="Document ID to export"),
    db: AsyncSession = Depends(get_db)
):
    """Export a single document as ALTO XML format."""
    doc = await get_document_by_id(db, doc_id)
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")
    
    xml_str = create_alto_xml(doc)
    
    return Response(
        content=xml_str,
        media_type="application/xml",
        headers={"Content-Disposition": f"attachment; filename=document_{doc_id}.alto.xml"}
    )


@router.get("/all/alto", response_class=Response)
async def export_all_documents_alto(db: AsyncSession = Depends(get_db)):
    """Export all documents as ALTO XML (multi-page document)."""
    documents = await get_all_documents(db)
    
    alto = ET.Element("alto")
    alto.set("xmlns", ALTO_NS)
    alto.set("version", "4.1")
    
    desc = ET.SubElement(alto, "Description")
    measurement_unit = ET.SubElement(desc, "MeasurementUnit")
    measurement_unit.text = "pixel"
    
    layout = ET.SubElement(alto, "Layout")
    
    page_idx = 1
    for doc in documents:
        if doc is None:
            continue
            
        if not hasattr(doc, 'texts') or doc.texts is None:
            texts = []
        else:
            texts = list(doc.texts)
        
        for text in texts:
            if text is None:
                continue
                
            page = ET.SubElement(layout, "Page")
            page.set("ID", f"page_{page_idx}")
            page.set("WIDTH", "2480")
            page.set("HEIGHT", "3508")
            
            print_space = ET.SubElement(page, "PrintSpace")
            print_space.set("HPOS", "0")
            print_space.set("VPOS", "0")
            print_space.set("WIDTH", "2480")
            print_space.set("HEIGHT", "3508")
            
            text_block = ET.SubElement(print_space, "TextBlock")
            text_block.set("ID", f"block_{text.text_id}")
            
            if not hasattr(text, 'lines') or text.lines is None:
                lines = []
            else:
                lines = list(text.lines)
            
            lines = [l for l in lines if l is not None]
            valid_lines = [l for l in lines if l is not None and hasattr(l, 'line_number')]
            valid_lines.sort(key=lambda l: l.line_number)
            
            for line in valid_lines:
                text_line = ET.SubElement(text_block, "TextLine")
                text_line.set("ID", f"line_{line.line_id}")
                
                hpos = str(int(line.bbox_xmin)) if getattr(line, 'bbox_xmin', None) is not None else "100"
                vpos = str(int(line.bbox_ymin)) if getattr(line, 'bbox_ymin', None) is not None else str(200 + (line.line_number * 30))
                width = str(int(line.bbox_xmax - line.bbox_xmin)) if getattr(line, 'bbox_xmax', None) is not None and getattr(line, 'bbox_xmin', None) is not None else "2280"
                height = str(int(line.bbox_ymax - line.bbox_ymin)) if getattr(line, 'bbox_ymax', None) is not None and getattr(line, 'bbox_ymin', None) is not None else "30"
                
                text_line.set("HPOS", hpos)
                text_line.set("VPOS", vpos)
                text_line.set("WIDTH", width)
                text_line.set("HEIGHT", height)
                
                # Add orientation if not upright
                orientation = getattr(line, 'orientation', 'upright')
                if orientation and orientation != 'upright':
                    text_line.set("ORIENTATION", orientation)
                
                string_elem = ET.SubElement(text_line, "String")
                string_elem.set("CONTENT", line.line_text)
                string_elem.set("HPOS", hpos)
                string_elem.set("VPOS", vpos)
                string_elem.set("WIDTH", width)
                string_elem.set("HEIGHT", height)
                
                confidence = getattr(line, 'confidence_score', None)
                if confidence is not None:
                    string_elem.set("WC", f"{confidence:.2f}")
            
            page_idx += 1
    
    xml_str = ET.tostring(alto, encoding="unicode")
    dom = minidom.parseString(xml_str)
    formatted_xml = dom.toprettyxml(indent="  ")
    
    return Response(
        content=formatted_xml,
        media_type="application/xml",
        headers={"Content-Disposition": "attachment; filename=all_documents.alto.xml"}
    )
