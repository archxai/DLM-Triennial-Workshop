from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import Response
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.orm import selectinload
import boto3
from botocore.config import Config
import os

from database import get_db
from models import Picture

router = APIRouter(prefix="/images", tags=["Images"])


def get_minio_client():
    """Create MinIO client."""
    return boto3.client(
        's3',
        endpoint_url=os.getenv('MINIO_ENDPOINT', 'http://minio-archxai:9000'),
        aws_access_key_id=os.getenv('MINIO_ROOT_USER', 'archxai_admin'),
        aws_secret_access_key=os.getenv('MINIO_ROOT_PASSWORD', 'archxai_secure_password_123'),
        config=Config(signature_version='s3v4')
    )


def get_object_key(picture: Picture, boxed: bool) -> str:
    """Get the correct object key for MinIO based on picture data."""
    if boxed and picture.boxed_image_path:
        # boxed_image_path is already the filename without prefix
        return picture.boxed_image_path
    else:
        # file_path has 'original/' prefix, strip it and change extension
        filename = picture.file_path.replace('original/', '')
        # Change .png to .jpg if needed
        if filename.endswith('.png'):
            filename = filename[:-4] + '.jpg'
        return filename


def get_content_type(picture: Picture) -> str:
    """Get content type from picture metadata if available."""
    if hasattr(picture, 'picture_metadata') and picture.picture_metadata:
        return picture.picture_metadata.mime_type or 'image/jpeg'
    return 'image/jpeg'


@router.get("/{picture_id}")
async def get_image(
    picture_id: int,
    boxed: bool = Query(False, description="Return boxed version of image"),
    db: AsyncSession = Depends(get_db)
):
    """Retrieve an image from MinIO storage."""
    query = select(Picture).options(
        selectinload(Picture.picture_metadata)
    ).where(Picture.picture_id == picture_id)
    result = await db.execute(query)
    picture = result.scalar_one_or_none()
    
    if not picture:
        raise HTTPException(status_code=404, detail="Image not found")
    
    bucket = os.getenv('MINIO_BUCKET', 'archxai-images')
    key = get_object_key(picture, boxed)
    
    try:
        s3_client = get_minio_client()
        response = s3_client.get_object(Bucket=bucket, Key=key)
        image_data = response['Body'].read()
        
        content_type = get_content_type(picture)
        
        return Response(
            content=image_data,
            media_type=content_type,
            headers={"Content-Disposition": f"inline; filename={key}"}
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to retrieve image: {str(e)}")


@router.get("/document/{document_id}")
async def get_document_images(
    document_id: int,
    boxed: bool = Query(False, description="Return boxed versions of images"),
    db: AsyncSession = Depends(get_db)
):
    """Retrieve all images for a document."""
    query = select(Picture).options(
        selectinload(Picture.picture_metadata)
    ).where(Picture.document_id == document_id)
    result = await db.execute(query)
    pictures = result.scalars().all()
    
    if not pictures:
        raise HTTPException(status_code=404, detail="No images found for document")
    
    bucket = os.getenv('MINIO_BUCKET', 'archxai-images')
    images = []
    
    for picture in pictures:
        key = get_object_key(picture, boxed)
        
        try:
            s3_client = get_minio_client()
            response = s3_client.get_object(Bucket=bucket, Key=key)
            image_data = response['Body'].read()
            
            images.append({
                "picture_id": picture.picture_id,
                "filename": key,
                "content_type": get_content_type(picture),
                "data": image_data.hex()
            })
        except Exception as e:
            continue
    
    if not images:
        raise HTTPException(status_code=500, detail="Failed to retrieve any images")
    
    return {"images": images}