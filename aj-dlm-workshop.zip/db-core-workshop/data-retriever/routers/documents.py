from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_, exists, cast, Text as SQLText, func as sqlfunc
from sqlalchemy.orm import selectinload, joinedload
from datetime import datetime

from database import get_db
from models import Document, Text, MetadataGeneral, DocumentKeyword, Keyword, Picture, PicturesMetadata
from schemas import DocumentsResponse, DocumentSchema

router = APIRouter(prefix="/documents", tags=["Documents"])


@router.get("", response_model=DocumentsResponse)
async def get_all_documents(
    page: int = Query(1, ge=1, description="Page number"),
    limit: int = Query(20, ge=1, le=100, description="Items per page"),
    language: str = Query(None, description="Filter by detected language code (e.g., fi, en)"),
    from_date: str = Query(None, description="Filter documents created after this date (YYYY-MM-DD)"),
    to_date: str = Query(None, description="Filter documents created before this date (YYYY-MM-DD)"),
    below_confidence: float = Query(None, ge=0, le=1, description="Filter documents below this confidence threshold"),
    above_confidence: float = Query(None, ge=0, le=1, description="Filter documents above this confidence threshold"),
    document_type: str = Query(None, description="Filter by document type"),
    text_origin: str = Query(None, description="Filter by text origin (OCR, HTR, Manual)"),
    keyword: str = Query(None, description="Filter by keyword label"),
    order: str = Query("desc", pattern="^(asc|desc)$", description="Sort direction"),
    db: AsyncSession = Depends(get_db)
):
    """Fetch all documents with their texts, lines, metadata, keywords, and pictures."""
    
    # Base query for documents
    filters = []
    
    # Exclude deleted documents
    filters.append(Document.deleted_at.is_(None))
    
    # Filter by document_type (case-insensitive)
    if document_type:
        filters.append(sqlfunc.lower(Document.document_type) == document_type.lower())
    
    # Filter by date range
    if from_date:
        try:
            from_datetime = datetime.strptime(from_date, "%Y-%m-%d")
            filters.append(Document.created_at >= from_datetime)
        except ValueError:
            pass
    
    if to_date:
        try:
            to_datetime = datetime.strptime(to_date, "%Y-%m-%d")
            to_datetime = to_datetime.replace(hour=23, minute=59, second=59)
            filters.append(Document.created_at <= to_datetime)
        except ValueError:
            pass
    
    # Build the base select for count
    count_query = select(func.count(Document.document_id.distinct()))
    
    # Build the base select for documents - use joinedload for nested picture_metadata
    query = select(Document).options(
        selectinload(Document.texts).selectinload(Text.lines),
        selectinload(Document.doc_metadata),
        selectinload(Document.keywords).selectinload(DocumentKeyword.keyword),
        joinedload(Document.pictures).joinedload(Picture.picture_metadata)
    )
    
    # Filter by keyword (case-insensitive)
    if keyword:
        query = query.join(Document.keywords).join(DocumentKeyword.keyword).where(sqlfunc.lower(Keyword.label) == keyword.lower())
        count_query = select(func.count(Document.document_id.distinct())).join(Document.keywords).join(DocumentKeyword.keyword).where(sqlfunc.lower(Keyword.label) == keyword.lower())
    
    # Filter by language using EXISTS subquery
    if language:
        lang_filter = exists().where(
            and_(
                Text.document_id == Document.document_id,
                Text.detected_language_code == language
            )
        )
        filters.append(lang_filter)
    
    # Filter by text origin using EXISTS subquery (case-insensitive)
    if text_origin:
        origin_filter = exists().where(
            and_(
                Text.document_id == Document.document_id,
                sqlfunc.lower(cast(Text.text_origin, SQLText)) == text_origin.lower()
            )
        )
        filters.append(origin_filter)
    
    # Filter by confidence using EXISTS subquery
    if below_confidence is not None:
        conf_filter = exists().where(
            and_(
                Text.document_id == Document.document_id,
                Text.confidence_score != None,
                Text.confidence_score <= below_confidence
            )
        )
        filters.append(conf_filter)
    
    if above_confidence is not None:
        conf_filter = exists().where(
            and_(
                Text.document_id == Document.document_id,
                Text.confidence_score != None,
                Text.confidence_score >= above_confidence
            )
        )
        filters.append(conf_filter)
    
    # Apply filters to both queries
    if filters:
        query = query.where(and_(*filters))
        count_query = count_query.where(and_(*filters))
    
    # Get total count before pagination
    count_result = await db.execute(count_query)
    total = count_result.scalar() or 0
    
    # Order by
    order_column = Document.document_id
    if order == "asc":
        query = query.order_by(order_column.asc())
    else:
        query = query.order_by(order_column.desc())
    
    # Pagination
    offset = (page - 1) * limit
    query = query.limit(limit).offset(offset)
    
    # Execute query
    result = await db.execute(query)
    documents = result.unique().scalars().all()

    return DocumentsResponse(
        documents=[DocumentSchema.model_validate(d) for d in documents],
        total=total
    )