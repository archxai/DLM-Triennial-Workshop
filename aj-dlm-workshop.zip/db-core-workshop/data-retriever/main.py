from fastapi import FastAPI
from routers.documents import router as documents_router
from routers.exports import router as exports_router
from routers.images import router as images_router

app = FastAPI(title="ArchXAI API", version="0.1.0")

app.include_router(documents_router)
app.include_router(exports_router)
app.include_router(images_router)
