from pydantic import BaseModel, field_validator, model_validator
from typing import List, Optional, Any
from datetime import datetime


class TextLineSchema(BaseModel):
    line_id: int
    line_number: int
    line_text: str
    is_corrected: bool
    orientation: Optional[str] = 'upright'
    confidence_score: Optional[float] = None

    class Config:
        from_attributes = True


class TextSchema(BaseModel):
    text_id: int
    document_id: int
    original_raw_text: str
    corrected_text: Optional[str]
    text_origin: str
    detected_language_code: Optional[str] = None
    confidence_score: Optional[float] = None
    lines: List[TextLineSchema] = []

    class Config:
        from_attributes = True


class MetadataSchema(BaseModel):
    gen_meta_id: int
    category: str
    key: str
    value_text: Optional[str] = None
    value_number: Optional[int] = None
    value_json: Optional[Any] = None

    class Config:
        from_attributes = True


class KeywordSchema(BaseModel):
    keyword_id: int
    label: str
    category: Optional[str] = None
    weight: Optional[float] = None

    class Config:
        from_attributes = True


class DocumentKeywordSchema(BaseModel):
    keyword_id: int
    relevance_score: Optional[float] = None
    frequency: Optional[int] = None
    keyword: Optional[KeywordSchema] = None

    class Config:
        from_attributes = True


class PictureSchema(BaseModel):
    picture_id: int
    document_id: int
    sha256_hash: str
    file_path: str
    boxed_image_path: Optional[str] = None
    archive_origin: Optional[str] = None
    collection_type: Optional[str] = None
    processed_at: Optional[datetime] = None
    original_filename: Optional[str] = None

    @model_validator(mode='before')
    @classmethod
    def extract_original_filename(cls, data):
        if hasattr(data, 'picture_metadata') and data.picture_metadata:
            data.original_filename = data.picture_metadata.original_filename
        return data

    class Config:
        from_attributes = True


class DocumentSchema(BaseModel):
    document_id: int
    document_type: str
    created_at: datetime
    texts: List[TextSchema] = []
    doc_metadata: List[MetadataSchema] = []
    keywords: List[DocumentKeywordSchema] = []
    pictures: List[PictureSchema] = []

    class Config:
        from_attributes = True


class DocumentsResponse(BaseModel):
    documents: List[DocumentSchema]
    total: int
